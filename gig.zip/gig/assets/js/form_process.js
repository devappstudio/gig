$(document).ready(function () {

// submit new article
    $("#frm_new_article").submit(function (e) {
        var body = tinyMCE.activeEditor.getContent();
        console.log(body);
        var title = $(this).attr('title');
        var datepicker = $(this).attr('datepicker');
        var id_sub_cats = $(this).attr('id_sub_cats');
        var userfile = $(this).attr('userfile');
        var credits = $(this).attr('credits');
        var options = {
            target: '.ajax_message',
            type: 'post',
            url: $(this).attr('action'),
            dataType: "json",
            cache: false,
            data: {'title': title, 'datepicker': datepicker, 'id_sub_cats': id_sub_cats, 'userfile': userfile, 'credits': credits, 'body': body},
            beforeSend: function () {
                $('.ajax_message').html('<div class="processor"><img src="<?php echo base_url();?>assets/images/loading.gif" alt="loading gif">  <span>Please wait while we process request!</span></div>');
            },
            success: function (data) {
                console.log(data);
                console.log(data);
                if (data.status == 'success') {
                    console.log(data);
                    $(".ajax_message").html('<div class="alert alert-success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Success, the article has been created succesfully</p></div>').show().addClass('ajax_success');
                    $('#frm_new_article')[0].reset();
                    window.scrollTo(0, 0);
                } else if (data.status == 'error') {
                    console.log(data);
                    $(".ajax_message").html('<div class="error"><p>' + data.errors + "</p></div>");
                    window.scrollTo(0, 0);
                }
            },
            error: function () {
                $(".ajax_message").html('<div class="alert alert-danger"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Sorry, the session expired - the article was not created</p></div>').show().addClass('ajax_success');
                window.scrollTo(0, 0);
            }

        };
        $('#frm_new_article').ajaxSubmit(options);
        e.preventDefault();
    });




    // submit new contributor article
    $("#frm_new_article_contributor").submit(function (e) {
        var body = tinyMCE.activeEditor.getContent();
        console.log(body);
        var title = $(this).attr('title');
        var datepicker = $(this).attr('datepicker');
        var id_sub_cats = $(this).attr('id_sub_cats');
        var userfile = $(this).attr('userfile');
        var credits = $(this).attr('credits');
        var options = {
            target: '.ajax_message',
            type: 'post',
            url: $(this).attr('action'),
            dataType: "json",
            cache: false,
            data: {'title': title, 'datepicker': datepicker, 'id_sub_cats': id_sub_cats, 'userfile': userfile, 'credits': credits, 'body': body},
            beforeSend: function () {
                $('.ajax_message').html('<div class="processor"><img src="<?php echo base_url();?>assets/images/loading.gif" alt="loading gif">  <span>Please wait while we process request!</span></div>');
            },
            success: function (data) {
                console.log(data);
                console.log(data);
                if (data.status == 'success') {
                    console.log(data);
                    $(".ajax_message").html('<div class="alert alert-success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Success, the article has been created succesfully</p></div>').show().addClass('ajax_success');
                    $('#frm_new_article_contributor')[0].reset();
                    window.scrollTo(0, 0);
                } else if (data.status == 'error') {
                    console.log(data);
                    $(".ajax_message").html('<div class="error"><p>' + data.errors + "</p></div>");
                    window.scrollTo(0, 0);
                }
            },
            error: function () {
                $(".ajax_message").html('<div class="alert alert-danger"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Sorry, the session expired - the article was not created</p></div>').show().addClass('ajax_success');
                window.scrollTo(0, 0);
            }

        };
        $('#frm_new_article_contributor').ajaxSubmit(options);
        e.preventDefault();
    });




    // submit new banner
    $("#frm_new_banner").submit(function (e) {
        var body = tinyMCE.activeEditor.getContent();
        console.log(body);
        var title = $(this).attr('title');
        var datepicker = $(this).attr('datepicker');
        var id_sub_cats = $(this).attr('id_sub_cats');
        var userfile = $(this).attr('userfile');
        var credits = $(this).attr('credits');
        var caption = $(this).attr('caption');
        var options = {
            target: '.ajax_message',
            type: 'post',
            url: $(this).attr('action'),
            dataType: "json",
            cache: false,
            data: {'title': title, 'datepicker': datepicker, 'id_sub_cats': id_sub_cats, 'userfile': userfile, 'credits': credits, 'body': body, 'caption': caption},
            beforeSend: function () {
                $('.ajax_message').html('<div class="processor"><img src="<?php echo base_url();?>assets/images/loading.gif" alt="loading gif">  <span>Please wait while we process request!</span></div>');
            },
            success: function (data) {
                console.log(data);
                console.log(data);
                if (data.status == 'success') {
                    console.log(data);
                    $(".ajax_message").html('<div class="alert alert-success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Success, the banner has been created succesfully</p></div>').show().addClass('ajax_success');
                    $('#frm_new_banner')[0].reset();
                    window.scrollTo(0, 0);
                } else if (data.status == 'error') {
                    console.log(data);
                    $(".ajax_message").html('<div class="error"><p>' + data.errors + "</p></div>");
                    window.scrollTo(0, 0);
                }
            },
            error: function () {
                $(".ajax_message").html('<div class="alert alert-danger"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Sorry, the session expired - the banner was not created</p></div>').show().addClass('ajax_success');
                window.scrollTo(0, 0);
            }

        };
        $('#frm_new_banner').ajaxSubmit(options);
        e.preventDefault();
    });



    // change/update banner image
    $("#frm_update_banner_photo").submit(function (e) {
        var id = $(this).attr('banner_id');
        var userfile = $(this).attr('userfile');
        var caption = $(this).attr('caption');
        var options = {
            target: '.ajax_message',
            type: 'post',
            url: $(this).attr('action'),
            dataType: "json",
            cache: false,
            //data: {'id': id,'userfile': userfile,'caption':caption},
            beforeSend: function () {
                $('.ajax_message').html('<div class="processor"><img src="<?php echo base_url();?>assets/images/loading.gif" alt="loading gif">  <span>Please wait while we process request!</span></div>');
            },
            success: function (data) {
                console.log(data);
                console.log(data);
                if (data.status == 'success') {
                    console.log(data);
                    $(".ajax_message").html('<div class="alert alert-success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Success, the banner has been updated succesfully</p></div>').show().addClass('ajax_success');
                    window.scrollTo(0, 0);
                    setTimeout(function () {
                        location.reload();
                    }, 1000);
                } else {
                    console.log(data);
                    $(".ajax_message").html('<div class="error"><p>' + data.errors + "</p></div>");
                    window.scrollTo(0, 0);
                }
            },
            error: function () {
                $(".ajax_message").html('<div class="alert alert-danger"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Sorry, the session expired - the banner was not updated</p></div>').show().addClass('ajax_success');
                window.scrollTo(0, 0);
            }

        };
        $('#frm_update_banner_photo').ajaxSubmit(options);
        e.preventDefault();
    });



    // Cm change/update banner image
    $("#frm_update_banner_photo_cm").submit(function (e) {
        var id = $(this).attr('banner_id');
        var userfile = $(this).attr('userfile');
        var caption = $(this).attr('caption');
        var options = {
            target: '.ajax_message',
            type: 'post',
            url: $(this).attr('action'),
            dataType: "json",
            cache: false,
            //data: {'id': id,'userfile': userfile,'caption':caption},
            beforeSend: function () {
                $('.ajax_message').html('<div class="processor"><img src="<?php echo base_url();?>assets/images/loading.gif" alt="loading gif">  <span>Please wait while we process request!</span></div>');
            },
            success: function (data) {
                console.log(data);
                console.log(data);
                if (data.status == 'success') {
                    console.log(data);
                    $(".ajax_message").html('<div class="alert alert-success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Success, the banner has been updated succesfully</p></div>').show().addClass('ajax_success');
                    window.scrollTo(0, 0);
                    setTimeout(function () {
                        location.reload();
                    }, 1000);
                } else {
                    console.log(data);
                    $(".ajax_message").html('<div class="error"><p>' + data.errors + "</p></div>");
                    window.scrollTo(0, 0);
                }
            },
            error: function () {
                $(".ajax_message").html('<div class="alert alert-danger"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Sorry, the session expired - the banner was not updated</p></div>').show().addClass('ajax_success');
                window.scrollTo(0, 0);
            }

        };
        $('#frm_update_banner_photo_cm').ajaxSubmit(options);
        e.preventDefault();
    });


    // update new banner
    $("#frm_edit_banner").submit(function (e) {
        var body = tinyMCE.activeEditor.getContent();
        console.log(body);
        var title = $(this).attr('title');
        var datepicker = $(this).attr('date_published');
        var id_sub_cats = $(this).attr('id_sub_cats');
        var credits = $(this).attr('credits');
        var options = {
            target: '.ajax_message',
            type: 'post',
            url: $(this).attr('action'),
            dataType: "json",
            cache: false,
            data: {'title': title, 'datepicker': datepicker, 'id_sub_cats': id_sub_cats, 'credits': credits, 'body': body},
            beforeSend: function () {
                $('.ajax_message').html('<div class="processor"><img src="<?php echo base_url();?>assets/images/loading.gif" alt="loading gif">  <span>Please wait while we process request!</span></div>');
            },
            success: function (data) {
                console.log(data);
                console.log(data);
                if (data.status == 'success') {
                    console.log(data);
                    $(".ajax_message").html('<div class="alert alert-success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Success, the article has been created succesfully</p></div>').show().addClass('ajax_success');
                    window.scrollTo(0, 0);
                } else if (data.status == 'error') {
                    console.log(data);
                    $(".ajax_message").html('<div class="error"><p>' + data.errors + "</p></div>");
                    window.scrollTo(0, 0);
                }
            },
            error: function () {
                $(".ajax_message").html('<div class="alert alert-danger"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Sorry, the session expired - the article was not created</p></div>').show().addClass('ajax_success');
                window.scrollTo(0, 0);
            }

        };
        $('#frm_edit_banner').ajaxSubmit(options);
        e.preventDefault();
    });
    // edit article cm
    $("#frm_update_article").submit(function (e) {
        var body = tinyMCE.activeEditor.getContent();
        //console.log(body);
        var title = $(this).attr('title');
        var datepicker = $(this).attr('datepicker');
        var id_sub_cats = $(this).attr('cats');
        var credits = $(this).attr('credits');
        var id_contributor = $("#id_contributor").val();
        var id = $("#id").val();
        var options = {
            target: '.ajax_message',
            type: "post",
            url: $(this).attr('action'),
            dataType: "json",
            cache: false,
            data: {'id_contributor': id_contributor, 'id': id, 'title': title, 'datepicker': datepicker, 'cats': id_sub_cats, 'credits': credits, 'body': body},
            beforeSend: function () {
                $('.ajax_message').html('<div class="processor">assets/images/loading.gif" alt="loading gif">  <span>Please wait while we process request!</span></div>');
            },
            success: function (data) {
                console.log(data);
                console.log(data);
                if (data.status == 'success') {
                    console.log(data);
                    $(".ajax_message").html('<div class="alert alert-success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Success, the article has been updated succesfully</p></div>').show().addClass('ajax_success');
                    window.scrollTo(0, 0);
                    setTimeout(function () {
                        window.location.reload();
                    }, 1000);
                } else if (data.status == 'error') {
                    console.log(data);
                    $(".ajax_message").html('<div class="alert alert-danger"><p>Error<br/>The article was not updated.</p></div>');
                    window.scrollTo(0, 0);
                }
            },
            error: function () {
//                $(".ajax_message").html('<div class="alert alert-danger"><p><i class="fa fa-exclamation-circle"></i> An error occurred whiles updating the article</p></div>');
//                 window.scrollTo(0, 0);
                $(".ajax_message").html('<div class="alert alert-success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Success, the article has been updated succesfully</p></div>').show().addClass('ajax_success');
                window.scrollTo(0, 0);
                // new location reload
                setTimeout(function () {
                    window.location.reload();
                }, 1000);
            }

        };
        $('#frm_update_article').ajaxSubmit(options);
        e.preventDefault();
    });





    // edit editors article
    $("#frm_update_editors_article").submit(function (e) {
        var body = tinyMCE.activeEditor.getContent();
        //console.log(body);
        var title = $(this).attr('title');
        var datepicker = $(this).attr('datepicker');
        var id_sub_cats = $(this).attr('cats');
        var credits = $(this).attr('credits');
        var id_contributor = $("#id_contributor").val();
        var id = $("#id").val();
        var options = {
            target: '.ajax_message',
            type: "post",
            url: $(this).attr('action'),
            dataType: "json",
            cache: false,
            data: {'id_contributor': id_contributor, 'id': id, 'title': title, 'datepicker': datepicker, 'cats': id_sub_cats, 'credits': credits, 'body': body},
            beforeSend: function () {
                $('.ajax_message').html('<div class="processor">assets/images/loading.gif" alt="loading gif">  <span>Please wait while we process request!</span></div>');
            },
            success: function (data) {
                console.log(data);
                console.log(data);
                if (data.status == 'success') {
                    console.log(data);
                    $(".ajax_message").html('<div class="alert alert-success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Success, the article has been updated succesfully</p></div>').show().addClass('ajax_success');
                    window.scrollTo(0, 0);
                    setTimeout(function () {
                        window.location.reload();
                    }, 1000);
                } else if (data.status == 'error') {
                    console.log(data);
                    $(".ajax_message").html('<div class="alert alert-danger"><p>Error<br/>The article was not updated.</p></div>');
                    window.scrollTo(0, 0);
                }
            },
            error: function () {
//                $(".ajax_message").html('<div class="alert alert-danger"><p><i class="fa fa-exclamation-circle"></i> An error occurred whiles updating the article</p></div>');
//                 window.scrollTo(0, 0);
                $(".ajax_message").html('<div class="alert alert-success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Success, the article has been updated succesfully</p></div>').show().addClass('ajax_success');
                window.scrollTo(0, 0);
                // new location reload
                setTimeout(function () {
                    window.location.reload();
                }, 1000);
            }

        };
        $('#frm_update_editors_article').ajaxSubmit(options);
        e.preventDefault();
    });



    // update contributors article
    $("#update_contributor_article").submit(function (e) {
        var body = tinyMCE.activeEditor.getContent();
        //console.log(body);
        var title = $(this).attr('title');
        var datepicker = $(this).attr('datepicker');
        var id_sub_cats = $(this).attr('cats');
        var credits = $(this).attr('credits');
        var id_contributor = $("#id_contributor").val();
        var id = $("#id").val();
        var options = {
            target: '.ajax_message',
            type: "post",
            url: $(this).attr('action'),
            dataType: "json",
            cache: false,
            data: {'id_contributor': id_contributor, 'id': id, 'title': title, 'datepicker': datepicker, 'cats': id_sub_cats, 'credits': credits, 'body': body},
            beforeSend: function () {
                $('.ajax_message').html('<div class="processor">assets/images/loading.gif" alt="loading gif">  <span>Please wait while we process request!</span></div>');
            },
            success: function (data) {
                console.log(data);
                console.log(data);
                if (data.status == 'success') {
                    console.log(data);
                    $(".ajax_message").html('<div class="alert alert-success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Success, the article has been updated succesfully</p></div>').show().addClass('ajax_success');
                    window.scrollTo(0, 0);
                    setTimeout(function () {
                        window.location.reload();
                    }, 1000);
                } else if (data.status == 'error') {
                    console.log(data);
                    $(".ajax_message").html('<div class="alert alert-danger"><p>Error<br/>The article was not updated.</p></div>');
                    window.scrollTo(0, 0);
                }
            },
            error: function () {
//                $(".ajax_message").html('<div class="alert alert-danger"><p><i class="fa fa-exclamation-circle"></i> An error occurred whiles updating the article</p></div>');
//                 window.scrollTo(0, 0);
                $(".ajax_message").html('<div class="alert alert-success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Success, the article has been updated succesfully</p></div>').show().addClass('ajax_success');
                window.scrollTo(0, 0);
                // new location reload
                setTimeout(function () {
                    window.location.reload();
                }, 1000);
            }

        };
        $('#update_contributor_article').ajaxSubmit(options);
        e.preventDefault();
    });





    // add new article photo
    $("#frm_add_new_article_photo").submit(function (e) {
//        var userfile = $(this).attr('userfile');
//        var id = $(this).attr('id');

        var options = {
            target: '.ajax_message',
            type: 'post',
            url: $(this).attr('action'),
            dataType: "json",
            cache: false,
            data: $("#frm_add_new_article_photo").serialize(),
            beforeSend: function () {
                $('.ajax_message').html('<div class="processor"><img src="<?php echo base_url();?>assets/images/loading.gif" alt="loading gif">  <span>Please wait while we process request!</span></div>');
            },
            success: function (data) {
                console.log(data);
                if (data.status == 'success') {
                    console.log(data);
                    $(".ajax_message").html('<div class="alert alert-success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Success, the article has been created succesfully</p></div>').show().addClass('ajax_success');
                    window.scrollTo(0, 0);
                } else if (data.status == 'error') {
                    console.log(data);
                    $(".ajax_message").html('<div class="error"><p>' + data.errors + "</p></div>");
                    window.scrollTo(0, 0);
                }
            },
            error: function () {
                $(".ajax_message").html('<div class="alert alert-danger"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Sorry, the session expired - the article was not created</p></div>').show().addClass('ajax_success');
                window.scrollTo(0, 0);
            }

        };
        $('#frm_add_new_article_photo').ajaxSubmit(options);
        e.preventDefault();
    });




    // add new media
    $("#fileupload2").submit(function (e) {


        var options = {
            target: '.ajax_message',
            type: 'post',
            url: $(this).attr('action'),
            dataType: "json",
            cache: false,
            data: $(".fileupload2").serialize(),
            beforeSend: function () {
                $('.ajax_message').html('<div class="processor"><img src="<?php echo base_url();?>assets/images/loading.gif" alt="loading gif">  <span>Please wait while we process request!</span></div>');
            },
            success: function (data) {
                console.log(data);
                if (data.status == 'success') {
                    console.log(data);
                    $(".ajax_message").html('<div class="alert alert-success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Success, the media has been created succesfully</p></div>').show().addClass('ajax_success');
                    $('#fileupload2')[0].reset();
                    window.scrollTo(0, 0);
                } else if (data.status == 'error') {
                    console.log(data);
                    $(".ajax_message").html('<div class="error"><p>' + data.errors + "</p></div>");
                    window.scrollTo(0, 0);
                }
            },
            error: function () {
                $(".ajax_message").html('<div class="alert alert-danger"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Error, session expired<br/> Please the file size exceeded the maximum file size recommendation of 5MB</p></div>').show().addClass('ajax_success');
                window.scrollTo(0, 0);
            }

        };
        $('#fileupload2').ajaxSubmit(options);
        e.preventDefault();
    });


    // LOAD MORE FUNCTIONALITY OF THE INDEX PAGE 
    var idx_load_more = 6;
    $('#show_more').click(function () {
        idx_load_more = idx_load_more + 3;

        var url = $(this).attr('url');
        $('#shop-list-content').load(url + 'site/load_more_index/' + idx_load_more);
    });



    // handle next paginations  on the event page - front end
    $('#paginate_next').click(function (e) {
        var id = $(this).attr('next');

        var url = $(this).attr('url');
        $('#paginate').html('');
        $('#paginate').load(url + 'site/paginate_next/' + id);
        e.preventDefault();
    });



    // handle pre paginations  on the event page - front end
    $('#paginate_pre').click(function (e) {

        var id = $(this).attr('pre');

        var url = $(this).attr('url');
        $('#paginate').html('');
        $('#paginate').load(url + 'site/paginate_pre/' + id);
        e.preventDefault();
    });




    // get selected institution - front end
    $('#select_country').on('change', function (e) {

        //var optionSelected = $("option:selected", this);
        var id = this.value;

        var url = $(this).attr('url');
        $('#institutions').html('');
        $('#institutions').load(url + 'site/get_selected_institution/' + id);
        e.preventDefault();
    });




    // submitcm article
    $('#submit_new_article_cm').submit(function (e) {
        e.preventDefault();
        var body = tinyMCE.activeEditor.getContent();
        var title = $(this).attr('title');
        var datepicker = $(this).attr('datepicker');
        var id_sub_cats = $(this).attr('id_sub_cats');
        var credits = $(this).attr('credits');
        var userfile = $(this).attr('userfile');
        //loading functionality
        window.scrollTo(0, 0);
//        if (files == null) {
//            $(".ajax_message").html('<div class="error"><p><i class="fa fa-exclamation-circle"></i>Please upload an image</p></div>');
//            return;
//        }
//        
        $('.ajax_message').html("<div class='processor'><img src=<?php echo base_url(); ?>assets/images/loading.gif' alt='loading gif'>  <span>Please wait while we process request!</span></div>");

        var options = {
            type: 'POST',
            cache: false,
            url: $(this).attr("action"),
            data: {'title': title, 'datepicker': datepicker, 'cats': id_sub_cats, 'credits': credits, 'body': body, 'userfile': userfile},
            processData: false,
            contentType: false,
            success: function (data) {
                data = JSON.parse(data);
                $('.ajax_message').empty();
                if (data.status == 'success') {
                    // window.location = data.target;                                 $(".ajax_message").html('');
                    $(".ajax_message").html('<div class="success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Thank you, article uploaded succesfully</p></div>').show().addClass('ajax_success');
                    $('#submit_new_article_cm')[0].reset();
                    //window.scrollTo(0, 0);
                    setTimeout(function () {
                        location.reload();
                    }, 1000);
                } else if (data.status == 'error') {
                    console.log(data);
                    $(".ajax_message").html('<div class="error"><p>' + data.errors + "</p></div>");
                }
            },
            error: function () {
                $(".ajax_message").html('<div class="error"><p><i class="fa fa-exclamation-circle"></i> Sorry, session expired</p></div>');
            }
        };

        $('#submit_new_article_cm').ajaxSubmit(options);
        e.preventDefault();
    });



    // submit new cm banner

    $('#submit_new_banner_cm').submit(function (e) {
        e.preventDefault();
        var body = tinyMCE.activeEditor.getContent();
        var title = $(this).attr('title');
        var datepicker = $(this).attr('datepicker');
        var id_sub_cats = $(this).attr('id_sub_cats');
        var credits = $(this).attr('credits');
        var userfile = $(this).attr('userfile');
        //var caption = $(this).attr('caption');
        //loading functionality
        window.scrollTo(0, 0);
//        if (files == null) {
//            $(".ajax_message").html('<div class="error"><p><i class="fa fa-exclamation-circle"></i>Please upload an image</p></div>');
//            return;
//        }
//        
//        $('.ajax_message').html('<div class="processor"><img src="<?php echo base_url(); ?>assets/images/loading.gif" alt="loading gif">  <span>Please wait while we process request!</span></div>');

        var options = {
            type: 'POST',
            cache: false,
            url: $(this).attr("action"),
            data: {'title': title, 'datepicker': datepicker, 'cats': id_sub_cats, 'credits': credits, 'body': body, 'userfile': userfile},
            processData: false,
            contentType: false,
            success: function (data) {
                data = JSON.parse(data);
                $('.ajax_message').empty();
                if (data.status == 'success') {
                    // window.location = data.target;                                 $(".ajax_message").html('');
                    $(".ajax_message").html('<div class="success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Thank you, banner uploaded succesfully</p></div>').show().addClass('ajax_success');
                    // $('#login-form-up').modal('hide');
                } else if (data.status == 'error') {
                    console.log(data);
                    $(".ajax_message").html('<div class="error"><p>' + data.errors + "</p></div>");
                }
            },
            error: function () {
                $(".ajax_message").html('<div class="error"><p><i class="fa fa-exclamation-circle"></i> Sorry, session expired</p></div>');
            }
        };

        $('#submit_new_banner_cm').ajaxSubmit(options);
        e.preventDefault();
    });




    // update banner
    $('#update_banner_cm').submit(function (e) {
        e.preventDefault();
        var body = tinyMCE.activeEditor.getContent();
        var title = $(this).attr('title');
        var datepicker = $(this).attr('datepicker');
        var id_sub_cats = $(this).attr('id_sub_cats');
        var credits = $(this).attr('credits');

        //var caption = $(this).attr('caption');
        //loading functionality
        window.scrollTo(0, 0);
//        if (files == null) {
//            $(".ajax_message").html('<div class="error"><p><i class="fa fa-exclamation-circle"></i>Please upload an image</p></div>');
//            return;
//        }
//        
//        $('.ajax_message').html('<div class="processor"><img src="<?php echo base_url(); ?>assets/images/loading.gif" alt="loading gif">  <span>Please wait while we process request!</span></div>');

        var options = {
            type: 'POST',
            cache: false,
            url: $(this).attr("action"),
            data: {'title': title, 'datepicker': datepicker, 'id_sub_cats': id_sub_cats, 'credits': credits, 'body': body},
            processData: false,
            contentType: false,
            success: function (data) {
                data = JSON.parse(data);
                $('.ajax_message').empty();
                if (data.status == 'success') {
                    // window.location = data.target;                                 $(".ajax_message").html('');
                    $(".ajax_message").html('<div class="success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Thank you, the banner updated succesfully</p></div>').show().addClass('ajax_success');
                    // $('#login-form-up').modal('hide');
                } else if (data.status == 'error') {
                    console.log(data);
                    $(".ajax_message").html('<div class="error"><p>' + data.errors + "</p></div>");
                }
            },
            error: function () {
                $(".ajax_message").html('<div class="error"><p><i class="fa fa-exclamation-circle"></i> Sorry, session expired</p></div>');
            }
        };

        $('#update_banner_cm').ajaxSubmit(options);
        e.preventDefault();
    });




    // add a comment - front end
    $("#post_commentx").submit(function (e) {

        var id = $('#article_id').val();
        var datax = $("#post_commentx").serialize();
        var url = $(this).attr('action') + 'site/submit_comment';
        var url2 = $(this).attr('action');
        $.ajax({
            type: "POST",
            url: url,
            data: datax,
            success: function (data) {
                if (data.status == 'success') {
                    $(".ajax_message").html('<div class="alert alert-success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Thank you, the comment was submitted succesfully</p></div>').show().addClass('ajax_success');
                    $("#post_commentx")[0].reset();
                    $('#comment').load(url2 + 'site/load_comment/' + id);
                } else if (data.status == 'error') {
                    $(".ajax_message").html('<div class="alert alert-danger"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Error: the comment was not submitted</p></div>').show().addClass('ajax_error');
                    console.log(data.status);
                }
            },
            dataType: 'json'
        });
        e.preventDefault();
    });






    // comment on media
    $("#media_comment_form").submit(function (e) {

        var id = $('#soundbite_id').val();
        var datax = $("#media_comment_form").serialize();
        var url = $(this).attr('action') + 'site/submit_media_comment';
        var url2 = $(this).attr('action');
        $.ajax({
            type: "POST",
            url: url,
            data: datax,
            success: function (data) {
                if (data.status == 'success') {
                    $(".ajax_message").html('<div class="alert alert-success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Thank you, the comment was submitted succesfully</p></div>').show().addClass('ajax_success');
                    $("#media_comment_form")[0].reset();
                    $('#media_comment_soundbite').load(url2 + 'site/load_media_comment/' + id);
                } else if (data.status == 'error') {
                    $(".ajax_message").html('<div class="alert alert-danger"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Error: the comment was not submitted<br/> ' + data.error + '</p></div>').show().addClass('ajax_error');
                    console.log(data.status);
                }
            },
            dataType: 'json'
        });
        e.preventDefault();
    });




    // add reply to a comment
    $("#comment_reply").submit(function (e) {
        if ($("#comment_rep").val() == '') {
            $(".ajax_messagex").html('<div class="alert alert-danger">Please enter comment</div>');
            return false;
        }

        var article_id = $("#article_id").val();
        var id = sessionStorage.getItem('comment_id');
        var reply = $("#comment_rep").val();
        var url = $(this).attr('action') + 'site/submit_comment_reply';
        var url2 = $(this).attr('action');
        $.ajax({
            type: "POST",
            url: url,
            data: {'comment_id': id, 'reply': reply},
            success: function (data) {
                if (data.status == 'success') {
                    $('#comment').html('');
                    $(".ajax_messagex").html('<div class="alert alert-success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Thank you, the comment reply was submitted succesfully</p></div>').show().addClass('ajax_success');
                    $("#comment_reply")[0].reset();
                    $('#comment').load(url2 + 'site/load_comment/' + article_id);
                } else if (data.status == 'error') {
                    $(".ajax_messagex").html('<div class="alert alert-danger"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Error: the comment reply was not submitted</p></div>').show().addClass('ajax_error');
                    console.log(data.status);
                }
            },
            dataType: 'json'
        });
        e.preventDefault();
    });




    // SOUNDBITE COMMENT REPLY
    $("#soundbite_reply").submit(function (e) {
        if ($("#rep_comment").val() == '') {
            $(".ajax_messagex").html('<div class="alert alert-danger">Please enter comment</div>');
            return false;
        }

        var article_id = $("#soundbite_id").val();
        var id = sessionStorage.getItem('soundbite_id');
        var reply = $("#rep_comment").val();
        var url = $(this).attr('action') + 'site/sound_comment_reply';
        var url2 = $(this).attr('action');
        $.ajax({
            type: "POST",
            url: url,
            data: {'comment_id': id, 'rep_comment': reply},
            success: function (data) {
                if (data.status == 'success') {
                    $('#media_comment_soundbite').html('');
                    $(".ajax_messagex1").html('<div class="alert alert-success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Thank you, the comment reply was submitted succesfully</p></div>').show().addClass('ajax_success');
                    $("#soundbite_reply")[0].reset();
                    $('#media_comment_soundbite').load(url2 + 'site/load_media_comment/' + article_id);
                } else if (data.status == 'error') {
                    $(".ajax_messagex1").html('<div class="alert alert-danger"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Error: the comment reply was not submitted</p></div>').show().addClass('ajax_error');
                    console.log(data.status);
                }
            },
            dataType: 'json'
        });
        e.preventDefault();
    });









    // comment on video form
    $("#video_comment_form").submit(function (e) {

        var id = $('#vid_id').val();
        var datax = $("#video_comment_form").serialize();
        var url = $(this).attr('action') + 'site/submit_video_comment';
        var url2 = $(this).attr('action');
        $.ajax({
            type: "POST",
            url: url,
            data: datax,
            success: function (data) {
                if (data.status == 'success') {
                    $(".ajax_message").html('<div class="alert alert-success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Thank you, the comment was submitted succesfully</p></div>').show().addClass('ajax_success');
                    $("#video_comment_form")[0].reset();
                    $('#media_comment_video').load(url2 + 'site/load_video_comment/' + id);
                } else if (data.status == 'error') {
                    $(".ajax_message").html('<div class="alert alert-danger"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Error: the comment was not submitted<br/> ' + data.error + '</p></div>').show().addClass('ajax_error');
                    console.log(data.status);
                }
            },
            dataType: 'json'
        });
        e.preventDefault();
    });



    // reply on video comment
    $("#video_comment_reply").submit(function (e) {
        if ($("#rep_comment1").val() == '') {
            $(".ajax_messagex").html('<div class="alert alert-danger">Please enter comment</div>');
            return false;
        }

        var article_id = $("#video_id").val();
        var id = sessionStorage.getItem('video_id');
        var reply = $("#rep_comment1").val();
        var url = $(this).attr('action') + 'site/video_comment_reply';
        var url2 = $(this).attr('action');
        $.ajax({
            type: "POST",
            url: url,
            data: {'comment_id': id, 'rep_comment': reply},
            success: function (data) {
                if (data.status == 'success') {
                    $('#media_comment_soundbite').html('');
                    $(".ajax_messagex1").html('<div class="alert alert-success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Thank you, the comment reply was submitted succesfully</p></div>').show().addClass('ajax_success');
                    $("#video_comment_reply")[0].reset();
                    $('#media_comment_video').load(url2 + 'site/load_video_comment/' + article_id);
                } else if (data.status == 'error') {
                    $(".ajax_messagex1").html('<div class="alert alert-danger"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Error: the comment reply was not submitted</p></div>').show().addClass('ajax_error');
                    console.log(data.status);
                }
            },
            dataType: 'json'
        });
        e.preventDefault();
    });




    // make the a school is selected from the choose location - front end
    $("#locationForm").submit(function () {
        if ($("#institution_id").val() === '') {
            $(".ajax_message").html("<div class='alert alert-danger'>Please make sure an institution is selected</div>");
            return false;
        } else if ($("#institution2").val() === '') {
            $(".ajax_message").html("<div class='alert alert-danger'>Please make sure an institution is selected</div>");
            return false;
        }


    });




    // send chat
    $("#send_chat").click(function (e) {

        if ($("#chat_message").val() == '') {
            $(".ajax_message").html('<div class="alert alert-danger">Please enter messsage</div>');
            return false;
        }
        var url = $("#url").val() + 'site/send_live_chat';
        var msg = $("#chat_message").val();
        var chats_id = $("#chat_id").val();
        var url2 = $("#url").val() + 'index.php/site/conversation/' + chats_id;

        $.ajax({
            type: "POST",
            url: url,
            data: {'chat_id': chats_id, 'msg': msg},
            success: function (data) {
                if (data.status == 'success') {
                    //$('#media_comment_soundbite').html('');
                    $(".ajax_message").html('<div class="alert alert-success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Thank you, the comment reply was submitted succesfully</p></div>').show().addClass('ajax_success');
                    //$("#chat_message").reset();
                    //$('#media_comment_video').load(url2 + 'site/load_video_comment/' + article_id);
                    $('#chats_div1').load(url2 + ' #chats_div1');
                    var ref = setInterval(function () {
                        $('#chats_div1').load(url2 + ' #chats_div1');
                    }, 2000);

                    $('#chats_div2').load(url2 + ' #chats_div2');
                    var ref = setInterval(function () {
                        $('#chats_div2').load(url2 + ' #chats_div2');
                        window.document.getElementById('chats_div2').innerHTML.scrollTo(0, 30000);
                    }, 2000);





                    $("#chat_message").val('');
                    $(".ajax_message").html('');

                } else if (data.status == 'error') {
                    $(".ajax_messagex1").html('<div class="alert alert-danger"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Error: the comment reply was not submitted</p></div>').show().addClass('ajax_error');
                    console.log(data.status);
                }
            },
            dataType: 'json'
        });


        e.preventDefault();
    });
 


    // send image - live chat
    $('#frm_send_photo').submit(function (e) {
        //e.preventDefault();
        var chats_id = $("#chat_id").val();
        var url2 = $("#url").val() + 'index.php/site/conversation/' + chats_id;

        $('.ajax_message1').html("<div class='alert alert-danger'><span>Please wait while we process your request!</span></div>");

        var options = {
            type: 'POST',
            cache: false,
            url: $(this).attr("action"),
            data: $('#frm_send_photo').serialize(), //{'credits': credits,'userfile': userfile,'chat_id':chat_id},
            dataType: "json",
            success: function (data) {
                $('.ajax_message1').empty();
                if (data.status == 'success') {
                    // window.location = data.target;                                 $(".ajax_message").html('');
                    $(".ajax_message1").html('<div class="success"><p>&nbsp;&nbsp;Thank you, the photo upload was succesfull</p></div>').show().addClass('ajax_success');


                    $('#chats_div1').load(url2 + ' #chats_div1');
                    var ref = setInterval(function () {
                        $('#chats_div1').load(url2 + ' #chats_div1');
                    }, 2000);

                    $('#chats_div2').load(url2 + ' #chats_div2');
                    var ref = setInterval(function () {
                        $('#chats_div2').load(url2 + ' #chats_div2');
                    }, 2000);

                    $('#frm_send_photo')[0].reset();
                    $('#attachment').modal('hide');

                } else if (data.status == 'error') {

                    $(".ajax_message1").html('<div class="error"><p>' + data.errors + "</p></div>");
                }
            },
            error: function () {
                $(".ajax_message1").html('<div class="error"><p><i class="fa fa-exclamation-circle"></i> Sorry, session expired</p></div>');
            }
        };

        $('#frm_send_photo').ajaxSubmit(options);
        e.preventDefault();
    });





    $('#frm_new_conversation').submit(function (e) {
        //e.preventDefault();

        $('.ajax_message').html("<div class='alert alert-danger'><span>Please wait while we process your request!</span></div>");

        var options = {
            type: 'POST',
            cache: false,
            url: $(this).attr("action"),
            data: $('#frm_new_conversation').serialize(),
            dataType: "json",
            success: function (data) {
                $('.ajax_message').empty();
                if (data.status == 'success') {
                    // window.location = data.target;                                 $(".ajax_message").html('');
                    $(".ajax_message").html('<div class="success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Thank you, the chat topic was submitted successfully</p></div>').show().addClass('ajax_success');
                    $('#frm_new_conversation')[0].reset();
                    //$('#attachment').modal('hide');
                    setTimeout(function () {
                        location.reload();
                    }, 1000);
                } else if (data.status == 'error') {

                    $(".ajax_message").html('<div class="error"><p>' + data.errors + "</p></div>");
                }
            },
            error: function () {
                $(".ajax_message").html('<div class="error"><p><i class="fa fa-exclamation-circle"></i> Sorry, session expired</p></div>');
            }
        };

        $('#frm_new_conversation').ajaxSubmit(options);
        e.preventDefault();
    });





    // choose screen name
    $("#frm_chat_name").submit(function (e) {

        var datax = $("#frm_chat_name").serialize();
        var url = $(this).attr('action');
        $.ajax({
            type: "POST",
            url: url,
            data: datax,
            success: function (data) {
                if (data.status == 'success') {
                    $(".ajax_message").html('<div class="alert alert-success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Thank you, your screen name has been created succesfully</p></div>').show().addClass('ajax_success');
                    $("#frm_chat_name")[0].reset();
                    setTimeout(function () {
                        location.reload();
                    }, 1000);
                    $("#screen-name").hide();
                } else if (data.status == 'error') {
                    $(".ajax_message").html('<div class="alert alert-danger"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Error: the screen name was not submitted<br/> ' + data.error + '</p></div>').show().addClass('ajax_error');
                    console.log(data.status);
                }
            },
            dataType: 'json'
        });
        e.preventDefault();
    });




    // registration - register a new user
    $("#frm_registration").submit(function (e) {

        var datax = $("#frm_registration").serialize();
        var url = $(this).attr('action');
        $.ajax({
            type: "POST",
            url: url,
            data: datax,
            success: function (data) {
                if (data.status == 'success') {
                    $("#ajax_message_sign_up").html('<div class="alert alert-success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Thank you, your registration was successfull</p></div>').show().addClass('ajax_success');
                    $("#frm_registration")[0].reset();
                    setTimeout(function () {
                        location.reload();
                    }, 1000);
                    $("#sign-up").hide();
                } else if (data.status == 'error') {
                    $("#ajax_message_sign_up").html('<div class="alert alert-danger"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Error: <br/> ' + data.error + '</p></div>').show().addClass('ajax_error');
                    console.log(data.status);
                }
            },
            dataType: 'json'
        });
        e.preventDefault();
    });


    // submit user login
    $("#frm_login").submit(function (e) {

        var datax = $("#frm_login").serialize();
        var url = $(this).attr('action');
        $.ajax({
            type: "POST",
            url: url,
            data: datax,
            success: function (data) {
                if (data.status == 'success') {
                    $("#messages_login").html('<div class="alert alert-success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Thank you, you are now logged into collegemag, we hope you will enjoy it!</p></div>').show().addClass('ajax_success');
                    $("#frm_login")[0].reset();
                    setTimeout(function () {
                        location.reload();
                    }, 1000);
                    $("#sign-up").hide();
                } else if (data.status == 'error') {
                    $("#messages_login").html('<div class="alert alert-danger"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Error: <br/> ' + data.error + '</p></div>').show().addClass('ajax_error');
                    console.log(data.status);
                }
            },
            dataType: 'json'
        });
        e.preventDefault();
    });









});


