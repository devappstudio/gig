<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'site';
$route['404_override'] = 'site/error';
$route['blog'] = 'site/blog';
$route['log_out'] = 'site/logout';
$route['new_gig'] = 'site/new_gig';
$route['asset_instruments'] = 'site/asset_instruments';
$route['instrument_codes'] = 'site/instrument_codes';
$route['assets'] = 'site/assets';
$route['new_user'] = 'site/new_user';
$route['logout'] = 'site/logout';
$route['login'] = 'site/index';
$route['placement_companies'] = 'site/placement_companies';
$route['client_setup'] = 'site/client_setup';
$route['client_management'] = 'site/client_management';
$route['dashboard'] = 'site/dashboard';
$route['transactions'] = 'site/transactions';
$route['manage_transactions'] = 'site/manage_transactions';
$route['pi_transactions'] = 'site/pi_transactions';
$route['pi_product_investments'] = 'site/pi_product_investments';
$route['pi_manage_transactions'] = 'site/pi_manage_transactions';
$route['groups'] = 'site/groups';
$route['pi_buy'] = 'site/pi_buy';
$route['pi_sell'] = 'site/pi_sell';
$route['pi_general_ledger'] = 'site/pi_general_ledger';
$route['pi_reports'] = 'site/pi_reports';
$route['pi_settlements'] = 'site/pi_settlements';
$route['pi_manage_placements'] = 'site/pi_manage_placements';
$route['pi_placements'] = 'site/pi_placements';
$route['buy'] = 'site/buy';
$route['sell'] = 'site/sell';
$route['settlements'] = 'site/settlements';
$route['reports'] = 'site/reports';
$route['general_ledger'] = 'site/general_ledger';
$route['settings'] = 'site/settings';
$route['companies'] = 'site/companies';
$route['company_settings'] = 'site/company_settings';
$route['list_product_investments'] = 'site/list_product_investments';
$route['cis'] = 'site/cis';
$route['user_privileges(/:num)'] = 'site/user_privileges';
$route['user_group_privileges(/:num)'] = 'site/user_group_privileges';
$route['pensions'] = 'site/pensions';
$route['private_wealth'] = 'site/private_wealth';
$route['pensions_admin'] = 'site/pensions_admin';

/**
 * Product Investment Routes
 */
$route['pi_settings'] = 'site/pi_settings';



$route['settings'] = 'site/settings';
$route['translate_uri_dashes'] = FALSE;
