<?php
class Numbers_Words_Exception extends Exception {}
