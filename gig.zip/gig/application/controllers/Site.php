<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 *
 * User: root
 *
 * Date: 5/17/15
 *
 * Time: 10:22 PM
 *
 *  check this against other denominator difault values
 * for payments of product investments
 * $denominator = 364;

 */

require 'vendor/autoload.php';

use Carbon\Carbon;
require APPPATH.'third_party/tcpdf/tcpdf.php';
require APPPATH.'third_party/tcpdf/tcpdf_barcodes_1d.php';
require APPPATH.'third_party/tcpdf/tcpdf_barcodes_2d.php';

class Site extends CI_Controller
{
    public $user;
    public $user_church;
    public $path;
    public $template;
    public $main;
    public $assets;

    function __construct()
    {
        parent::__construct();
        $this->main = 'main/';
        $this->template = 'template/';
        $this->user =  array();

        $this->data['user'] = array();

        if($this->session->id)
        {
        $this->user =   $this->db->get_where('users',array('id'=>$this->session->id))->row();

        $this->data['user'] = $this->user;
        }
        $this->path = dirname(dirname(__DIR__)).'/assets/images';
        $this->data['assets']= base_url().'assets/';
        $this->data['app'] = $this->db->get('application_info')->row();
        $this->data['app_name'] = $this->data['app']->name;

    }

    function error()
    {

        $this->data['title']= "404 Error Page Not Found";
        $this->data['caption']= "404";
        $this->data['view'] = $this->main."error";
// new_gig       $this->load->view($this->main.'error',$this->data);
        $this->load->view($this->template.'skeleton',$this->data);
    }

    function index()
    {
        $this->load->view($this->main.'index',$this->data);
    }


    function blog()
    {
        $this->load->view($this->main.'blog',$this->data);
    }

    function new_gig()
    {
        $this->load->view($this->main.'newgig',$this->data);
    }
    

    function login()
    {
        $this->load->view($this->main.'login',$this->data);
    }

    function register()
    {
        $this->load->view($this->main.'register',$this->data);
    }

    function reset_password()
    {
        $this->load->view($this->main.'resetpassword',$this->data);
    }


    function logout()
    {
        $this->session->unset_userdata('id');
        redirect(base_url());
    }


    //Action Scripts

    function register_user()
    {
        $this->form_validation->set_rules('fname','First Name','required');
        $this->form_validation->set_rules('lname','Last Name','required');
        $this->form_validation->set_rules('email','Email ','required');
        $this->form_validation->set_rules('username','Username ','required');
        $this->form_validation->set_rules('password','Password','required');
        if($this->form_validation->run())
        {
            if($this->input->post('password_confirm',true) === $this->input->post('password',true))
            {
                $res = $this->db->get_where('users',array('email'=>$this->input->post('email',true)))->row();
                if(!$res)
                {
                $res = $this->db->get_where('users',array('username'=>$this->input->post('username',true)))->row();

                                $data = array();
            $rand = rand(100,99999);
            $confirm = time()*$rand;
            $data['first_name'] = $this->input->post('fname');
            $data['last_name'] = $this->input->post('lname');
            $data['username'] = $this->input->post('username');
            $data['password'] = $this->hasher->create_hash($this->input->post('password',true));
            $data['email'] = $this->input->post('email');
            $data['activation_code'] = md5($confirm);
            $data['user_type'] = 1;
            $this->db->insert('users',$data);
            $id = $this->db->insert_id();
            $rand1 = rand(10000,99999);
            $this->db->where('id',$id);
            $this->db->update('users',array('referal_code'=>$id.$rand1));
            $data = array();
            if($this->session->ref)
            {
                $data['user_id'] = $id;
                $data['reference_code_used'] = $this->session->ref;
                $this->db->insert('user_referals',$data);
                $this->session->unset_userdata('ref');
            }
            $message = "Hello ".$this->input->post('fname').", <br> We welcome you to GiGsHiP. <br/>Please click <a href='".base_url()."login?d5=".md5(time())."&&c=".$confirm."'>here</a> to confirm your account or <br> Copy and paste this link >> ".base_url()."login?d5=".md5(time())."&&c=".$confirm." << <br/> Thank You <br/> The GiGsHiP Team";
            $this->mod->sendEmail($this->input->post('email',true),$message,"GiGsHiP Account Activation Link");
            echo json_encode(array('status'=>'success'));                        


                }
                else
                {
            echo json_encode(array('status'=>'error','error'=>"Sorry Email Address Is Not Available"));            
                    
                }
            }
            else
            {
            echo json_encode(array('status'=>'error','error'=>"Kindly Confirm Your Password"));            
                
            }
        }
        else
        {
            echo json_encode(array('status'=>'error','error'=>validation_errors()));            

        }
        
    }

    function login_user()
    {
        $this->form_validation->set_rules('username','Username ','required');
        $this->form_validation->set_rules('password','Password','required');
        if($this->form_validation->run())
        {
            $res = $this->db->get_where('users',array('username'=>$this->input->post('username'),'activation_code'=>""))->row();
            if($res)
            {
                if($this->hasher->validate_password($this->input->post('password',true),$res->password))
                {
                    $this->session->set_userdata('id',$res->id);
                    echo json_encode(array('status'=>'success'));                        
                }
                else
                {
                    echo json_encode(array('status'=>'error','error'=>"Sorry Username And Password Combination Cannot Be Found,<br/> Did you forget your login details?"));            
                }

            }
            else
            {
            echo json_encode(array('status'=>'error','error'=>"Sorry Username And Password Combination Cannot Be Found,<br/> Did you forget your login details?"));            
                
            }
        }
        else
        {
            echo json_encode(array('status'=>'error','error'=>validation_errors()));            

        }
                
    }

    function recover_user()
    {
        $this->form_validation->set_rules('email','Email ','required');
        if($this->form_validation->run())
        {
            $res = $this->db->get_where('users',array('email'=>$this->input->post('email'),'activation_code'=>""))->row();
            if($res)
            {
            $rand = rand(100,99999);
            $confirm = time()*$rand;
            $this->db->where('id',$res->id);
            $this->db->update('users',array('password_recovery_code'=>$confirm));
            $message = "Hello ".$res->first_name.", We learnt you have forgotten your password don't worry, <br> . <br/>Please click <a href='".base_url()."reset_password?d5=".md5(time())."&&c=".$confirm."'>here</a> to reset your account password or <br> Copy and paste this link >> ".base_url()."reset_password?d5=".md5(time())."&&c=".$confirm." << <br/> Thank You <br/> The GiGsHiP Team";
            $this->mod->sendEmail($this->input->post('email',true),$message,"GiGsHiP Account Reset Link");
            echo json_encode(array('status'=>'success'));                        
            }
            else
            {
            echo json_encode(array('status'=>'error','error'=>"Sorry Email Address Cannot Be Found"));            
                
            }
        }
        else
        {
            echo json_encode(array('status'=>'error','error'=>validation_errors()));            

        }        
    }

    function reset_user()
    {
        
    }

}