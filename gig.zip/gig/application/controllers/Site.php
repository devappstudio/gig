<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 *
 * User: root
 *
 * Date: 5/17/15
 *
 * Time: 10:22 PM
 *
 *  check this against other denominator difault values
 * for payments of product investments
 * $denominator = 364;

 */

require 'vendor/autoload.php';

use Carbon\Carbon;
require APPPATH.'third_party/tcpdf/tcpdf.php';
require APPPATH.'third_party/tcpdf/tcpdf_barcodes_1d.php';
require APPPATH.'third_party/tcpdf/tcpdf_barcodes_2d.php';

class Site extends CI_Controller
{
    public $user;
    public $user_church;
    public $path;
    public $template;
    public $main;
    public $assets;

    function __construct()
    {
        parent::__construct();
        $this->main = 'main/';
        $this->template = 'template/';
        $this->user =  array();

        $this->data['user'] = array();

        if($this->session->id)
        {
        $this->user =   $this->db->get_where('users',array('id'=>$this->session->id))->row();

        $this->data['user'] = $this->user;
        }
        $this->path = dirname(dirname(__DIR__)).'/assets/images';
        $this->data['assets']= base_url().'assets/';
        $this->data['app'] = $this->db->get('application_info')->row();
        $this->data['app_name'] = $this->data['app']->name;

    }

    function error()
    {

        $this->data['title']= "404 Error Page Not Found";
        $this->data['caption']= "404";
        $this->data['view'] = $this->main."error";
// new_gig       $this->load->view($this->main.'error',$this->data);
        $this->load->view($this->template.'skeleton',$this->data);
    }

    function index()
    {
        $this->load->view($this->main.'index',$this->data);
    }


    function blog()
    {
        $this->load->view($this->main.'index',$this->data);
    }

    function new_gig()
    {
        $this->load->view($this->main.'index',$this->data);
    }

    function login()
    {
        $this->session->unset_userdata('id');
        redirect(base_url().'index.php/auth');
    }

    function logout()
    {
        $this->session->unset_userdata('id');
        redirect(base_url().'index.php/auth');
    }
}