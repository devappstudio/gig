-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 04, 2016 at 09:06 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `int`
--

-- --------------------------------------------------------

--
-- Table structure for table `application_info`
--

DROP TABLE IF EXISTS `application_info`;
CREATE TABLE `application_info` (
  `id` int(1) NOT NULL,
  `name` varchar(255) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `footer` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `application_info`
--

TRUNCATE TABLE `application_info`;
--
-- Dumping data for table `application_info`
--

INSERT INTO `application_info` (`id`, `name`, `file_name`, `version`, `footer`) VALUES
(1, 'InTalekt', '', '0.01 Alpha', '');

-- --------------------------------------------------------

--
-- Table structure for table `app_migration`
--

DROP TABLE IF EXISTS `app_migration`;
CREATE TABLE `app_migration` (
  `id` int(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `telephone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `fax` varchar(255) NOT NULL,
  `comments` varchar(255) NOT NULL,
  `posted_by` varchar(255) NOT NULL,
  `date_posted` varchar(255) NOT NULL,
  `active` int(2) NOT NULL,
  `t_bill_class` varchar(255) NOT NULL,
  `category_id` int(255) NOT NULL,
  `date_of_birth` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `nationality` varchar(255) NOT NULL,
  `proof` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `city_1` varchar(255) NOT NULL,
  `ssnit_contributor` varchar(255) NOT NULL,
  `mobile_number` varchar(255) NOT NULL,
  `marital_status` varchar(255) NOT NULL,
  `city_2` varchar(255) NOT NULL,
  `country_2` varchar(255) NOT NULL,
  `next_of_kin` varchar(255) NOT NULL,
  `next_of_kin_number` varchar(255) NOT NULL,
  `employment_status` varchar(255) NOT NULL,
  `kin_relationship` varchar(255) NOT NULL,
  `employer_name` varchar(255) NOT NULL,
  `job_level` varchar(255) NOT NULL,
  `kin_employment_status` varchar(255) NOT NULL,
  `salary_interval` varchar(255) NOT NULL,
  `no_dependants` int(25) NOT NULL,
  `annual_income` varchar(255) NOT NULL,
  `occupation` varchar(255) NOT NULL,
  `img_url` varchar(255) NOT NULL,
  `client_type_code` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `residential_number` varchar(255) NOT NULL,
  `id_number` varchar(255) NOT NULL,
  `years_of_work` varchar(255) NOT NULL,
  `branch_id` int(255) NOT NULL,
  `customer_type_id` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `app_migration`
--

TRUNCATE TABLE `app_migration`;
-- --------------------------------------------------------

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
CREATE TABLE `assets` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `id_company` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `assets`
--

TRUNCATE TABLE `assets`;
--
-- Dumping data for table `assets`
--

INSERT INTO `assets` (`id`, `name`, `id_company`) VALUES
(1, 'Fixed Income', 1),
(2, 'Other', 1),
(3, 'Fixed Deposits', 2),
(4, 'Bonds', 2),
(5, 'Fixed Term Instruments', 3),
(6, 'Bonds', 3),
(7, 'Treasury Bills', 2),
(8, 'FIXED TERM', 2);

-- --------------------------------------------------------

--
-- Table structure for table `asset_category`
--

DROP TABLE IF EXISTS `asset_category`;
CREATE TABLE `asset_category` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `denominator` varchar(255) NOT NULL,
  `id_company` int(255) NOT NULL,
  `id_asset` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `asset_category`
--

TRUNCATE TABLE `asset_category`;
--
-- Dumping data for table `asset_category`
--

INSERT INTO `asset_category` (`id`, `name`, `denominator`, `id_company`, `id_asset`) VALUES
(1, 'Government Bills', '389', 1, 1),
(2, 'Certificates Of Deposite', '365', 1, 1),
(3, 'Fixed Deposits', '365', 2, 3),
(4, 'Fixed Deposits', '365', 3, 5),
(5, 'Fixed Deposits', '182', 2, 3),
(6, 'Fixed Deposits', '91', 2, 3),
(7, 'FIXED DEPOSITS', '365', 2, 8),
(8, 'TREASURY BILLS', '365', 2, 8);

-- --------------------------------------------------------

--
-- Table structure for table `banks`
--

DROP TABLE IF EXISTS `banks`;
CREATE TABLE `banks` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `id_company` int(255) NOT NULL,
  `account_number` varchar(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `currency` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `banks`
--

TRUNCATE TABLE `banks`;
--
-- Dumping data for table `banks`
--

INSERT INTO `banks` (`id`, `name`, `id_company`, `account_number`, `branch`, `currency`) VALUES
(1, 'Zenith Bank', 1, '02356612', 'Achimota', ''),
(2, 'Royal Bank Int', 1, '514644', 'Achimota', ''),
(3, 'Royal Bank', 2, '---', '---', ''),
(4, 'Stanbic Bank', 2, '---', '---', ''),
(5, 'Fidelity Bank', 2, '---', '---', ''),
(6, 'Bank Of Africa', 2, '---', '---', ''),
(7, 'Test company bank account', 3, '123466889', 'fFimxl', 'GhC'),
(8, 'Royal Bank ', 3, '02356612', 'Achimota', 'USD');

-- --------------------------------------------------------

--
-- Table structure for table `banks_available`
--

DROP TABLE IF EXISTS `banks_available`;
CREATE TABLE `banks_available` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `id_company` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `banks_available`
--

TRUNCATE TABLE `banks_available`;
--
-- Dumping data for table `banks_available`
--

INSERT INTO `banks_available` (`id`, `name`, `remarks`, `id_company`) VALUES
(1, 'Royal Bank', 'Test huh', 1),
(2, ' Access Bank (Ghana) Limited', '', 2),
(3, ' ADB Bank Limited ', '', 2),
(4, ' Bank of Africa Ghana Ltd', '', 2),
(5, ' Bank of Baroda (Ghana) Limited', '', 2),
(6, ' Barclays Bank of Ghana Ltd', '', 2),
(7, 'Sahel Sahara Bank ', '', 2),
(8, ' Ecobank Ghana Limited ', '', 2),
(9, ' Energy Bank (Ghana) Ltd ', '', 2),
(10, ' FBN Bank Ghana Ltd', '', 2),
(11, ' Fidelity Bank Limited', '', 2),
(12, ' First Atlantic Bank Ltd', '', 2),
(13, ' Capital Bank Limited ', '', 2),
(14, ' First National Bank Ghana Ltd', '', 2),
(15, ' GCB Bank Limited', '', 2),
(16, ' GN Bank Limited', '', 2),
(17, ' Guaranty Trust Bank (Ghana) Limited', '', 2),
(18, ' HFC Bank Ghana Ltd', '', 2),
(19, ' National Investment Bank Ltd', '', 2),
(20, ' Prudential Bank Limited', '', 2),
(21, ' Societe General Ghana Limited', '', 2),
(22, ' Stanbic Bank Ghana Ltd', '', 2),
(23, ' Standard Chartered Bank (Ghana) Limited', '', 2),
(24, ' The Royal Bank Limited ', '', 2),
(25, ' UniBank Ghana Ltd', '', 2),
(26, ' United Bank for Africa (Ghana) Ltd', '', 2),
(27, ' Universal Merchant Bank (Ghana) Ltd', '', 2),
(28, ' UT Bank Limited', '', 2),
(29, ' Zenith Bank (Ghana) Limited', '', 2),
(30, ' Sovereign Bank Limited', '', 2),
(31, ' ARB Apex Bank Ltd', '', 2),
(32, 'Test Bank', '', 3);

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

DROP TABLE IF EXISTS `branches`;
CREATE TABLE `branches` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `remarks` text NOT NULL,
  `telephone` text NOT NULL,
  `details` text NOT NULL,
  `company_id` int(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `branches`
--

TRUNCATE TABLE `branches`;
--
-- Dumping data for table `branches`
--

INSERT INTO `branches` (`id`, `name`, `code`, `address`, `remarks`, `telephone`, `details`, `company_id`, `is_active`) VALUES
(1, 'Main Branch', '001', 'Laterbiokorshie', 'Non', '00233574389899', '', 1, 1),
(2, 'Accra Branch', '100', '-----', '', '0249419419', '', 2, 1),
(3, 'Main Accra', '001', '----', '----', '02625332666', '', 3, 1),
(4, 'TAKORADI', '300', '', '', '', '', 2, 1),
(5, 'KUMASI', '400', '', '', '', '', 2, 1),
(6, 'HQ', '001', '----', '**--', '------', '', 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `business_types`
--

DROP TABLE IF EXISTS `business_types`;
CREATE TABLE `business_types` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `business_types`
--

TRUNCATE TABLE `business_types`;
--
-- Dumping data for table `business_types`
--

INSERT INTO `business_types` (`id`, `name`) VALUES
(1, 'SOLE PROPRIETORSHIP'),
(2, ' 	PARTNERSHIP'),
(3, 'LIMTIED LIABILITY COMPANY');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
CREATE TABLE `clients` (
  `id` int(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `other_name` varchar(255) NOT NULL,
  `client_type_id` int(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `title_id` int(255) NOT NULL,
  `date_of_birth` varchar(255) NOT NULL,
  `country_id` int(255) NOT NULL,
  `postal_address` text NOT NULL,
  `city` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `id_card_type_id` int(255) NOT NULL,
  `id_card_number` varchar(255) NOT NULL,
  `occupation` varchar(255) NOT NULL,
  `marital_status` varchar(255) NOT NULL,
  `next_of_kin` varchar(255) NOT NULL,
  `next_of_kin_phone` varchar(255) NOT NULL,
  `signature_file` varchar(255) NOT NULL,
  `client_file` varchar(255) NOT NULL,
  `account_number` varchar(255) NOT NULL,
  `branch_id` int(255) NOT NULL,
  `company_id` int(255) NOT NULL,
  `date_created` varchar(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `nature_of_business` varchar(255) NOT NULL,
  `business_type_id` varchar(255) NOT NULL,
  `business_registration_number` varchar(255) NOT NULL,
  `business_name` varchar(255) NOT NULL,
  `date_incorporated` varchar(255) NOT NULL,
  `signatory_image_1` varchar(255) NOT NULL,
  `signatory_image_2` varchar(255) NOT NULL,
  `signature_image_1` varchar(255) NOT NULL,
  `signature_image_2` varchar(255) NOT NULL,
  `bank_name` varchar(255) NOT NULL,
  `bank_branch` varchar(255) NOT NULL,
  `bank_account_number` varchar(255) NOT NULL,
  `first_name_1` varchar(255) NOT NULL,
  `first_name_2` varchar(255) NOT NULL,
  `last_name_1` varchar(255) NOT NULL,
  `last_name_2` varchar(255) NOT NULL,
  `other_name_1` varchar(255) NOT NULL,
  `other_name_2` varchar(255) NOT NULL,
  `phone_1` varchar(255) NOT NULL,
  `phone_2` varchar(255) NOT NULL,
  `is_approved` int(1) NOT NULL DEFAULT '0',
  `id_card_type_id_1` int(255) NOT NULL,
  `id_card_number_1` varchar(255) NOT NULL,
  `id_card_type_id_2` int(255) NOT NULL,
  `id_card_number_2` varchar(255) NOT NULL,
  `approved_by` int(255) NOT NULL DEFAULT '0',
  `statement_frequency` varchar(255) NOT NULL DEFAULT '',
  `management_fees` varchar(255) NOT NULL,
  `residential_address` text NOT NULL,
  `company_telephone` varchar(255) NOT NULL DEFAULT '',
  `phone_alternative` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `clients`
--

TRUNCATE TABLE `clients`;
--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `first_name`, `last_name`, `other_name`, `client_type_id`, `gender`, `title_id`, `date_of_birth`, `country_id`, `postal_address`, `city`, `phone`, `email`, `id_card_type_id`, `id_card_number`, `occupation`, `marital_status`, `next_of_kin`, `next_of_kin_phone`, `signature_file`, `client_file`, `account_number`, `branch_id`, `company_id`, `date_created`, `user_id`, `nature_of_business`, `business_type_id`, `business_registration_number`, `business_name`, `date_incorporated`, `signatory_image_1`, `signatory_image_2`, `signature_image_1`, `signature_image_2`, `bank_name`, `bank_branch`, `bank_account_number`, `first_name_1`, `first_name_2`, `last_name_1`, `last_name_2`, `other_name_1`, `other_name_2`, `phone_1`, `phone_2`, `is_approved`, `id_card_type_id_1`, `id_card_number_1`, `id_card_type_id_2`, `id_card_number_2`, `approved_by`, `statement_frequency`, `management_fees`, `residential_address`, `company_telephone`, `phone_alternative`) VALUES
(1, 'Nunya', 'Afari', 'Jnr', 1, 'Male', 1, '04/06/86', 82, 'KN 143490', 'Accra', '+233267534489', 'afarri.nunya@live.com', 1, '73984932348', 'trader', 'Married', 'James Ansah', '+233267534489', '', '', '100000000001', 2, 2, '1469109014', 11, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 11, '2', '', 'North Legon', '', ''),
(2, '', '', '', 2, '', 0, '', 0, 'BOX AA 225', 'ACCRA', '+233057383986', 'leonard.nyakpo@brooksmoney.com', 0, '', '', '', '', '', '', '', '100000000002', 2, 2, '1469211199', 15, 'POLITICS', '3', '125122', 'KOFI WAYO LIMITED', '06/27/2000', 'default.jpg', 'default.jpg', 'default.jpg', 'default.jpg', 'Royal Bank', 'East Legon', '12121212121', 'Wayo', 'Rose', 'Kojogah', 'Bonsi', 'Kofi', '', '+233057383986', '+233', 1, 2, '122121', 1, '125422', 11, '2', '1252', '', '', ''),
(3, 'Nunya', 'Afari', 'Kwame', 1, 'Female', 1, '04/06/1986', 82, 'kn 1349', 'accra', '+233267534489', 'afari.nunya@ live.com', 2, '3423423', 'banker', 'Single', 'james ansah', '+233267534489', '', '', '001000000001', 3, 3, '1469311947', 16, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 16, '1', '', 'dansoman', '', ''),
(4, 'james', 'asare', '', 1, 'Male', 1, '07/27/2016', 82, '345435', 'accra', '+233267534489', 'afari.nunya@live.com', 1, '34534543', 'accountant', 'Single', 'afari', '+233267534489', '', '', '001000000002', 3, 3, '1469705374', 16, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 16, '1', '', 'accra', '', ''),
(5, 'Isaac', 'Darko', '', 1, 'Male', 1, '08/02/1984', 82, 'Box Lt 290 Laterbioshie Accra', 'Accra', '+233262141279', 'isaacbremang@gmail.com', 2, 'H52235G', 'Programmer', 'Single', '---', '+233262141274', '', '', '001000000003', 3, 3, '1469796388', 16, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 16, '1', '', 'A48A/2B Candle Link Laterbiokorshie Accra', '', ''),
(6, 'PROSPER', 'DELEKA', '', 1, 'Male', 1, '08/01/2016', 82, 'BOX AF 2973 ADENTA', 'ACCRA', '+233273458516', 'delekaprosper@yahoo.com', 1, '123456', 'BANKING', 'Married', 'DELEKA DELEKA', '+233234567', '', '', '100000000003', 2, 2, '1470396321', 8, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 4, '2', '', 'ACCRA', '', ''),
(7, 'Sherel', 'David', '', 1, 'Female', 2, '06/01/1976', 82, 'P. O. Box 1103', 'ACCRA', '+233245860013', '', 1, '11006789', 'Trader', 'Single', 'Samuel David', '+233240000987', '', '', '100000000004', 2, 2, '1470847971', 4, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 4, '1', '', 'Drake Road, Spintex, Accra', '', ''),
(8, 'George ', 'Nkansah', '', 1, 'Male', 1, '08/01/2016', 82, 'Box Lt 290', '', '+233262141279', '', 2, 'H52235G', 'Programmer', 'Single', 'kwame kudjoe', '+233262542365', 'George__1470913942_signature_Nkansah.jpeg', 'George__1470913939_passport_Nkansah.png', '100000000005', 2, 2, '1470913943', 11, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 7, '1', '', 'A48A/2B Candle Link Laterbiokorshie Accra', '', ''),
(9, 'Aura', 'Danso', 'Ama', 1, 'Female', 3, '08/10/1976', 82, 'P.O.BOX 923 Accra', 'Accra', '+233249907084', 'ewurama.danso@brooksmoney.com', 1, 'G1238765', 'Business Woman', 'Single', 'nana', '+233253565243', 'Aura_1471343793_signature_Danso.jpg', 'Aura_1471343793_passport_Danso.jpg', '100000000006', 2, 2, '1471343793', 18, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 7, '2', '', 'ODOKOR', '', ''),
(10, 'YAW', 'BOATENG', 'OBIRI', 1, 'Male', 1, '08/18/1990', 82, 'P.O.BOX 3567', 'KUMASI', '+233269009275', 'ibrahim.mohammed@brooksmoney.com', 2, 'G1234598', 'Electrical Engineer', 'Married', 'Kwadwo Mensah', '+233345682929', 'YAW_1471344939_signature_BOATENG.jpg', 'YAW_1471344939_passport_BOATENG.jpg', '100000000007', 2, 2, '1471344939', 18, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 20, '1', '', 'EAST LEGON', '', ''),
(11, 'Ewuramaa', 'Danso', '', 1, 'Female', 3, '03/01/1980', 82, 'P.o.box an12', 'Accra', '+233249907084', 'ewurama.danso@brooksmoney.com', 1, '234563885848', 'Customer Service Executive', 'Single', 'John Danso', '+233249907084', 'Ewuramaa_1471345086_signature_Danso.jpg', 'Ewuramaa_1471345086_passport_Danso.jpg', '100000000008', 2, 2, '1471345087', 20, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 20, '1', '', '12/20', '', ''),
(12, 'Lucas', 'Ahiable', 'Worlanyo', 1, 'Male', 1, '12/12/1986', 82, 'P.o.box an20', 'Accra', '+233249334996', 'lucas.ahiable@brooksmoney.com', 2, '34486858', 'Customer Service Executive', 'Single', 'Nutifafa Worlanyo Ahiable', '+233249334996', 'Lucas_1471345673_signature_Ahiable.jpg', 'Lucas_1471345673_passport_Ahiable.jpg', '100000000009', 2, 2, '1471345673', 20, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 7, '2', '', '23/344', '', ''),
(13, 'LUCAS', 'WORLANYO', 'XOLA', 1, 'Male', 1, '08/30/1992', 82, 'P.O.BOX 2343', 'ACCRA', '+233249334996', 'lucas.ahiable@brooksmoney.com', 2, 'G4709875', 'IT CONSULTANT', 'Single', 'XOLA AGBEVE', '+233093747466', 'LUCAS_1471345776_signature_WORLANYO.jpg', 'LUCAS_1471345774_passport_WORLANYO.jpg', '100000000010', 2, 2, '1471345778', 18, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 7, '1', '', 'AIRPORT', '', ''),
(14, 'GLORIA', 'DANKYI', 'AFIA', 1, 'Female', 2, '08/23/1992', 82, 'P.O Box 250, Accra North', 'Accra', '+233242160462', 'eunice.ofosu-dankyi@brooksmoney.com', 2, 'G7897545', 'Accounts Executive', 'Married', 'Eunice Koree', '+233368853999', 'GLORIA_1471346193_signature_DANKYI.jpg', 'GLORIA_1471346191_passport_DANKYI.jpg', '100000000011', 2, 2, '1471346196', 18, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 20, '1', '', 'NORTH LEGON,897', '', ''),
(15, 'EMMANUEL', 'DANSO-BOAFO', '', 1, 'Male', 1, '02/07/1980', 82, 'Box k230 Asafo Kumasi', 'Kumasi', '+233209000500', ' E: emmanuel.danso-boafo@brooksmoney.com', 1, '236345556', 'Research Analyst', 'Married', ' kelvin DANSO-BOAFO', '+233209000500', 'EMMANUEL_1471346275_signature_DANSO-BOAFO.jpg', 'EMMANUEL_1471346275_passport_DANSO-BOAFO.jpg', '100000000012', 2, 2, '1471346275', 20, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 7, '1', '', 'k46/244 Asafo Kumasi', '', ''),
(16, 'Dorcas', 'Aboagye', 'Kokoi', 1, 'Female', 2, '08/09/1986', 82, 'P.O Box 4358, Accra North', '', '+233207507572', 'florence.kokoi@broooksmoney.com', 2, 'G0986537', 'Analyst', 'Married', 'Kofi Asare', '+233234567884', 'Dorcas_1471346938_signature_Aboagye.jpg', 'Dorcas_1471346938_passport_Aboagye.jpg', '100000000013', 2, 2, '1471346938', 18, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 3, '1', '', 'East Airport', '', ''),
(17, 'Nana', 'Osei Tutu', '', 1, 'Male', 1, '03/08/1978', 82, 'box k566 Asafo Kumasi', 'Kumasi', '+233273458543', 'nana.oseitutu@brooksmoney.com', 1, '3845786578', 'Relationship Manager', 'Married', 'Agyeman Osei-Tutu', '+233273458543', 'Nana_1471347414_signature_Osei_Tutu.jpg', 'Nana_1471347414_passport_Osei_Tutu.jpg', '100000000014', 2, 2, '1471347428', 20, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 7, '2', '', 'k12/0909 Kumasi', '', ''),
(18, 'IBRAHIM', 'MOHAMMED-LANSA ', '', 1, 'Male', 1, '12/12/1980', 82, 'Box  Es459 East legon, Accra', 'Accra', '+233269009275', ' ibrahim.mohammed@brooksmoney.com', 1, '456895848484', 'Business Systems Administrator', 'Single', 'Abdul MOHAMMED-LANSA', '+233269009275', 'IBRAHIM_1471348027_signature_MOHAMMED-LANSA_.jpg', 'IBRAHIM_1471348027_passport_MOHAMMED-LANSA_.jpg', '100000000015', 2, 2, '1471348028', 20, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 7, '1', '', '8676/59 EastLegon Accra', '', ''),
(19, 'SUMAYA', 'MUBASHIRU', '', 1, 'Female', 2, '12/12/1981', 82, 'Box M455 Madina, Accra', 'Accra', '+233273458517', 'sumaya.mubashiru@brooksmoney.com', 2, '78965778899', 'Head, Sales & Marketing', 'Married', 'Kadija MUBASHIRU', '+233273458517', 'SUMAYA_1471348415_signature_MUBASHIRU.jpg', 'SUMAYA_1471348415_passport_MUBASHIRU.jpg', '100000000016', 2, 2, '1471348417', 20, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 7, '1', '', '54/09 Madina, Accra', '', ''),
(20, 'SUMAYA', 'MUBASHIRU', '', 1, 'Female', 2, '12/12/1981', 82, 'Box M455 Madina, Accra', 'Accra', '+233273458517', 'sumaya.mubashiru@brooksmoney.com', 2, '78965778899', 'Head, Sales & Marketing', 'Married', 'Kadija MUBASHIRU', '+233273458517', 'SUMAYA_1471348424_signature_MUBASHIRU.jpg', 'SUMAYA_1471348424_passport_MUBASHIRU.jpg', '100000000017', 2, 2, '1471348424', 20, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 7, '1', '', '54/09 Madina, Accra', '', ''),
(21, 'Patience', 'Feda', '', 1, 'Male', 1, '01/10/1980', 82, 'Box Ds988 Dansoman, Accra', 'Accra', '+233273458522', 'patience.feda@brooksmoney.com', 2, '9089897876', 'TREASURY', 'Single', 'Elorm Feda', '+233273458522', 'Patience_1471348902_signature_Feda.jpg', 'Patience_1471348902_passport_Feda.jpg', '100000000018', 2, 2, '1471348903', 20, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 7, '2', '', '78/94', '', ''),
(22, 'Kofi ', 'Nyantakyi', 'Ameyaw', 1, 'Male', 1, '08/01/1979', 82, 'P.O Box 9734, Accra North', 'Tamale', '+233265199081', 'godwin.akowuah@brooksmoney.com', 2, 'G6547650', 'Architect', 'Married', 'Asare Botwe', '+233939847646', 'Kofi__1471349079_signature_Nyantakyi.jpg', 'Kofi__1471349077_passport_Nyantakyi.jpg', '100000000019', 2, 2, '1471349081', 18, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 7, '1', '', 'Regimanuel Estates', '', ''),
(23, '', '', '', 2, '', 0, '', 0, 'P.O Box 250, Accra North', 'Accra', '+233249907084', 'pomahdan@gmail.com', 0, '', '', '', '', '', '', '', '100000000020', 2, 2, '1471350311', 18, 'CATERING SERVICES', '1', 'CO7689', 'ROYALE TASTY CATERING SERVICES', '08/04/1985', 'Pomaa_1471350291_passport_Takyi.jpg', 'Lambert_1471350306_passport_Adomako.jpg', 'Pomaa_1471350291_signature_Takyi.jpg', 'Lambert_1471350309_signature_Adomako.jpg', 'Prudential Bank', 'NIA Branch', '1308997634537', 'Pomaa', 'Lambert', 'Takyi', 'Adomako', 'Edna', '', '+233249907084', '+233249334996', 1, 2, 'G1234564', 2, 'G9809809', 7, '2', '2', '', '024', ''),
(24, '', '', '', 2, '', 0, '', 0, 'P.O Box 250, Accra North', 'Accra', '+233249907084', 'pomahdan@gmail.com', 0, '', '', '', '', '', '', '', '100000000021', 2, 2, '1471350319', 18, 'CATERING SERVICES', '1', '67654', 'ROYALE TASTY CATERING SERVICES', '08/04/1985', 'Pomaa_1471350319_passport_Takyi.jpg', '', 'Pomaa_1471350319_signature_Takyi.jpg', '', 'Prudential Bank', 'NIA Branch', '1308997634537', 'Pomaa', 'Lambert', 'Takyi', 'Adomako', 'Edna', '', '+233249907084', '+233249334996', 1, 2, 'G1234564', 2, 'G9809809', 7, '2', '2', '', '024', ''),
(25, ' PROSPER', 'DELEKA', ' ACHOLO', 1, 'Male', 1, '12/03/1975', 82, 'Box T45 Tamale', 'Tamale', '+233273458516', ' prosper.deleka@brooksmoney.com', 2, '5689076890769', 'Portfolio Officer', 'Married', 'John Deleka', '+233273458516', '_PROSPER_1471355206_signature_DELEKA.jpg', '_PROSPER_1471355206_passport_DELEKA.jpg', '100000000022', 2, 2, '1471355207', 20, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 7, '2', '', '25/98', '', ''),
(26, ' Anthony ', 'Dapaah ', '', 1, 'Male', 1, '03/05/1975', 82, 'Boxk66 Kumasi', 'Kumasi', '+233574315454', '  tony.dapaah@brooksmoney.com', 1, '6767889890', 'Relationship Manager', 'Single', 'Osei Dapaah', '+233574315454', '_Anthony__1471355948_signature_Dapaah_.jpg', '_Anthony__1471355948_passport_Dapaah_.jpg', '100000000023', 2, 2, '1471355948', 20, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 7, '1', '', '776/767', '', ''),
(27, 'ibrahim', 'mohammed-lansa', '', 1, 'Male', 1, '08/30/1990', 82, 'p.o box 458', 'Accra', '+233269009275', 'ibrahim.mohammed@brooksmoney.com', 2, 'g0102569', 'bsa', 'Single', 'ivy', '+233240216514', 'ibrahim_1471366613_signature_mohammed-lansa.jpg', 'ibrahim_1471366611_passport_mohammed-lansa.jpg', '000000000001', 0, 2, '1471366614', 3, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 3, '1', '', 'Accra', '', ''),
(28, 'Mariam ', ' Barnor  ', 'Norley', 1, 'Female', 2, '08/01/1980', 82, 'Box  Os123', 'Accra', '+233574315446', 'mariam.norley-barnor@brooksmoney.com ', 1, '21233445456', 'Administrative assistant', 'Married', ' Adom ', '+233574315446', 'Mariam__1471520469_signature__Barnor__.jpg', 'Mariam__1471520469_passport__Barnor__.jpg', '100000000024', 2, 2, '1471520469', 20, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 7, '2', '', '23/86 Osu, Accra', '', ''),
(29, ' PATIENCE', ' FEDA ', '', 1, 'Male', 1, '08/03/1982', 82, 'Box Ds645 Dansoman, Accra', 'Accra', '+233273458522', ' patience.feda@brooksmoney.com', 2, '8978894589', 'TREASURY', 'Single', 'Etornam Feda', '+233273458522', '_PATIENCE_1471521024_signature__FEDA_.jpg', '_PATIENCE_1471521024_passport__FEDA_.jpg', '100000000025', 2, 2, '1471521024', 20, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 7, '1', '', '12/57', '', ''),
(30, 'John', 'Titiati', 'Mensah', 1, 'Male', 1, '07/01/1979', 82, 'box M320 Madina, Accra', 'A', '+233243126411', 'John.titiati@brooksmoney.com', 2, '76789898989', 'Banker', 'Married', 'Maxwell Titiati', '+233243126411', 'John_1471596982_signature_Titiati.jpg', 'John_1471596981_passport_Titiati.jpg', '100000000026', 2, 2, '1471596982', 20, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 7, '1', '', '122/349 Madina', '', ''),
(31, 'John', 'Titiati', 'Mensah', 1, 'Male', 1, '07/01/1979', 82, 'box M320 Madina, Accra', 'Accra', '+233243126411', 'John.titiati@brooksmoney.com', 2, '76789898989', 'Banker', 'Married', 'Maxwell Titiati', '+233243126411', 'John_1471596995_signature_Titiati.jpg', 'John_1471596995_passport_Titiati.jpg', '100000000027', 2, 2, '1471596995', 20, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 7, '1', '', '122/349 Madina', '', ''),
(32, '', '', '', 2, '', 0, '', 0, 'BOX TM234', 'TEMA', '+233249334996', '', 0, '', '', '', '', '', '', '', '100000000028', 2, 2, '1471852284', 20, 'IT SERVICES', '2', 'GR 22334445', 'TOP  CONSULT', '08/02/2016', 'LUCAS_1471852281_passport__AHIABLE.jpg', 'PROSPER_1471852283_passport_DELEKA.jpg', 'LUCAS_1471852282_signature__AHIABLE.jpg', 'PROSPER_1471852283_signature_DELEKA.jpg', 'ROYAL BANK', 'ACCRA MAIN', '1110004324568', 'LUCAS', 'PROSPER', ' AHIABLE', 'DELEKA', 'WORLANYO', '', '+233249334996', '+233273458516', 1, 1, '076896U896896', 2, '78478578688956', 7, '2', '', '', '249334996', ''),
(33, '', '', '', 2, '', 0, '', 0, 'BOX AN578', 'ACRCRA', '+233243126411', 'donewell@gmail.com', 0, '', '', '', '', '', '', '', '100000000029', 2, 2, '1471852970', 20, 'AUTOMOBILE', '1', 'GR976959669', 'DONEWELL GH', '08/01/2016', 'EMMANUEL_1471852970_passport__DANSO-BOAFO.jpg', 'IBRAHIM_1471852970_passport__MOHAMMED-LANSA_.jpg', 'EMMANUEL_1471852970_signature__DANSO-BOAFO.jpg', 'IBRAHIM_1471852970_signature__MOHAMMED-LANSA_.jpg', 'UNIBANK', 'EAST LEGON', '1110056789034', 'EMMANUEL', 'IBRAHIM', ' DANSO-BOAFO', ' MOHAMMED-LANSA ', '', '', '+233209000500', '+233269009275', 1, 2, '90968089', 3, '45789568968', 7, '1', '', '', '302 550 133', ''),
(34, '', '', '', 2, '', 0, '', 0, 'BOX SK3445', 'TEMA', '+233249334996', '', 0, '', '', '', '', '', '', '', '100000000030', 2, 2, '1471861994', 20, 'FOOD', '2', 'GR88798', 'ROYAL  FOOD SERVICES', '08/03/2012', 'JERRY_1471861991_passport_ADAMS.jpg', 'GEYLORD_1471861993_passport_COFFIE.jpg', 'JERRY_1471861991_signature_ADAMS.jpg', 'GEYLORD_1471861993_signature_COFFIE.jpg', 'FIDELITY BANK ', 'TEMA', '10104566666', 'JERRY', 'GEYLORD', 'ADAMS', 'COFFIE', 'KOBBY', '', '+233249334996', '+233249334996', 1, 2, '768945845', 3, '8989778765', 7, '1', '', '', '249334996', ''),
(35, '', '', '', 2, '', 0, '', 0, 'BOX SK3445', 'TEMA', '+233249334996', '', 0, '', '', '', '', '', '', '', '100000000031', 2, 2, '1471862001', 20, 'FOOD', '2', 'GR88798', 'ROYAL  FOOD SERVICES', '08/03/2012', 'JERRY_1471862001_passport_ADAMS.jpg', 'GEYLORD_1471862001_passport_COFFIE.jpg', 'JERRY_1471862001_signature_ADAMS.jpg', '', 'FIDELITY BANK ', 'TEMA', '10104566666', 'JERRY', 'GEYLORD', 'ADAMS', 'COFFIE', 'KOBBY', '', '+233249334996', '+233249334996', 1, 2, '768945845', 3, '8989778765', 7, '1', '', '', '249334996', ''),
(36, '', '', '', 3, '', 0, '', 82, 'BOX OS6544', 'ACRCRA', '+233249334996', '', 0, '', '', '', '', '', '', '', '000000000002', 0, 0, '1471862936', 20, '', '', '', 'MR/MRS JOHN JERRY', '', 'JOHN__1471862936_passport_JERRY.jpg', 'JOYCE__1471862936_passport_JOHN.jpg', 'JOHN__1471862936_signature_JERRY.jpg', 'JOYCE__1471862936_signature_JOHN.jpg', 'GN BANK', 'CIRCLE ACCRA', '00156476788', 'JOHN ', 'JOYCE ', 'JERRY', 'JOHN', '', '', '+233249334996', '+233249334996', 0, 2, '23345672', 1, '54645355', 0, '1', '', '', '', ''),
(37, '', '', '', 3, '', 0, '', 82, 'BOX OS6544', 'ACRCRA', '+233249334996', '', 0, '', '', '', '', '', '', '', '000000000003', 0, 0, '1471863029', 20, '', '', '', 'MR/MRS JOHN JERRY', '', 'JOHN__1471863026_passport_JERRY.jpg', 'JOYCE__1471863028_passport_JOHN.jpg', 'JOHN__1471863026_signature_JERRY.jpg', 'JOYCE__1471863028_signature_JOHN.jpg', 'GN BANK', 'CIRCLE ACCRA', '00156476788', 'JOHN ', 'JOYCE ', 'JERRY', 'JOHN', '', '', '+233249334996', '+233249334996', 0, 2, '23345672', 1, '54645355', 0, '1', '', '', '', ''),
(38, '', '', '', 3, '', 0, '', 82, 'BOX OS6544', 'ACRCRA', '+233249334996', '', 0, '', '', '', '', '', '', '', '000000000004', 0, 0, '1471863050', 20, '', '', '', 'MR/MRS JOHN JERRY', '', 'JOHN__1471863050_passport_JERRY.jpg', 'JOYCE__1471863050_passport_JOHN.jpg', 'JOHN__1471863050_signature_JERRY.jpg', 'JOYCE__1471863050_signature_JOHN.jpg', 'GN BANK', 'CIRCLE ACCRA', '00156476788', 'JOHN ', 'JOYCE ', 'JERRY', 'JOHN', '', '', '+233249334996', '+233249334996', 0, 2, '23345672', 1, '54645355', 0, '1', '', '', '', ''),
(39, '', '', '', 3, '', 0, '', 82, 'BOX OS6544', 'ACRCRA', '+233249334996', '', 0, '', '', '', '', '', '', '', '000000000005', 0, 0, '1471863076', 20, '', '', '', 'MR/MRS JOHN JERRY', '', 'JOHN__1471863076_passport_JERRY.jpg', 'JOYCE__1471863076_passport_JOHN.jpg', 'JOHN__1471863076_signature_JERRY.jpg', 'JOYCE__1471863076_signature_JOHN.jpg', 'GN BANK', 'CIRCLE ACCRA', '00156476788', 'JOHN ', 'JOYCE ', 'JERRY', 'JOHN', '', '', '+233249334996', '+233249334996', 0, 2, '23345672', 1, '54645355', 0, '1', '', '', '', ''),
(40, '', '', '', 3, '', 0, '', 82, 'BOX OS6544', 'ACRCRA', '+233249334996', '', 0, '', '', '', '', '', '', '', '000000000006', 0, 0, '1471863099', 20, '', '', '', 'MR/MRS JOHN JERRY', '', 'JOHN__1471863099_passport_JERRY.jpg', 'JOYCE__1471863099_passport_JOHN.jpg', 'JOHN__1471863099_signature_JERRY.jpg', 'JOYCE__1471863099_signature_JOHN.jpg', 'GN BANK', 'CIRCLE ACCRA', '00156476788', 'JOHN ', 'JOYCE ', 'JERRY', 'JOHN', '', '', '+233249334996', '+233249334996', 0, 2, '23345672', 1, '54645355', 0, '1', '', '', '', ''),
(41, '', '', '', 3, '', 0, '', 82, 'BOX OS6544', 'ACRCRA', '+233249334996', '', 0, '', '', '', '', '', '', '', '000000000007', 0, 0, '1471863163', 20, '', '', '', 'MR/MRS JOHN JERRY', '', 'JOHN__1471863163_passport_JERRY.jpg', 'JOYCE__1471863163_passport_JOHN.jpg', 'JOHN__1471863163_signature_JERRY.jpg', 'JOYCE__1471863163_signature_JOHN.jpg', 'GN BANK', 'CIRCLE ACCRA', '00156476788', 'JOHN ', 'JOYCE ', 'JERRY', 'JOHN', '', '', '+233249334996', '+233249334996', 0, 2, '23345672', 1, '54645355', 0, '1', '', '', '', ''),
(42, '', '', '', 3, '', 0, '', 82, 'BOX OS6544', 'ACRCRA', '+233249334996', '', 0, '', '', '', '', '', '', '', '000000000008', 0, 0, '1471863224', 20, '', '', '', 'MR/MRS JOHN JERRY', '', 'JOHN__1471863222_passport_JERRY.jpg', 'JOYCE__1471863223_passport_JOHN.jpg', 'JOHN__1471863222_signature_JERRY.jpg', 'JOYCE__1471863223_signature_JOHN.jpg', 'GN BANK', 'CIRCLE ACCRA', '00156476788', 'JOHN ', 'JOYCE ', 'JERRY', 'JOHN', '', '', '+233249334996', '+233249334996', 0, 2, '23345672', 1, '54645355', 0, '1', '', '', '', ''),
(43, '', '', '', 3, '', 0, '', 82, 'BOX OS6544', 'ACRCRA', '+233249334996', '', 0, '', '', '', '', '', '', '', '000000000009', 0, 0, '1471863242', 20, '', '', '', 'MR/MRS JOHN JERRY', '', 'JOHN__1471863242_passport_JERRY.jpg', 'JOYCE__1471863242_passport_JOHN.jpg', 'JOHN__1471863242_signature_JERRY.jpg', 'JOYCE__1471863242_signature_JOHN.jpg', 'GN BANK', 'CIRCLE ACCRA', '00156476788', 'JOHN ', 'JOYCE ', 'JERRY', 'JOHN', '', '', '+233249334996', '+233249334996', 0, 2, '23345672', 1, '54645355', 0, '1', '', '', '', ''),
(44, '', '', '', 3, '', 0, '', 82, 'BOX OS6544', 'ACRCRA', '+233249334996', '', 0, '', '', '', '', '', '', '', '000000000010', 0, 0, '1471863297', 20, '', '', '', 'MR/MRS JOHN JERRY', '', 'JOHN__1471863297_passport_JERRY.jpg', 'JOYCE__1471863297_passport_JOHN.jpg', 'JOHN__1471863297_signature_JERRY.jpg', 'JOYCE__1471863297_signature_JOHN.jpg', 'GN BANK', 'CIRCLE ACCRA', '00156476788', 'JOHN ', 'JOYCE ', 'JERRY', 'JOHN', '', '', '+233249334996', '+233249334996', 0, 2, '23345672', 1, '54645355', 0, '1', '', '', '', ''),
(45, '', '', '', 3, '', 0, '', 82, 'BOX OS6544', 'ACRCRA', '+233249334996', '', 0, '', '', '', '', '', '', '', '000000000011', 0, 0, '1471863311', 20, '', '', '', 'MR/MRS JOHN JERRY', '', 'JOHN__1471863311_passport_JERRY.jpg', 'JOYCE__1471863311_passport_JOHN.jpg', 'JOHN__1471863311_signature_JERRY.jpg', 'JOYCE__1471863311_signature_JOHN.jpg', 'GN BANK', 'CIRCLE ACCRA', '00156476788', 'JOHN ', 'JOYCE ', 'JERRY', 'JOHN', '', '', '+233249334996', '+233249334996', 0, 2, '23345672', 1, '54645355', 0, '1', '', '', '', ''),
(46, '', '', '', 3, '', 0, '', 82, 'BOX OS6544', 'ACRCRA', '+233249334996', '', 0, '', '', '', '', '', '', '', '000000000012', 0, 0, '1471863354', 20, '', '', '', 'MR/MRS JOHN JERRY', '', 'JOHN__1471863351_passport_JERRY.jpg', 'JOYCE__1471863352_passport_JOHN.jpg', 'JOHN__1471863351_signature_JERRY.jpg', 'JOYCE__1471863352_signature_JOHN.jpg', 'GN BANK', 'CIRCLE ACCRA', '00156476788', 'JOHN ', 'JOYCE ', 'JERRY', 'JOHN', '', '', '+233249334996', '+233249334996', 0, 2, '23345672', 1, '54645355', 0, '1', '', '', '', ''),
(47, '', '', '', 3, '', 0, '', 82, 'BOX OS6544', 'ACRCRA', '+233249334996', '', 0, '', '', '', '', '', '', '', '000000000013', 0, 0, '1471863443', 20, '', '', '', 'MR/MRS JOHN JERRY', '', 'JOHN__1471863443_passport_JERRY.jpg', 'JOYCE__1471863443_passport_JOHN.jpg', 'JOHN__1471863443_signature_JERRY.jpg', 'JOYCE__1471863443_signature_JOHN.jpg', 'GN BANK', 'CIRCLE ACCRA', '00156476788', 'JOHN ', 'JOYCE ', 'JERRY', 'JOHN', '', '', '+233249334996', '+233249334996', 0, 2, '23345672', 1, '54645355', 0, '1', '', '', '', ''),
(48, '', '', '', 3, '', 0, '', 82, 'BOX OS6544', 'ACRCRA', '+233249334996', '', 0, '', '', '', '', '', '', '', '000000000014', 0, 0, '1471863766', 20, '', '', '', 'MR/MRS JOHN JERRY', '', 'JOHN__1471863766_passport_JERRY.jpg', 'JOYCE__1471863766_passport_JOHN.jpg', 'JOHN__1471863766_signature_JERRY.jpg', 'JOYCE__1471863766_signature_JOHN.jpg', 'GN BANK', 'CIRCLE ACCRA', '00156476788', 'JOHN ', 'JOYCE ', 'JERRY', 'JOHN', '', '', '+233249334996', '+233249334996', 0, 2, '23345672', 1, '54645355', 0, '1', '', '', '', ''),
(49, '', '', '', 3, '', 0, '', 82, 'BOX OS6544', 'ACRCRA', '+233249334996', '', 0, '', '', '', '', '', '', '', '000000000015', 0, 0, '1471866376', 20, '', '', '', 'MR/MRS JOHN JERRY', '', 'JOHN__1471866376_passport_JERRY.jpg', 'JOYCE__1471866376_passport_JOHN.jpg', 'JOHN__1471866376_signature_JERRY.jpg', 'JOYCE__1471866376_signature_JOHN.jpg', 'GN BANK', 'CIRCLE ACCRA', '00156476788', 'JOHN ', 'JOYCE ', 'JERRY', 'JOHN', '', '', '+233249334996', '+233249334996', 0, 2, '23345672', 1, '54645355', 0, '1', '', '', '', ''),
(50, '', '', '', 3, '', 0, '', 82, 'BOX OS6544', 'ACRCRA', '+233249334996', '', 0, '', '', '', '', '', '', '', '000000000016', 0, 0, '1471866417', 20, '', '', '', 'MR/MRS JOHN JERRY', '', 'JOHN__1471866417_passport_JERRY.jpg', 'JOYCE__1471866417_passport_JOHN.jpg', 'JOHN__1471866417_signature_JERRY.jpg', 'JOYCE__1471866417_signature_JOHN.jpg', 'GN BANK', 'CIRCLE ACCRA', '00156476788', 'JOHN ', 'JOYCE ', 'JERRY', 'JOHN', '', '', '+233249334996', '+233249334996', 0, 2, '23345672', 1, '54645355', 0, '1', '', '', '', ''),
(51, '', '', '', 3, '', 0, '', 82, 'BOX OS6544', 'ACRCRA', '+233249334996', '', 0, '', '', '', '', '', '', '', '000000000017', 0, 0, '1471866428', 20, '', '', '', 'MR/MRS JOHN JERRY', '', 'JOHN__1471866428_passport_JERRY.jpg', 'JOYCE__1471866428_passport_JOHN.jpg', 'JOHN__1471866428_signature_JERRY.jpg', 'JOYCE__1471866428_signature_JOHN.jpg', 'GN BANK', 'CIRCLE ACCRA', '00156476788', 'JOHN ', 'JOYCE ', 'JERRY', 'JOHN', '', '', '+233249334996', '+233249334996', 0, 2, '23345672', 1, '54645355', 0, '1', '', '', '', ''),
(52, '', '', '', 3, '', 0, '', 82, 'BOX OS6544', 'ACRCRA', '+233249334996', '', 0, '', '', '', '', '', '', '', '000000000018', 0, 0, '1471866443', 20, '', '', '', 'MR/MRS JOHN JERRY', '', 'JOHN__1471866443_passport_JERRY.jpg', 'JOYCE__1471866443_passport_JOHN.jpg', 'JOHN__1471866443_signature_JERRY.jpg', 'JOYCE__1471866443_signature_JOHN.jpg', 'GN BANK', 'CIRCLE ACCRA', '00156476788', 'JOHN ', 'JOYCE ', 'JERRY', 'JOHN', '', '', '+233249334996', '+233249334996', 0, 2, '23345672', 1, '54645355', 0, '1', '', '', '', ''),
(53, '', '', '', 3, '', 0, '', 82, 'BOX OS6544', 'ACRCRA', '+233249334996', '', 0, '', '', '', '', '', '', '', '000000000019', 0, 0, '1471867833', 20, '', '', '', 'MR/MRS JOHN JERRY', '', 'JOHN__1471867830_passport_JERRY.jpg', 'JOYCE__1471867832_passport_JOHN.jpg', 'JOHN__1471867830_signature_JERRY.jpg', 'JOYCE__1471867832_signature_JOHN.jpg', 'GN BANK', 'CIRCLE ACCRA', '00156476788', 'JOHN ', 'JOYCE ', 'JERRY', 'JOHN', '', '', '+233249334996', '+233249334996', 0, 2, '23345672', 1, '54645355', 0, '1', '', '', '', ''),
(54, '', '', '', 3, '', 0, '', 82, 'BOX OS6544', 'ACRCRA', '+233249334996', '', 0, '', '', '', '', '', '', '', '000000000020', 0, 0, '1471886432', 20, '', '', '', 'MR/MRS JOHN JERRY', '', 'JOHN__1471886431_passport_JERRY.jpg', 'JOYCE__1471886432_passport_JOHN.jpg', 'JOHN__1471886432_signature_JERRY.jpg', 'JOYCE__1471886432_signature_JOHN.jpg', 'GN BANK', 'CIRCLE ACCRA', '00156476788', 'JOHN ', 'JOYCE ', 'JERRY', 'JOHN', '', '', '+233249334996', '+233249334996', 0, 2, '23345672', 1, '54645355', 0, '1', '', '', '', ''),
(55, 'Schmidt', 'Bosoman-Yeboah', '', 1, 'Male', 1, '04/04/1981', 82, 'Box Ab432 Abeka lapaz', 'Accra', '+233243336725', 'Schmidt.yeboah@brooksmoney.com', 3, '545656809', 'Network Administrator', 'Married', 'Bosoman-Yeboah', '+233243336725', 'Schmidt_1471939983_signature_Bosoman-Yeboah.jpg', 'Schmidt_1471939982_passport_Bosoman-Yeboah.jpg', '100000000031', 2, 2, '1471939983', 20, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 18, '1', '', 'b34/2344 Lapaz, Accra', '', ''),
(56, '', '', '', 2, '', 0, '', 0, 'Box Sk244 Sakumono, Tema', 'Tema', '+233249334996', 'lucas.ahiable@brooksmoney.com', 0, '', '', '', '', '', '', '', '100000000034', 2, 2, '1471940913', 20, 'Fuel Retailling', '1', 'Gr76685988', 'Upsol Oil services', '08/04/2015', 'Lucas_1471940912_passport_Ahiable.jpg', '', 'Lucas_1471940912_signature_Ahiable.jpg', '', 'Stanbic Bank', 'Airport', '1110000543214', 'Lucas', '', 'Ahiable', '', 'Worlanyo', '', '+233249334996', '+233', 1, 2, '54567687656453433', 1, '', 18, '2', '', '', '249334996', ''),
(57, 'SUSANA', 'ODEI', 'NANA ADJOA', 1, 'Female', 2, '09/20/1976', 82, 'P.O.BOX 345,ACCRA', 'Accra', '+233244765782', 'elizabeth.akua-ampadu@brooksmoney.com', 2, 'G2098764', 'Business Woman', 'Married', 'Kwadjo Ansah', '+233249907084', 'SUSANA_1473098813_signature_ODEI.jpg', 'SUSANA_1473098813_passport_ODEI.jpg', '100000000032', 2, 2, '1473098813', 18, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 18, '2', '', 'NUMBER   3026 STREET ,EAST LEGON ACCRA', '', ''),
(58, 'Ama', 'Kessewa', 'Essuman', 1, 'Male', 1, '01/12/1991', 82, 'P.O Box 1253 gr,Accra', 'Accra', '+233127115008', 'amak.esugmail.com', 1, '100091234576', 'Trader', 'Single', 'Kwaku Amissah Mensah', '+233112984654', 'Ama_1473432231_signature_Kessewa.jpg', 'Ama_1473432231_passport_Kessewa.jpg', '001000000003', 3, 3, '1473432231', 25, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 25, '1', '', 'West ham Street', '', ''),
(59, 'Hayford', 'Danso Tutu', '', 1, 'Male', 1, '09/30/2016', 82, 'Box Lt 290 Laterbioshie Accra', '', '+233262141279', '', 1, '556663322', 'Programmer', 'Single', 'kwame kudjoe', '+233262141274', 'Hayford_1473612815_signature_Danso_Tutu.png', 'Hayford_1473612815_passport_Danso_Tutu.jpeg', '001000000004', 3, 3, '1473612815', 16, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 16, '1', '', 'A48A/2B Candle Link Laterbiokorshie Accra', '', ''),
(60, 'George', 'Nkansah', '', 1, 'Male', 1, '07/24/1985', 82, 'Box Lt 290', '', '+233027345852', '', 1, 'H52235G', '----', 'Single', 'kwame kudjoe', '+233262542365', 'George_1473614416_signature_Nkansah.jpeg', 'George_1473614416_passport_Nkansah.png', '001000000005', 3, 3, '1473614416', 16, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 16, '1', '', '-----', '', ''),
(61, 'william', 'kyei', 'nana', 1, 'Male', 1, '07/07/1980', 82, 'P.o.box 465 Accra', 'Accra', '+233249334996', 'william.kyei@brookmoney.com', 2, '099887765665', 'Account officer', 'Single', 'osei kyei', '+233249334996', 'william_1473847856_signature_kyei.jpg', 'william_1473847856_passport_kyei.jpg', '100000000033', 2, 2, '1473847856', 20, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 18, '2', '', 'b67/56', '', ''),
(62, 'Anthony', 'Dapaah', '', 1, 'Male', 1, '09/25/1979', 82, 'Box Ts 5676, Takoradi', 'Takoradi', '+233574315454', 'tony.dapaah@brooksmoney.com', 1, '568908978', 'Relationship Officer', 'Married', 'DanielDapaah', '+233574315454', 'Anthony_1474307684_signature_Dapaah.jpg', 'Anthony_1474307684_passport_Dapaah.jpg', '300000000000', 4, 2, '1474307686', 20, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 18, '1', '', 'T456/5666', '', ''),
(63, 'Gifty', 'Agbefah', '', 1, 'Female', 3, '09/09/1080', 82, 'Box T677', 'Takoradi', '+233273458524', 'gifty.agbefah@brooksmoney.con', 2, '8978767656', 'Customer Service Executive', 'Single', 'lilian Agbefah', '+233273458524', 'Gifty_1474309776_signature_Agbefah.jpg', 'Gifty_1474309776_passport_Agbefah.jpg', '300000000001', 4, 2, '1474309776', 20, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 7, '1', '', 'T12/90', '', ''),
(64, 'Esther', 'Quainoo', '', 1, 'Female', 3, '12/04/1978', 82, 'Box T908', 'Takoradi', '+233574315452', 'esther.quainoo@brooksmoney.com', 3, '44556778', 'Branch Manafer', 'Single', 'nhyiraba Quainoo', '+233574315452', 'Esther_1474310454_signature_Quainoo.jpg', 'Esther_1474310454_passport_Quainoo.jpg', '300000000002', 4, 2, '1474310454', 20, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 7, '1', '', 'T56/788', '', ''),
(65, 'JOSEPHINE', 'SENAZAH', '', 1, 'Female', 2, '06/22/1980', 82, 'P.O.BOX2089, ADUM KUMASI', 'KUMASI', '+233273458520', 'josephine.senazah@brooksmoney.com', 2, 'G0278615', 'ACCOUNTS EXECUTIVE', 'Married', 'JERRY  SENAZAH', '249907084', 'JOSEPHINE_1475846021_signature_SENAZAH.jpg', 'JOSEPHINE_1475846019_passport_SENAZAH.jpg', '', 5, 2, '1475846023', 18, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, '', 0, '', 0, '2', '', 'BUOKROM', '', ''),
(66, 'John', 'Azu', '', 1, 'Male', 1, '03/14/1991', 82, 'P.O Box 543,Accra-North', 'Accra', '+233244710365', '', 1, '1238750112', 'Geologist', 'Single', 'Alice Kuma', '57896011', 'John_1476099220_signature_Azu.png', 'John_1476099220_passport_Azu.png', '001000000006', 3, 3, '1476099220', 25, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 25, '1', '', 'Osu Oxford palace', '', '271230978'),
(67, 'Isaac', 'Trial Account', '', 1, 'Male', 1, '07/14/1988', 82, 'Box L.T 290 Laterbiokorshie', 'Accra', '+233262141279', 'isaacbremang@gmail.com', 2, 'H2633Q', 'Programmer', 'Single', 'Isaac', '262171279', 'Isaac_1477150043_signature_Trial_Account.jpg', 'Isaac_1477150043_passport_Trial_Account.png', '100000000035', 2, 2, '1477150043', 11, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 11, '1', '', 'A48A/2B Laterbiokorshie', '', '262141279'),
(68, 'Andrew', 'Adjetey', 'Nii', 1, 'Male', 1, '03/23/1985', 82, 'bt 488', 'Kumasi', '+233208189855', 'andyadjetey@gmail.com', 1, '11111111', 'Business Executive', 'Married', 'Carlien Adjetey', '208373586', 'Andrew_1478774059_signature_Adjetey.jpg', 'Andrew_1478774059_passport_Adjetey.jpg', '001000000007', 3, 3, '1478774059', 16, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, '', 0, '', 16, '1', '', 'Adenta SSNIT Flat', '', '208189855');

-- --------------------------------------------------------

--
-- Table structure for table `clients_update`
--

DROP TABLE IF EXISTS `clients_update`;
CREATE TABLE `clients_update` (
  `id` int(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `other_name` varchar(255) NOT NULL,
  `client_type_id` int(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `title_id` int(255) NOT NULL,
  `date_of_birth` varchar(255) NOT NULL,
  `country_id` int(255) NOT NULL,
  `postal_address` text NOT NULL,
  `city` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `id_card_type_id` int(255) NOT NULL,
  `id_card_number` varchar(255) NOT NULL,
  `occupation` varchar(255) NOT NULL,
  `marital_status` varchar(255) NOT NULL,
  `next_of_kin` varchar(255) NOT NULL,
  `next_of_kin_phone` varchar(255) NOT NULL,
  `signature_file` varchar(255) NOT NULL,
  `client_file` varchar(255) NOT NULL,
  `account_number` varchar(255) NOT NULL,
  `branch_id` int(255) NOT NULL,
  `company_id` int(255) NOT NULL,
  `date_created` varchar(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `nature_of_business` varchar(255) NOT NULL,
  `business_type_id` varchar(255) NOT NULL,
  `business_registration_number` varchar(255) NOT NULL,
  `business_name` varchar(255) NOT NULL,
  `date_incorporated` varchar(255) NOT NULL,
  `signatory_image_1` varchar(255) NOT NULL,
  `signatory_image_2` varchar(255) NOT NULL,
  `signature_image_1` varchar(255) NOT NULL,
  `signature_image_2` varchar(255) NOT NULL,
  `bank_name` varchar(255) NOT NULL,
  `bank_branch` varchar(255) NOT NULL,
  `bank_account_number` varchar(255) NOT NULL,
  `first_name_1` varchar(255) NOT NULL,
  `first_name_2` varchar(255) NOT NULL,
  `last_name_1` varchar(255) NOT NULL,
  `last_name_2` varchar(255) NOT NULL,
  `other_name_1` varchar(255) NOT NULL,
  `other_name_2` varchar(255) NOT NULL,
  `phone_1` varchar(255) NOT NULL,
  `phone_2` varchar(255) NOT NULL,
  `is_approved` int(1) NOT NULL DEFAULT '0',
  `id_card_type_id_1` int(255) NOT NULL,
  `id_card_number_1` varchar(255) NOT NULL,
  `id_card_type_id_2` int(255) NOT NULL,
  `id_card_number_2` varchar(255) NOT NULL,
  `approved_by` int(255) NOT NULL DEFAULT '0',
  `statement_frequency` varchar(255) NOT NULL DEFAULT '',
  `management_fees` varchar(255) NOT NULL,
  `residential_address` text NOT NULL,
  `company_telephone` varchar(255) NOT NULL DEFAULT '',
  `phone_alternative` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `clients_update`
--

TRUNCATE TABLE `clients_update`;
-- --------------------------------------------------------

--
-- Table structure for table `client_products`
--

DROP TABLE IF EXISTS `client_products`;
CREATE TABLE `client_products` (
  `id` int(255) NOT NULL,
  `id_client` int(255) NOT NULL,
  `id_product` int(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `client_products`
--

TRUNCATE TABLE `client_products`;
--
-- Dumping data for table `client_products`
--

INSERT INTO `client_products` (`id`, `id_client`, `id_product`) VALUES
(66, 1, 2),
(2, 2, 2),
(3, 3, 1),
(4, 3, 2),
(9, 4, 1),
(6, 4, 2),
(7, 1, 5),
(8, 3, 5),
(10, 5, 1),
(11, 5, 2),
(12, 6, 2),
(13, 7, 1),
(15, 7, 2),
(16, 8, 2),
(17, 9, 1),
(18, 10, 1),
(19, 11, 1),
(20, 12, 1),
(21, 13, 1),
(22, 14, 1),
(23, 15, 1),
(24, 16, 1),
(25, 17, 1),
(26, 18, 1),
(27, 19, 1),
(28, 20, 1),
(29, 21, 1),
(30, 22, 1),
(31, 23, 1),
(32, 24, 1),
(33, 25, 1),
(34, 26, 1),
(35, 27, 1),
(85, 28, 1),
(37, 29, 1),
(38, 30, 1),
(39, 31, 1),
(40, 32, 1),
(41, 33, 1),
(42, 34, 1),
(43, 35, 1),
(44, 36, 1),
(45, 37, 1),
(46, 38, 1),
(47, 39, 1),
(48, 40, 1),
(49, 41, 1),
(50, 42, 1),
(51, 43, 1),
(52, 44, 1),
(53, 45, 1),
(54, 46, 1),
(55, 47, 1),
(56, 48, 1),
(57, 49, 1),
(58, 50, 1),
(59, 51, 1),
(60, 52, 1),
(61, 53, 1),
(62, 54, 1),
(63, 55, 1),
(64, 56, 1),
(65, 15, 2),
(68, 12, 2),
(69, 10, 4),
(70, 57, 2),
(71, 14, 2),
(72, 6, 5),
(73, 4, 4),
(74, 58, 4),
(75, 58, 2),
(76, 58, 5),
(77, 59, 2),
(78, 60, 5),
(79, 61, 2),
(80, 16, 2),
(81, 9, 2),
(83, 11, 2),
(84, 55, 2),
(86, 28, 2),
(88, 9, 5),
(89, 62, 2),
(90, 63, 2),
(91, 64, 2),
(92, 59, 3),
(93, 65, 2),
(94, 63, 3),
(95, 3, 3),
(96, 66, 5),
(97, 66, 3),
(98, 67, 1),
(99, 67, 2),
(100, 5, 5),
(101, 68, 2),
(102, 1, 3),
(103, 6, 1),
(104, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `client_relation_officer`
--

DROP TABLE IF EXISTS `client_relation_officer`;
CREATE TABLE `client_relation_officer` (
  `id` int(255) NOT NULL,
  `id_client` int(255) NOT NULL,
  `id_relation_officer` int(255) NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `client_relation_officer`
--

TRUNCATE TABLE `client_relation_officer`;
--
-- Dumping data for table `client_relation_officer`
--

INSERT INTO `client_relation_officer` (`id`, `id_client`, `id_relation_officer`, `date`) VALUES
(5, 1, 4, '1469109014'),
(6, 2, 4, '1469211200'),
(7, 4, 6, '1469705375'),
(8, 5, 6, '1469796388'),
(9, 6, 4, '1470396321'),
(10, 7, 4, '1470847972'),
(11, 8, 7, '1470913943'),
(12, 9, 4, '1471343793'),
(13, 10, 4, '1471344940'),
(14, 11, 4, '1471345088'),
(15, 12, 4, '1471345673'),
(16, 13, 4, '1471345779'),
(17, 14, 4, '1471346196'),
(18, 15, 4, '1471346275'),
(20, 17, 4, '1471347429'),
(21, 18, 4, '1471348029'),
(22, 19, 4, '1471348417'),
(23, 20, 4, '1471348424'),
(24, 21, 4, '1471348903'),
(25, 22, 4, '1471349082'),
(26, 23, 7, '1471350312'),
(27, 24, 7, '1471350320'),
(28, 25, 4, '1471355208'),
(29, 26, 4, '1471355948'),
(30, 27, 2, '1471366614'),
(31, 28, 4, '1471520469'),
(32, 29, 4, '1471521024'),
(33, 30, 4, '1471596982'),
(34, 31, 4, '1471597007'),
(35, 32, 4, '1471852285'),
(36, 33, 4, '1471852971'),
(37, 34, 4, '1471861995'),
(38, 35, 4, '1471862001'),
(39, 36, 4, '1471862937'),
(40, 37, 4, '1471863029'),
(41, 38, 4, '1471863050'),
(42, 39, 4, '1471863077'),
(43, 40, 4, '1471863099'),
(44, 41, 4, '1471863163'),
(45, 42, 4, '1471863225'),
(46, 43, 4, '1471863243'),
(47, 44, 4, '1471863298'),
(48, 45, 4, '1471863312'),
(49, 46, 4, '1471863354'),
(50, 47, 4, '1471863444'),
(51, 48, 4, '1471863767'),
(52, 49, 4, '1471866378'),
(53, 50, 4, '1471866418'),
(54, 51, 4, '1471866429'),
(55, 52, 4, '1471866443'),
(56, 53, 4, '1471867834'),
(57, 54, 4, '1471886432'),
(58, 55, 4, '1471939985'),
(59, 56, 4, '1471940913'),
(60, 57, 4, '1473098813'),
(61, 58, 6, '1473432231'),
(62, 59, 6, '1473612815'),
(63, 60, 6, '1473614416'),
(64, 61, 4, '1473847856'),
(65, 16, 4, '1473863772'),
(66, 66, 6, '1476099220'),
(67, 67, 4, '1477150043'),
(68, 68, 6, '1478774059');

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

DROP TABLE IF EXISTS `companies`;
CREATE TABLE `companies` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `telephone` varchar(255) NOT NULL,
  `expiry` varchar(255) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `id_company_type` int(255) NOT NULL,
  `location` text NOT NULL,
  `email` varchar(255) NOT NULL DEFAULT 'root@devappstudio.com',
  `sms_username` varchar(255) NOT NULL,
  `sms_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `companies`
--

TRUNCATE TABLE `companies`;
--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `name`, `telephone`, `expiry`, `file_name`, `is_active`, `id_company_type`, `location`, `email`, `sms_username`, `sms_password`) VALUES
(1, 'Dev Apps Studio', '00233574389899', '1472594400', 'banekoma.png', 1, 0, 'Laterbiokorshie', 'root@devappstudio.com', 'BrickLaw', 'QuA29VKP'),
(2, 'Brooks Asset Management ', '0269009275', '2240611200', 'banekoma.png', 1, 0, 'East Legon', 'ibrahim.mohammed@brooksmoney.com', 'brooks.money', 'CfbQFgId'),
(3, 'Finxl', '0262141279', '1574899200', 'banekoma.png', 1, 0, 'Accra', 'root@devappstudio.com', 'brooks.money', 'CfbQFgId'),
(4, 'Naasons Agro Limited', '----', '1514678400', '', 1, 0, '---', 'root@devappstudio.com', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `company_bank_savings_transaction`
--

DROP TABLE IF EXISTS `company_bank_savings_transaction`;
CREATE TABLE `company_bank_savings_transaction` (
  `id` int(255) NOT NULL,
  `id_bank` int(255) NOT NULL,
  `id_transaction` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `company_bank_savings_transaction`
--

TRUNCATE TABLE `company_bank_savings_transaction`;
--
-- Dumping data for table `company_bank_savings_transaction`
--

INSERT INTO `company_bank_savings_transaction` (`id`, `id_bank`, `id_transaction`) VALUES
(1, 0, 1),
(2, 0, 2),
(3, 0, 9),
(4, 0, 31),
(5, 0, 32);

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
CREATE TABLE `countries` (
  `id` int(5) NOT NULL,
  `countryCode` char(2) NOT NULL DEFAULT '',
  `name` varchar(45) NOT NULL DEFAULT '',
  `currencyCode` char(3) DEFAULT NULL,
  `capital` varchar(30) DEFAULT NULL,
  `continentName` varchar(15) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `countries`
--

TRUNCATE TABLE `countries`;
--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `countryCode`, `name`, `currencyCode`, `capital`, `continentName`) VALUES
(1, 'AD', 'Andorra', 'EUR', 'Andorra la Vella', 'Europe'),
(2, 'AE', 'United Arab Emirates', 'AED', 'Abu Dhabi', 'Asia'),
(3, 'AF', 'Afghanistan', 'AFN', 'Kabul', 'Asia'),
(4, 'AG', 'Antigua and Barbuda', 'XCD', 'St. John''s', 'North America'),
(5, 'AI', 'Anguilla', 'XCD', 'The Valley', 'North America'),
(6, 'AL', 'Albania', 'ALL', 'Tirana', 'Europe'),
(7, 'AM', 'Armenia', 'AMD', 'Yerevan', 'Asia'),
(8, 'AO', 'Angola', 'AOA', 'Luanda', 'Africa'),
(9, 'AQ', 'Antarctica', '', '', 'Antarctica'),
(10, 'AR', 'Argentina', 'ARS', 'Buenos Aires', 'South America'),
(11, 'AS', 'American Samoa', 'USD', 'Pago Pago', 'Oceania'),
(12, 'AT', 'Austria', 'EUR', 'Vienna', 'Europe'),
(13, 'AU', 'Australia', 'AUD', 'Canberra', 'Oceania'),
(14, 'AW', 'Aruba', 'AWG', 'Oranjestad', 'North America'),
(15, 'AX', 'Aland', 'EUR', 'Mariehamn', 'Europe'),
(16, 'AZ', 'Azerbaijan', 'AZN', 'Baku', 'Asia'),
(17, 'BA', 'Bosnia and Herzegovina', 'BAM', 'Sarajevo', 'Europe'),
(18, 'BB', 'Barbados', 'BBD', 'Bridgetown', 'North America'),
(19, 'BD', 'Bangladesh', 'BDT', 'Dhaka', 'Asia'),
(20, 'BE', 'Belgium', 'EUR', 'Brussels', 'Europe'),
(21, 'BF', 'Burkina Faso', 'XOF', 'Ouagadougou', 'Africa'),
(22, 'BG', 'Bulgaria', 'BGN', 'Sofia', 'Europe'),
(23, 'BH', 'Bahrain', 'BHD', 'Manama', 'Asia'),
(24, 'BI', 'Burundi', 'BIF', 'Bujumbura', 'Africa'),
(25, 'BJ', 'Benin', 'XOF', 'Porto-Novo', 'Africa'),
(26, 'BL', 'Saint Barthelemy', 'EUR', 'Gustavia', 'North America'),
(27, 'BM', 'Bermuda', 'BMD', 'Hamilton', 'North America'),
(28, 'BN', 'Brunei', 'BND', 'Bandar Seri Begawan', 'Asia'),
(29, 'BO', 'Bolivia', 'BOB', 'Sucre', 'South America'),
(30, 'BQ', 'Bonaire', 'USD', '', 'North America'),
(31, 'BR', 'Brazil', 'BRL', 'Brasília', 'South America'),
(32, 'BS', 'Bahamas', 'BSD', 'Nassau', 'North America'),
(33, 'BT', 'Bhutan', 'BTN', 'Thimphu', 'Asia'),
(34, 'BV', 'Bouvet Island', 'NOK', '', 'Antarctica'),
(35, 'BW', 'Botswana', 'BWP', 'Gaborone', 'Africa'),
(36, 'BY', 'Belarus', 'BYR', 'Minsk', 'Europe'),
(37, 'BZ', 'Belize', 'BZD', 'Belmopan', 'North America'),
(38, 'CA', 'Canada', 'CAD', 'Ottawa', 'North America'),
(39, 'CC', 'Cocos [Keeling] Islands', 'AUD', 'West Island', 'Asia'),
(40, 'CD', 'Democratic Republic of the Congo', 'CDF', 'Kinshasa', 'Africa'),
(41, 'CF', 'Central African Republic', 'XAF', 'Bangui', 'Africa'),
(42, 'CG', 'Republic of the Congo', 'XAF', 'Brazzaville', 'Africa'),
(43, 'CH', 'Switzerland', 'CHF', 'Berne', 'Europe'),
(44, 'CI', 'Ivory Coast', 'XOF', 'Yamoussoukro', 'Africa'),
(45, 'CK', 'Cook Islands', 'NZD', 'Avarua', 'Oceania'),
(46, 'CL', 'Chile', 'CLP', 'Santiago', 'South America'),
(47, 'CM', 'Cameroon', 'XAF', 'Yaoundé', 'Africa'),
(48, 'CN', 'China', 'CNY', 'Beijing', 'Asia'),
(49, 'CO', 'Colombia', 'COP', 'Bogotá', 'South America'),
(50, 'CR', 'Costa Rica', 'CRC', 'San José', 'North America'),
(51, 'CU', 'Cuba', 'CUP', 'Havana', 'North America'),
(52, 'CV', 'Cape Verde', 'CVE', 'Praia', 'Africa'),
(53, 'CW', 'Curacao', 'ANG', 'Willemstad', 'North America'),
(54, 'CX', 'Christmas Island', 'AUD', 'The Settlement', 'Asia'),
(55, 'CY', 'Cyprus', 'EUR', 'Nicosia', 'Europe'),
(56, 'CZ', 'Czech Republic', 'CZK', 'Prague', 'Europe'),
(57, 'DE', 'Germany', 'EUR', 'Berlin', 'Europe'),
(58, 'DJ', 'Djibouti', 'DJF', 'Djibouti', 'Africa'),
(59, 'DK', 'Denmark', 'DKK', 'Copenhagen', 'Europe'),
(60, 'DM', 'Dominica', 'XCD', 'Roseau', 'North America'),
(61, 'DO', 'Dominican Republic', 'DOP', 'Santo Domingo', 'North America'),
(62, 'DZ', 'Algeria', 'DZD', 'Algiers', 'Africa'),
(63, 'EC', 'Ecuador', 'USD', 'Quito', 'South America'),
(64, 'EE', 'Estonia', 'EUR', 'Tallinn', 'Europe'),
(65, 'EG', 'Egypt', 'EGP', 'Cairo', 'Africa'),
(66, 'EH', 'Western Sahara', 'MAD', 'El Aaiún', 'Africa'),
(67, 'ER', 'Eritrea', 'ERN', 'Asmara', 'Africa'),
(68, 'ES', 'Spain', 'EUR', 'Madrid', 'Europe'),
(69, 'ET', 'Ethiopia', 'ETB', 'Addis Ababa', 'Africa'),
(70, 'FI', 'Finland', 'EUR', 'Helsinki', 'Europe'),
(71, 'FJ', 'Fiji', 'FJD', 'Suva', 'Oceania'),
(72, 'FK', 'Falkland Islands', 'FKP', 'Stanley', 'South America'),
(73, 'FM', 'Micronesia', 'USD', 'Palikir', 'Oceania'),
(74, 'FO', 'Faroe Islands', 'DKK', 'Tórshavn', 'Europe'),
(75, 'FR', 'France', 'EUR', 'Paris', 'Europe'),
(76, 'GA', 'Gabon', 'XAF', 'Libreville', 'Africa'),
(77, 'GB', 'United Kingdom', 'GBP', 'London', 'Europe'),
(78, 'GD', 'Grenada', 'XCD', 'St. George''s', 'North America'),
(79, 'GE', 'Georgia', 'GEL', 'Tbilisi', 'Asia'),
(80, 'GF', 'French Guiana', 'EUR', 'Cayenne', 'South America'),
(81, 'GG', 'Guernsey', 'GBP', 'St Peter Port', 'Europe'),
(82, 'GH', 'Ghana', 'GHS', 'Accra', 'Africa'),
(83, 'GI', 'Gibraltar', 'GIP', 'Gibraltar', 'Europe'),
(84, 'GL', 'Greenland', 'DKK', 'Nuuk', 'North America'),
(85, 'GM', 'Gambia', 'GMD', 'Banjul', 'Africa'),
(86, 'GN', 'Guinea', 'GNF', 'Conakry', 'Africa'),
(87, 'GP', 'Guadeloupe', 'EUR', 'Basse-Terre', 'North America'),
(88, 'GQ', 'Equatorial Guinea', 'XAF', 'Malabo', 'Africa'),
(89, 'GR', 'Greece', 'EUR', 'Athens', 'Europe'),
(90, 'GS', 'South Georgia and the South Sandwich Islands', 'GBP', 'Grytviken', 'Antarctica'),
(91, 'GT', 'Guatemala', 'GTQ', 'Guatemala City', 'North America'),
(92, 'GU', 'Guam', 'USD', 'Hagåtña', 'Oceania'),
(93, 'GW', 'Guinea-Bissau', 'XOF', 'Bissau', 'Africa'),
(94, 'GY', 'Guyana', 'GYD', 'Georgetown', 'South America'),
(95, 'HK', 'Hong Kong', 'HKD', 'Hong Kong', 'Asia'),
(96, 'HM', 'Heard Island and McDonald Islands', 'AUD', '', 'Antarctica'),
(97, 'HN', 'Honduras', 'HNL', 'Tegucigalpa', 'North America'),
(98, 'HR', 'Croatia', 'HRK', 'Zagreb', 'Europe'),
(99, 'HT', 'Haiti', 'HTG', 'Port-au-Prince', 'North America'),
(100, 'HU', 'Hungary', 'HUF', 'Budapest', 'Europe'),
(101, 'ID', 'Indonesia', 'IDR', 'Jakarta', 'Asia'),
(102, 'IE', 'Ireland', 'EUR', 'Dublin', 'Europe'),
(103, 'IL', 'Israel', 'ILS', '', 'Asia'),
(104, 'IM', 'Isle of Man', 'GBP', 'Douglas', 'Europe'),
(105, 'IN', 'India', 'INR', 'New Delhi', 'Asia'),
(106, 'IO', 'British Indian Ocean Territory', 'USD', '', 'Asia'),
(107, 'IQ', 'Iraq', 'IQD', 'Baghdad', 'Asia'),
(108, 'IR', 'Iran', 'IRR', 'Tehran', 'Asia'),
(109, 'IS', 'Iceland', 'ISK', 'Reykjavik', 'Europe'),
(110, 'IT', 'Italy', 'EUR', 'Rome', 'Europe'),
(111, 'JE', 'Jersey', 'GBP', 'Saint Helier', 'Europe'),
(112, 'JM', 'Jamaica', 'JMD', 'Kingston', 'North America'),
(113, 'JO', 'Jordan', 'JOD', 'Amman', 'Asia'),
(114, 'JP', 'Japan', 'JPY', 'Tokyo', 'Asia'),
(115, 'KE', 'Kenya', 'KES', 'Nairobi', 'Africa'),
(116, 'KG', 'Kyrgyzstan', 'KGS', 'Bishkek', 'Asia'),
(117, 'KH', 'Cambodia', 'KHR', 'Phnom Penh', 'Asia'),
(118, 'KI', 'Kiribati', 'AUD', 'Tarawa', 'Oceania'),
(119, 'KM', 'Comoros', 'KMF', 'Moroni', 'Africa'),
(120, 'KN', 'Saint Kitts and Nevis', 'XCD', 'Basseterre', 'North America'),
(121, 'KP', 'North Korea', 'KPW', 'Pyongyang', 'Asia'),
(122, 'KR', 'South Korea', 'KRW', 'Seoul', 'Asia'),
(123, 'KW', 'Kuwait', 'KWD', 'Kuwait City', 'Asia'),
(124, 'KY', 'Cayman Islands', 'KYD', 'George Town', 'North America'),
(125, 'KZ', 'Kazakhstan', 'KZT', 'Astana', 'Asia'),
(126, 'LA', 'Laos', 'LAK', 'Vientiane', 'Asia'),
(127, 'LB', 'Lebanon', 'LBP', 'Beirut', 'Asia'),
(128, 'LC', 'Saint Lucia', 'XCD', 'Castries', 'North America'),
(129, 'LI', 'Liechtenstein', 'CHF', 'Vaduz', 'Europe'),
(130, 'LK', 'Sri Lanka', 'LKR', 'Colombo', 'Asia'),
(131, 'LR', 'Liberia', 'LRD', 'Monrovia', 'Africa'),
(132, 'LS', 'Lesotho', 'LSL', 'Maseru', 'Africa'),
(133, 'LT', 'Lithuania', 'LTL', 'Vilnius', 'Europe'),
(134, 'LU', 'Luxembourg', 'EUR', 'Luxembourg', 'Europe'),
(135, 'LV', 'Latvia', 'EUR', 'Riga', 'Europe'),
(136, 'LY', 'Libya', 'LYD', 'Tripoli', 'Africa'),
(137, 'MA', 'Morocco', 'MAD', 'Rabat', 'Africa'),
(138, 'MC', 'Monaco', 'EUR', 'Monaco', 'Europe'),
(139, 'MD', 'Moldova', 'MDL', 'Chişinău', 'Europe'),
(140, 'ME', 'Montenegro', 'EUR', 'Podgorica', 'Europe'),
(141, 'MF', 'Saint Martin', 'EUR', 'Marigot', 'North America'),
(142, 'MG', 'Madagascar', 'MGA', 'Antananarivo', 'Africa'),
(143, 'MH', 'Marshall Islands', 'USD', 'Majuro', 'Oceania'),
(144, 'MK', 'Macedonia', 'MKD', 'Skopje', 'Europe'),
(145, 'ML', 'Mali', 'XOF', 'Bamako', 'Africa'),
(146, 'MM', 'Myanmar [Burma]', 'MMK', 'Nay Pyi Taw', 'Asia'),
(147, 'MN', 'Mongolia', 'MNT', 'Ulan Bator', 'Asia'),
(148, 'MO', 'Macao', 'MOP', 'Macao', 'Asia'),
(149, 'MP', 'Northern Mariana Islands', 'USD', 'Saipan', 'Oceania'),
(150, 'MQ', 'Martinique', 'EUR', 'Fort-de-France', 'North America'),
(151, 'MR', 'Mauritania', 'MRO', 'Nouakchott', 'Africa'),
(152, 'MS', 'Montserrat', 'XCD', 'Plymouth', 'North America'),
(153, 'MT', 'Malta', 'EUR', 'Valletta', 'Europe'),
(154, 'MU', 'Mauritius', 'MUR', 'Port Louis', 'Africa'),
(155, 'MV', 'Maldives', 'MVR', 'Malé', 'Asia'),
(156, 'MW', 'Malawi', 'MWK', 'Lilongwe', 'Africa'),
(157, 'MX', 'Mexico', 'MXN', 'Mexico City', 'North America'),
(158, 'MY', 'Malaysia', 'MYR', 'Kuala Lumpur', 'Asia'),
(159, 'MZ', 'Mozambique', 'MZN', 'Maputo', 'Africa'),
(160, 'NA', 'Namibia', 'NAD', 'Windhoek', 'Africa'),
(161, 'NC', 'New Caledonia', 'XPF', 'Noumea', 'Oceania'),
(162, 'NE', 'Niger', 'XOF', 'Niamey', 'Africa'),
(163, 'NF', 'Norfolk Island', 'AUD', 'Kingston', 'Oceania'),
(164, 'NG', 'Nigeria', 'NGN', 'Abuja', 'Africa'),
(165, 'NI', 'Nicaragua', 'NIO', 'Managua', 'North America'),
(166, 'NL', 'Netherlands', 'EUR', 'Amsterdam', 'Europe'),
(167, 'NO', 'Norway', 'NOK', 'Oslo', 'Europe'),
(168, 'NP', 'Nepal', 'NPR', 'Kathmandu', 'Asia'),
(169, 'NR', 'Nauru', 'AUD', '', 'Oceania'),
(170, 'NU', 'Niue', 'NZD', 'Alofi', 'Oceania'),
(171, 'NZ', 'New Zealand', 'NZD', 'Wellington', 'Oceania'),
(172, 'OM', 'Oman', 'OMR', 'Muscat', 'Asia'),
(173, 'PA', 'Panama', 'PAB', 'Panama City', 'North America'),
(174, 'PE', 'Peru', 'PEN', 'Lima', 'South America'),
(175, 'PF', 'French Polynesia', 'XPF', 'Papeete', 'Oceania'),
(176, 'PG', 'Papua New Guinea', 'PGK', 'Port Moresby', 'Oceania'),
(177, 'PH', 'Philippines', 'PHP', 'Manila', 'Asia'),
(178, 'PK', 'Pakistan', 'PKR', 'Islamabad', 'Asia'),
(179, 'PL', 'Poland', 'PLN', 'Warsaw', 'Europe'),
(180, 'PM', 'Saint Pierre and Miquelon', 'EUR', 'Saint-Pierre', 'North America'),
(181, 'PN', 'Pitcairn Islands', 'NZD', 'Adamstown', 'Oceania'),
(182, 'PR', 'Puerto Rico', 'USD', 'San Juan', 'North America'),
(183, 'PS', 'Palestine', 'ILS', '', 'Asia'),
(184, 'PT', 'Portugal', 'EUR', 'Lisbon', 'Europe'),
(185, 'PW', 'Palau', 'USD', 'Melekeok - Palau State Capital', 'Oceania'),
(186, 'PY', 'Paraguay', 'PYG', 'Asunción', 'South America'),
(187, 'QA', 'Qatar', 'QAR', 'Doha', 'Asia'),
(188, 'RE', 'Reunion', 'EUR', 'Saint-Denis', 'Africa'),
(189, 'RO', 'Romania', 'RON', 'Bucharest', 'Europe'),
(190, 'RS', 'Serbia', 'RSD', 'Belgrade', 'Europe'),
(191, 'RU', 'Russia', 'RUB', 'Moscow', 'Europe'),
(192, 'RW', 'Rwanda', 'RWF', 'Kigali', 'Africa'),
(193, 'SA', 'Saudi Arabia', 'SAR', 'Riyadh', 'Asia'),
(194, 'SB', 'Solomon Islands', 'SBD', 'Honiara', 'Oceania'),
(195, 'SC', 'Seychelles', 'SCR', 'Victoria', 'Africa'),
(196, 'SD', 'Sudan', 'SDG', 'Khartoum', 'Africa'),
(197, 'SE', 'Sweden', 'SEK', 'Stockholm', 'Europe'),
(198, 'SG', 'Singapore', 'SGD', 'Singapore', 'Asia'),
(199, 'SH', 'Saint Helena', 'SHP', 'Jamestown', 'Africa'),
(200, 'SI', 'Slovenia', 'EUR', 'Ljubljana', 'Europe'),
(201, 'SJ', 'Svalbard and Jan Mayen', 'NOK', 'Longyearbyen', 'Europe'),
(202, 'SK', 'Slovakia', 'EUR', 'Bratislava', 'Europe'),
(203, 'SL', 'Sierra Leone', 'SLL', 'Freetown', 'Africa'),
(204, 'SM', 'San Marino', 'EUR', 'San Marino', 'Europe'),
(205, 'SN', 'Senegal', 'XOF', 'Dakar', 'Africa'),
(206, 'SO', 'Somalia', 'SOS', 'Mogadishu', 'Africa'),
(207, 'SR', 'Suriname', 'SRD', 'Paramaribo', 'South America'),
(208, 'SS', 'South Sudan', 'SSP', 'Juba', 'Africa'),
(209, 'ST', 'Sao Tome and Principe', 'STD', 'São Tomé', 'Africa'),
(210, 'SV', 'El Salvador', 'USD', 'San Salvador', 'North America'),
(211, 'SX', 'Sint Maarten', 'ANG', 'Philipsburg', 'North America'),
(212, 'SY', 'Syria', 'SYP', 'Damascus', 'Asia'),
(213, 'SZ', 'Swaziland', 'SZL', 'Mbabane', 'Africa'),
(214, 'TC', 'Turks and Caicos Islands', 'USD', 'Cockburn Town', 'North America'),
(215, 'TD', 'Chad', 'XAF', 'N''Djamena', 'Africa'),
(216, 'TF', 'French Southern Territories', 'EUR', 'Port-aux-Français', 'Antarctica'),
(217, 'TG', 'Togo', 'XOF', 'Lomé', 'Africa'),
(218, 'TH', 'Thailand', 'THB', 'Bangkok', 'Asia'),
(219, 'TJ', 'Tajikistan', 'TJS', 'Dushanbe', 'Asia'),
(220, 'TK', 'Tokelau', 'NZD', '', 'Oceania'),
(221, 'TL', 'East Timor', 'USD', 'Dili', 'Oceania'),
(222, 'TM', 'Turkmenistan', 'TMT', 'Ashgabat', 'Asia'),
(223, 'TN', 'Tunisia', 'TND', 'Tunis', 'Africa'),
(224, 'TO', 'Tonga', 'TOP', 'Nuku''alofa', 'Oceania'),
(225, 'TR', 'Turkey', 'TRY', 'Ankara', 'Asia'),
(226, 'TT', 'Trinidad and Tobago', 'TTD', 'Port of Spain', 'North America'),
(227, 'TV', 'Tuvalu', 'AUD', 'Funafuti', 'Oceania'),
(228, 'TW', 'Taiwan', 'TWD', 'Taipei', 'Asia'),
(229, 'TZ', 'Tanzania', 'TZS', 'Dodoma', 'Africa'),
(230, 'UA', 'Ukraine', 'UAH', 'Kyiv', 'Europe'),
(231, 'UG', 'Uganda', 'UGX', 'Kampala', 'Africa'),
(232, 'UM', 'U.S. Minor Outlying Islands', 'USD', '', 'Oceania'),
(233, 'US', 'United States', 'USD', 'Washington', 'North America'),
(234, 'UY', 'Uruguay', 'UYU', 'Montevideo', 'South America'),
(235, 'UZ', 'Uzbekistan', 'UZS', 'Tashkent', 'Asia'),
(236, 'VA', 'Vatican City', 'EUR', 'Vatican', 'Europe'),
(237, 'VC', 'Saint Vincent and the Grenadines', 'XCD', 'Kingstown', 'North America'),
(238, 'VE', 'Venezuela', 'VEF', 'Caracas', 'South America'),
(239, 'VG', 'British Virgin Islands', 'USD', 'Road Town', 'North America'),
(240, 'VI', 'U.S. Virgin Islands', 'USD', 'Charlotte Amalie', 'North America'),
(241, 'VN', 'Vietnam', 'VND', 'Hanoi', 'Asia'),
(242, 'VU', 'Vanuatu', 'VUV', 'Port Vila', 'Oceania'),
(243, 'WF', 'Wallis and Futuna', 'XPF', 'Mata-Utu', 'Oceania'),
(244, 'WS', 'Samoa', 'WST', 'Apia', 'Oceania'),
(245, 'XK', 'Kosovo', 'EUR', 'Pristina', 'Europe'),
(246, 'YE', 'Yemen', 'YER', 'Sanaa', 'Asia'),
(247, 'YT', 'Mayotte', 'EUR', 'Mamoutzou', 'Africa'),
(248, 'ZA', 'South Africa', 'ZAR', 'Pretoria', 'Africa'),
(249, 'ZM', 'Zambia', 'ZMW', 'Lusaka', 'Africa'),
(250, 'ZW', 'Zimbabwe', 'ZWL', 'Harare', 'Africa');

-- --------------------------------------------------------

--
-- Table structure for table `country_codes`
--

DROP TABLE IF EXISTS `country_codes`;
CREATE TABLE `country_codes` (
  `id` int(11) NOT NULL,
  `iso` char(2) NOT NULL,
  `name` varchar(80) NOT NULL,
  `nicename` varchar(80) NOT NULL,
  `iso3` char(3) DEFAULT NULL,
  `numcode` smallint(6) DEFAULT NULL,
  `phonecode` int(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `country_codes`
--

TRUNCATE TABLE `country_codes`;
--
-- Dumping data for table `country_codes`
--

INSERT INTO `country_codes` (`id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`) VALUES
(1, 'AF', 'AFGHANISTAN', 'Afghanistan', 'AFG', 4, 93),
(2, 'AL', 'ALBANIA', 'Albania', 'ALB', 8, 355),
(3, 'DZ', 'ALGERIA', 'Algeria', 'DZA', 12, 213),
(4, 'AS', 'AMERICAN SAMOA', 'American Samoa', 'ASM', 16, 1684),
(5, 'AD', 'ANDORRA', 'Andorra', 'AND', 20, 376),
(6, 'AO', 'ANGOLA', 'Angola', 'AGO', 24, 244),
(7, 'AI', 'ANGUILLA', 'Anguilla', 'AIA', 660, 1264),
(8, 'AQ', 'ANTARCTICA', 'Antarctica', NULL, NULL, 0),
(9, 'AG', 'ANTIGUA AND BARBUDA', 'Antigua and Barbuda', 'ATG', 28, 1268),
(10, 'AR', 'ARGENTINA', 'Argentina', 'ARG', 32, 54),
(11, 'AM', 'ARMENIA', 'Armenia', 'ARM', 51, 374),
(12, 'AW', 'ARUBA', 'Aruba', 'ABW', 533, 297),
(13, 'AU', 'AUSTRALIA', 'Australia', 'AUS', 36, 61),
(14, 'AT', 'AUSTRIA', 'Austria', 'AUT', 40, 43),
(15, 'AZ', 'AZERBAIJAN', 'Azerbaijan', 'AZE', 31, 994),
(16, 'BS', 'BAHAMAS', 'Bahamas', 'BHS', 44, 1242),
(17, 'BH', 'BAHRAIN', 'Bahrain', 'BHR', 48, 973),
(18, 'BD', 'BANGLADESH', 'Bangladesh', 'BGD', 50, 880),
(19, 'BB', 'BARBADOS', 'Barbados', 'BRB', 52, 1246),
(20, 'BY', 'BELARUS', 'Belarus', 'BLR', 112, 375),
(21, 'BE', 'BELGIUM', 'Belgium', 'BEL', 56, 32),
(22, 'BZ', 'BELIZE', 'Belize', 'BLZ', 84, 501),
(23, 'BJ', 'BENIN', 'Benin', 'BEN', 204, 229),
(24, 'BM', 'BERMUDA', 'Bermuda', 'BMU', 60, 1441),
(25, 'BT', 'BHUTAN', 'Bhutan', 'BTN', 64, 975),
(26, 'BO', 'BOLIVIA', 'Bolivia', 'BOL', 68, 591),
(27, 'BA', 'BOSNIA AND HERZEGOVINA', 'Bosnia and Herzegovina', 'BIH', 70, 387),
(28, 'BW', 'BOTSWANA', 'Botswana', 'BWA', 72, 267),
(29, 'BV', 'BOUVET ISLAND', 'Bouvet Island', NULL, NULL, 0),
(30, 'BR', 'BRAZIL', 'Brazil', 'BRA', 76, 55),
(31, 'IO', 'BRITISH INDIAN OCEAN TERRITORY', 'British Indian Ocean Territory', NULL, NULL, 246),
(32, 'BN', 'BRUNEI DARUSSALAM', 'Brunei Darussalam', 'BRN', 96, 673),
(33, 'BG', 'BULGARIA', 'Bulgaria', 'BGR', 100, 359),
(34, 'BF', 'BURKINA FASO', 'Burkina Faso', 'BFA', 854, 226),
(35, 'BI', 'BURUNDI', 'Burundi', 'BDI', 108, 257),
(36, 'KH', 'CAMBODIA', 'Cambodia', 'KHM', 116, 855),
(37, 'CM', 'CAMEROON', 'Cameroon', 'CMR', 120, 237),
(38, 'CA', 'CANADA', 'Canada', 'CAN', 124, 1),
(39, 'CV', 'CAPE VERDE', 'Cape Verde', 'CPV', 132, 238),
(40, 'KY', 'CAYMAN ISLANDS', 'Cayman Islands', 'CYM', 136, 1345),
(41, 'CF', 'CENTRAL AFRICAN REPUBLIC', 'Central African Republic', 'CAF', 140, 236),
(42, 'TD', 'CHAD', 'Chad', 'TCD', 148, 235),
(43, 'CL', 'CHILE', 'Chile', 'CHL', 152, 56),
(44, 'CN', 'CHINA', 'China', 'CHN', 156, 86),
(45, 'CX', 'CHRISTMAS ISLAND', 'Christmas Island', NULL, NULL, 61),
(46, 'CC', 'COCOS (KEELING) ISLANDS', 'Cocos (Keeling) Islands', NULL, NULL, 672),
(47, 'CO', 'COLOMBIA', 'Colombia', 'COL', 170, 57),
(48, 'KM', 'COMOROS', 'Comoros', 'COM', 174, 269),
(49, 'CG', 'CONGO', 'Congo', 'COG', 178, 242),
(50, 'CD', 'CONGO, THE DEMOCRATIC REPUBLIC OF THE', 'Congo, the Democratic Republic of the', 'COD', 180, 242),
(51, 'CK', 'COOK ISLANDS', 'Cook Islands', 'COK', 184, 682),
(52, 'CR', 'COSTA RICA', 'Costa Rica', 'CRI', 188, 506),
(53, 'CI', 'COTE D''IVOIRE', 'Cote D''Ivoire', 'CIV', 384, 225),
(54, 'HR', 'CROATIA', 'Croatia', 'HRV', 191, 385),
(55, 'CU', 'CUBA', 'Cuba', 'CUB', 192, 53),
(56, 'CY', 'CYPRUS', 'Cyprus', 'CYP', 196, 357),
(57, 'CZ', 'CZECH REPUBLIC', 'Czech Republic', 'CZE', 203, 420),
(58, 'DK', 'DENMARK', 'Denmark', 'DNK', 208, 45),
(59, 'DJ', 'DJIBOUTI', 'Djibouti', 'DJI', 262, 253),
(60, 'DM', 'DOMINICA', 'Dominica', 'DMA', 212, 1767),
(61, 'DO', 'DOMINICAN REPUBLIC', 'Dominican Republic', 'DOM', 214, 1809),
(62, 'EC', 'ECUADOR', 'Ecuador', 'ECU', 218, 593),
(63, 'EG', 'EGYPT', 'Egypt', 'EGY', 818, 20),
(64, 'SV', 'EL SALVADOR', 'El Salvador', 'SLV', 222, 503),
(65, 'GQ', 'EQUATORIAL GUINEA', 'Equatorial Guinea', 'GNQ', 226, 240),
(66, 'ER', 'ERITREA', 'Eritrea', 'ERI', 232, 291),
(67, 'EE', 'ESTONIA', 'Estonia', 'EST', 233, 372),
(68, 'ET', 'ETHIOPIA', 'Ethiopia', 'ETH', 231, 251),
(69, 'FK', 'FALKLAND ISLANDS (MALVINAS)', 'Falkland Islands (Malvinas)', 'FLK', 238, 500),
(70, 'FO', 'FAROE ISLANDS', 'Faroe Islands', 'FRO', 234, 298),
(71, 'FJ', 'FIJI', 'Fiji', 'FJI', 242, 679),
(72, 'FI', 'FINLAND', 'Finland', 'FIN', 246, 358),
(73, 'FR', 'FRANCE', 'France', 'FRA', 250, 33),
(74, 'GF', 'FRENCH GUIANA', 'French Guiana', 'GUF', 254, 594),
(75, 'PF', 'FRENCH POLYNESIA', 'French Polynesia', 'PYF', 258, 689),
(76, 'TF', 'FRENCH SOUTHERN TERRITORIES', 'French Southern Territories', NULL, NULL, 0),
(77, 'GA', 'GABON', 'Gabon', 'GAB', 266, 241),
(78, 'GM', 'GAMBIA', 'Gambia', 'GMB', 270, 220),
(79, 'GE', 'GEORGIA', 'Georgia', 'GEO', 268, 995),
(80, 'DE', 'GERMANY', 'Germany', 'DEU', 276, 49),
(81, 'GH', 'GHANA', 'Ghana', 'GHA', 288, 233),
(82, 'GI', 'GIBRALTAR', 'Gibraltar', 'GIB', 292, 350),
(83, 'GR', 'GREECE', 'Greece', 'GRC', 300, 30),
(84, 'GL', 'GREENLAND', 'Greenland', 'GRL', 304, 299),
(85, 'GD', 'GRENADA', 'Grenada', 'GRD', 308, 1473),
(86, 'GP', 'GUADELOUPE', 'Guadeloupe', 'GLP', 312, 590),
(87, 'GU', 'GUAM', 'Guam', 'GUM', 316, 1671),
(88, 'GT', 'GUATEMALA', 'Guatemala', 'GTM', 320, 502),
(89, 'GN', 'GUINEA', 'Guinea', 'GIN', 324, 224),
(90, 'GW', 'GUINEA-BISSAU', 'Guinea-Bissau', 'GNB', 624, 245),
(91, 'GY', 'GUYANA', 'Guyana', 'GUY', 328, 592),
(92, 'HT', 'HAITI', 'Haiti', 'HTI', 332, 509),
(93, 'HM', 'HEARD ISLAND AND MCDONALD ISLANDS', 'Heard Island and Mcdonald Islands', NULL, NULL, 0),
(94, 'VA', 'HOLY SEE (VATICAN CITY STATE)', 'Holy See (Vatican City State)', 'VAT', 336, 39),
(95, 'HN', 'HONDURAS', 'Honduras', 'HND', 340, 504),
(96, 'HK', 'HONG KONG', 'Hong Kong', 'HKG', 344, 852),
(97, 'HU', 'HUNGARY', 'Hungary', 'HUN', 348, 36),
(98, 'IS', 'ICELAND', 'Iceland', 'ISL', 352, 354),
(99, 'IN', 'INDIA', 'India', 'IND', 356, 91),
(100, 'ID', 'INDONESIA', 'Indonesia', 'IDN', 360, 62),
(101, 'IR', 'IRAN, ISLAMIC REPUBLIC OF', 'Iran, Islamic Republic of', 'IRN', 364, 98),
(102, 'IQ', 'IRAQ', 'Iraq', 'IRQ', 368, 964),
(103, 'IE', 'IRELAND', 'Ireland', 'IRL', 372, 353),
(104, 'IL', 'ISRAEL', 'Israel', 'ISR', 376, 972),
(105, 'IT', 'ITALY', 'Italy', 'ITA', 380, 39),
(106, 'JM', 'JAMAICA', 'Jamaica', 'JAM', 388, 1876),
(107, 'JP', 'JAPAN', 'Japan', 'JPN', 392, 81),
(108, 'JO', 'JORDAN', 'Jordan', 'JOR', 400, 962),
(109, 'KZ', 'KAZAKHSTAN', 'Kazakhstan', 'KAZ', 398, 7),
(110, 'KE', 'KENYA', 'Kenya', 'KEN', 404, 254),
(111, 'KI', 'KIRIBATI', 'Kiribati', 'KIR', 296, 686),
(112, 'KP', 'KOREA, DEMOCRATIC PEOPLE''S REPUBLIC OF', 'Korea, Democratic People''s Republic of', 'PRK', 408, 850),
(113, 'KR', 'KOREA, REPUBLIC OF', 'Korea, Republic of', 'KOR', 410, 82),
(114, 'KW', 'KUWAIT', 'Kuwait', 'KWT', 414, 965),
(115, 'KG', 'KYRGYZSTAN', 'Kyrgyzstan', 'KGZ', 417, 996),
(116, 'LA', 'LAO PEOPLE''S DEMOCRATIC REPUBLIC', 'Lao People''s Democratic Republic', 'LAO', 418, 856),
(117, 'LV', 'LATVIA', 'Latvia', 'LVA', 428, 371),
(118, 'LB', 'LEBANON', 'Lebanon', 'LBN', 422, 961),
(119, 'LS', 'LESOTHO', 'Lesotho', 'LSO', 426, 266),
(120, 'LR', 'LIBERIA', 'Liberia', 'LBR', 430, 231),
(121, 'LY', 'LIBYAN ARAB JAMAHIRIYA', 'Libyan Arab Jamahiriya', 'LBY', 434, 218),
(122, 'LI', 'LIECHTENSTEIN', 'Liechtenstein', 'LIE', 438, 423),
(123, 'LT', 'LITHUANIA', 'Lithuania', 'LTU', 440, 370),
(124, 'LU', 'LUXEMBOURG', 'Luxembourg', 'LUX', 442, 352),
(125, 'MO', 'MACAO', 'Macao', 'MAC', 446, 853),
(126, 'MK', 'MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF', 'Macedonia, the Former Yugoslav Republic of', 'MKD', 807, 389),
(127, 'MG', 'MADAGASCAR', 'Madagascar', 'MDG', 450, 261),
(128, 'MW', 'MALAWI', 'Malawi', 'MWI', 454, 265),
(129, 'MY', 'MALAYSIA', 'Malaysia', 'MYS', 458, 60),
(130, 'MV', 'MALDIVES', 'Maldives', 'MDV', 462, 960),
(131, 'ML', 'MALI', 'Mali', 'MLI', 466, 223),
(132, 'MT', 'MALTA', 'Malta', 'MLT', 470, 356),
(133, 'MH', 'MARSHALL ISLANDS', 'Marshall Islands', 'MHL', 584, 692),
(134, 'MQ', 'MARTINIQUE', 'Martinique', 'MTQ', 474, 596),
(135, 'MR', 'MAURITANIA', 'Mauritania', 'MRT', 478, 222),
(136, 'MU', 'MAURITIUS', 'Mauritius', 'MUS', 480, 230),
(137, 'YT', 'MAYOTTE', 'Mayotte', NULL, NULL, 269),
(138, 'MX', 'MEXICO', 'Mexico', 'MEX', 484, 52),
(139, 'FM', 'MICRONESIA, FEDERATED STATES OF', 'Micronesia, Federated States of', 'FSM', 583, 691),
(140, 'MD', 'MOLDOVA, REPUBLIC OF', 'Moldova, Republic of', 'MDA', 498, 373),
(141, 'MC', 'MONACO', 'Monaco', 'MCO', 492, 377),
(142, 'MN', 'MONGOLIA', 'Mongolia', 'MNG', 496, 976),
(143, 'MS', 'MONTSERRAT', 'Montserrat', 'MSR', 500, 1664),
(144, 'MA', 'MOROCCO', 'Morocco', 'MAR', 504, 212),
(145, 'MZ', 'MOZAMBIQUE', 'Mozambique', 'MOZ', 508, 258),
(146, 'MM', 'MYANMAR', 'Myanmar', 'MMR', 104, 95),
(147, 'NA', 'NAMIBIA', 'Namibia', 'NAM', 516, 264),
(148, 'NR', 'NAURU', 'Nauru', 'NRU', 520, 674),
(149, 'NP', 'NEPAL', 'Nepal', 'NPL', 524, 977),
(150, 'NL', 'NETHERLANDS', 'Netherlands', 'NLD', 528, 31),
(151, 'AN', 'NETHERLANDS ANTILLES', 'Netherlands Antilles', 'ANT', 530, 599),
(152, 'NC', 'NEW CALEDONIA', 'New Caledonia', 'NCL', 540, 687),
(153, 'NZ', 'NEW ZEALAND', 'New Zealand', 'NZL', 554, 64),
(154, 'NI', 'NICARAGUA', 'Nicaragua', 'NIC', 558, 505),
(155, 'NE', 'NIGER', 'Niger', 'NER', 562, 227),
(156, 'NG', 'NIGERIA', 'Nigeria', 'NGA', 566, 234),
(157, 'NU', 'NIUE', 'Niue', 'NIU', 570, 683),
(158, 'NF', 'NORFOLK ISLAND', 'Norfolk Island', 'NFK', 574, 672),
(159, 'MP', 'NORTHERN MARIANA ISLANDS', 'Northern Mariana Islands', 'MNP', 580, 1670),
(160, 'NO', 'NORWAY', 'Norway', 'NOR', 578, 47),
(161, 'OM', 'OMAN', 'Oman', 'OMN', 512, 968),
(162, 'PK', 'PAKISTAN', 'Pakistan', 'PAK', 586, 92),
(163, 'PW', 'PALAU', 'Palau', 'PLW', 585, 680),
(164, 'PS', 'PALESTINIAN TERRITORY, OCCUPIED', 'Palestinian Territory, Occupied', NULL, NULL, 970),
(165, 'PA', 'PANAMA', 'Panama', 'PAN', 591, 507),
(166, 'PG', 'PAPUA NEW GUINEA', 'Papua New Guinea', 'PNG', 598, 675),
(167, 'PY', 'PARAGUAY', 'Paraguay', 'PRY', 600, 595),
(168, 'PE', 'PERU', 'Peru', 'PER', 604, 51),
(169, 'PH', 'PHILIPPINES', 'Philippines', 'PHL', 608, 63),
(170, 'PN', 'PITCAIRN', 'Pitcairn', 'PCN', 612, 0),
(171, 'PL', 'POLAND', 'Poland', 'POL', 616, 48),
(172, 'PT', 'PORTUGAL', 'Portugal', 'PRT', 620, 351),
(173, 'PR', 'PUERTO RICO', 'Puerto Rico', 'PRI', 630, 1787),
(174, 'QA', 'QATAR', 'Qatar', 'QAT', 634, 974),
(175, 'RE', 'REUNION', 'Reunion', 'REU', 638, 262),
(176, 'RO', 'ROMANIA', 'Romania', 'ROM', 642, 40),
(177, 'RU', 'RUSSIAN FEDERATION', 'Russian Federation', 'RUS', 643, 70),
(178, 'RW', 'RWANDA', 'Rwanda', 'RWA', 646, 250),
(179, 'SH', 'SAINT HELENA', 'Saint Helena', 'SHN', 654, 290),
(180, 'KN', 'SAINT KITTS AND NEVIS', 'Saint Kitts and Nevis', 'KNA', 659, 1869),
(181, 'LC', 'SAINT LUCIA', 'Saint Lucia', 'LCA', 662, 1758),
(182, 'PM', 'SAINT PIERRE AND MIQUELON', 'Saint Pierre and Miquelon', 'SPM', 666, 508),
(183, 'VC', 'SAINT VINCENT AND THE GRENADINES', 'Saint Vincent and the Grenadines', 'VCT', 670, 1784),
(184, 'WS', 'SAMOA', 'Samoa', 'WSM', 882, 684),
(185, 'SM', 'SAN MARINO', 'San Marino', 'SMR', 674, 378),
(186, 'ST', 'SAO TOME AND PRINCIPE', 'Sao Tome and Principe', 'STP', 678, 239),
(187, 'SA', 'SAUDI ARABIA', 'Saudi Arabia', 'SAU', 682, 966),
(188, 'SN', 'SENEGAL', 'Senegal', 'SEN', 686, 221),
(189, 'CS', 'SERBIA AND MONTENEGRO', 'Serbia and Montenegro', NULL, NULL, 381),
(190, 'SC', 'SEYCHELLES', 'Seychelles', 'SYC', 690, 248),
(191, 'SL', 'SIERRA LEONE', 'Sierra Leone', 'SLE', 694, 232),
(192, 'SG', 'SINGAPORE', 'Singapore', 'SGP', 702, 65),
(193, 'SK', 'SLOVAKIA', 'Slovakia', 'SVK', 703, 421),
(194, 'SI', 'SLOVENIA', 'Slovenia', 'SVN', 705, 386),
(195, 'SB', 'SOLOMON ISLANDS', 'Solomon Islands', 'SLB', 90, 677),
(196, 'SO', 'SOMALIA', 'Somalia', 'SOM', 706, 252),
(197, 'ZA', 'SOUTH AFRICA', 'South Africa', 'ZAF', 710, 27),
(198, 'GS', 'SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS', 'South Georgia and the South Sandwich Islands', NULL, NULL, 0),
(199, 'ES', 'SPAIN', 'Spain', 'ESP', 724, 34),
(200, 'LK', 'SRI LANKA', 'Sri Lanka', 'LKA', 144, 94),
(201, 'SD', 'SUDAN', 'Sudan', 'SDN', 736, 249),
(202, 'SR', 'SURINAME', 'Suriname', 'SUR', 740, 597),
(203, 'SJ', 'SVALBARD AND JAN MAYEN', 'Svalbard and Jan Mayen', 'SJM', 744, 47),
(204, 'SZ', 'SWAZILAND', 'Swaziland', 'SWZ', 748, 268),
(205, 'SE', 'SWEDEN', 'Sweden', 'SWE', 752, 46),
(206, 'CH', 'SWITZERLAND', 'Switzerland', 'CHE', 756, 41),
(207, 'SY', 'SYRIAN ARAB REPUBLIC', 'Syrian Arab Republic', 'SYR', 760, 963),
(208, 'TW', 'TAIWAN, PROVINCE OF CHINA', 'Taiwan, Province of China', 'TWN', 158, 886),
(209, 'TJ', 'TAJIKISTAN', 'Tajikistan', 'TJK', 762, 992),
(210, 'TZ', 'TANZANIA, UNITED REPUBLIC OF', 'Tanzania, United Republic of', 'TZA', 834, 255),
(211, 'TH', 'THAILAND', 'Thailand', 'THA', 764, 66),
(212, 'TL', 'TIMOR-LESTE', 'Timor-Leste', NULL, NULL, 670),
(213, 'TG', 'TOGO', 'Togo', 'TGO', 768, 228),
(214, 'TK', 'TOKELAU', 'Tokelau', 'TKL', 772, 690),
(215, 'TO', 'TONGA', 'Tonga', 'TON', 776, 676),
(216, 'TT', 'TRINIDAD AND TOBAGO', 'Trinidad and Tobago', 'TTO', 780, 1868),
(217, 'TN', 'TUNISIA', 'Tunisia', 'TUN', 788, 216),
(218, 'TR', 'TURKEY', 'Turkey', 'TUR', 792, 90),
(219, 'TM', 'TURKMENISTAN', 'Turkmenistan', 'TKM', 795, 7370),
(220, 'TC', 'TURKS AND CAICOS ISLANDS', 'Turks and Caicos Islands', 'TCA', 796, 1649),
(221, 'TV', 'TUVALU', 'Tuvalu', 'TUV', 798, 688),
(222, 'UG', 'UGANDA', 'Uganda', 'UGA', 800, 256),
(223, 'UA', 'UKRAINE', 'Ukraine', 'UKR', 804, 380),
(224, 'AE', 'UNITED ARAB EMIRATES', 'United Arab Emirates', 'ARE', 784, 971),
(225, 'GB', 'UNITED KINGDOM', 'United Kingdom', 'GBR', 826, 44),
(226, 'US', 'UNITED STATES', 'United States', 'USA', 840, 1),
(227, 'UM', 'UNITED STATES MINOR OUTLYING ISLANDS', 'United States Minor Outlying Islands', NULL, NULL, 1),
(228, 'UY', 'URUGUAY', 'Uruguay', 'URY', 858, 598),
(229, 'UZ', 'UZBEKISTAN', 'Uzbekistan', 'UZB', 860, 998),
(230, 'VU', 'VANUATU', 'Vanuatu', 'VUT', 548, 678),
(231, 'VE', 'VENEZUELA', 'Venezuela', 'VEN', 862, 58),
(232, 'VN', 'VIET NAM', 'Viet Nam', 'VNM', 704, 84),
(233, 'VG', 'VIRGIN ISLANDS, BRITISH', 'Virgin Islands, British', 'VGB', 92, 1284),
(234, 'VI', 'VIRGIN ISLANDS, U.S.', 'Virgin Islands, U.s.', 'VIR', 850, 1340),
(235, 'WF', 'WALLIS AND FUTUNA', 'Wallis and Futuna', 'WLF', 876, 681),
(236, 'EH', 'WESTERN SAHARA', 'Western Sahara', 'ESH', 732, 212),
(237, 'YE', 'YEMEN', 'Yemen', 'YEM', 887, 967),
(238, 'ZM', 'ZAMBIA', 'Zambia', 'ZMB', 894, 260),
(239, 'ZW', 'ZIMBABWE', 'Zimbabwe', 'ZWE', 716, 263);

-- --------------------------------------------------------

--
-- Table structure for table `fund_manager_account`
--

DROP TABLE IF EXISTS `fund_manager_account`;
CREATE TABLE `fund_manager_account` (
  `id` bigint(255) NOT NULL,
  `account_number` varchar(255) NOT NULL,
  `id_investment_management_type` int(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `value_date` varchar(255) NOT NULL,
  `spread` varchar(255) NOT NULL,
  `is_traded` int(1) NOT NULL DEFAULT '0',
  `is_authorised` int(1) NOT NULL DEFAULT '0',
  `ordered_by` int(255) NOT NULL,
  `traded_by` int(255) NOT NULL,
  `authorised_by` int(255) NOT NULL,
  `id_company` int(255) NOT NULL,
  `id_branch` int(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `date_created` varchar(255) NOT NULL,
  `date_traded` varchar(255) NOT NULL,
  `date_authorised` varchar(255) NOT NULL,
  `id_client` int(255) NOT NULL,
  `remarks` text NOT NULL,
  `instruction` text NOT NULL,
  `redemption` text NOT NULL,
  `number_days` varchar(255) NOT NULL,
  `maturity_date` varchar(255) NOT NULL,
  `daily_interest` varchar(255) NOT NULL,
  `id_liability_order` int(255) NOT NULL,
  `amount_left` varchar(255) NOT NULL,
  `stopped` int(1) NOT NULL DEFAULT '0',
  `days_dropped` int(1) NOT NULL DEFAULT '0',
  `previous` int(255) NOT NULL DEFAULT '0',
  `is_fund` int(5) NOT NULL DEFAULT '0',
  `id_instrument_code` int(255) NOT NULL,
  `id_asset_category` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `fund_manager_account`
--

TRUNCATE TABLE `fund_manager_account`;
-- --------------------------------------------------------

--
-- Table structure for table `fund_manager_daily_interest_transactions`
--

DROP TABLE IF EXISTS `fund_manager_daily_interest_transactions`;
CREATE TABLE `fund_manager_daily_interest_transactions` (
  `id` bigint(255) NOT NULL,
  `id_order` int(255) NOT NULL,
  `interest` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `day` int(255) NOT NULL,
  `is_fund` int(5) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `fund_manager_daily_interest_transactions`
--

TRUNCATE TABLE `fund_manager_daily_interest_transactions`;
--
-- Dumping data for table `fund_manager_daily_interest_transactions`
--

INSERT INTO `fund_manager_daily_interest_transactions` (`id`, `id_order`, `interest`, `date`, `day`, `is_fund`) VALUES
(1, 1, '38.35616438356165', '1472256000', 1, 0),
(2, 1, '38.35616438356165', '1472342400', 2, 0),
(3, 1, '38.35616438356165', '1472428800', 3, 0),
(4, 1, '38.35616438356165', '1472515200', 4, 0),
(5, 1, '38.35616438356165', '1472601600', 5, 0),
(6, 1, '38.35616438356165', '1472688000', 6, 0),
(7, 1, '38.35616438356165', '1472774400', 7, 0),
(8, 1, '38.35616438356165', '1472860800', 8, 0),
(9, 1, '38.35616438356165', '1472947200', 9, 0),
(10, 1, '38.35616438356165', '1473033600', 10, 0),
(11, 1, '38.35616438356165', '1473120000', 11, 0),
(12, 1, '38.35616438356165', '1473206400', 12, 0),
(13, 1, '38.35616438356165', '1473292800', 13, 0),
(14, 1, '38.35616438356165', '1473379200', 14, 0),
(15, 1, '38.35616438356165', '1473465600', 15, 0),
(16, 1, '38.35616438356165', '1473552000', 16, 0),
(17, 1, '38.35616438356165', '1473638400', 17, 0),
(18, 1, '38.35616438356165', '1473724800', 18, 0),
(19, 1, '38.35616438356165', '1473811200', 19, 0),
(20, 1, '38.35616438356165', '1473897600', 20, 0),
(21, 1, '38.35616438356165', '1473984000', 21, 0),
(22, 1, '38.35616438356165', '1474070400', 22, 0),
(23, 1, '38.35616438356165', '1474156800', 23, 0),
(24, 1, '38.35616438356165', '1474243200', 24, 0),
(25, 1, '38.35616438356165', '1474329600', 25, 0),
(26, 1, '38.35616438356165', '1474416000', 26, 0),
(27, 1, '38.35616438356165', '1474502400', 27, 0),
(28, 1, '38.35616438356165', '1474588800', 28, 0),
(29, 1, '38.35616438356165', '1474675200', 29, 0),
(30, 1, '38.35616438356165', '1474761600', 30, 0),
(31, 1, '38.35616438356165', '1474848000', 31, 0),
(32, 1, '38.35616438356165', '1474934400', 32, 0),
(33, 1, '38.35616438356165', '1475020800', 33, 0),
(34, 1, '38.35616438356165', '1475107200', 34, 0),
(35, 1, '38.35616438356165', '1475193600', 35, 0),
(36, 1, '38.35616438356165', '1475280000', 36, 0),
(37, 1, '38.35616438356165', '1475366400', 37, 0),
(38, 1, '38.35616438356165', '1475452800', 38, 0),
(39, 1, '38.35616438356165', '1475539200', 39, 0),
(40, 1, '38.35616438356165', '1475625600', 40, 0),
(41, 1, '38.35616438356165', '1475712000', 41, 0),
(42, 1, '38.35616438356165', '1475798400', 42, 0),
(43, 1, '38.35616438356165', '1475884800', 43, 0),
(44, 1, '38.35616438356165', '1475971200', 44, 0),
(45, 1, '38.35616438356165', '1476057600', 45, 0),
(46, 1, '38.35616438356165', '1476144000', 46, 0),
(47, 1, '38.35616438356165', '1476230400', 47, 0),
(48, 1, '38.35616438356165', '1476316800', 48, 0),
(49, 1, '38.35616438356165', '1476403200', 49, 0),
(50, 1, '38.35616438356165', '1476489600', 50, 0),
(51, 1, '38.35616438356165', '1476576000', 51, 0),
(52, 1, '38.35616438356165', '1476662400', 52, 0),
(53, 1, '38.35616438356165', '1476748800', 53, 0),
(54, 1, '38.35616438356165', '1476835200', 54, 0),
(55, 1, '38.35616438356165', '1476921600', 55, 0),
(56, 1, '38.35616438356165', '1477008000', 56, 0),
(57, 1, '38.35616438356165', '1477094400', 57, 0),
(58, 1, '38.35616438356165', '1477180800', 58, 0),
(59, 1, '38.35616438356165', '1477267200', 59, 0),
(60, 1, '38.35616438356165', '1477353600', 60, 0),
(61, 1, '38.35616438356165', '1477440000', 61, 0),
(62, 1, '38.35616438356165', '1477526400', 62, 0),
(63, 1, '38.35616438356165', '1477612800', 63, 0),
(64, 1, '38.35616438356165', '1477699200', 64, 0),
(65, 1, '38.35616438356165', '1477785600', 65, 0),
(66, 1, '38.35616438356165', '1477872000', 66, 0),
(67, 1, '38.35616438356165', '1477958400', 67, 0),
(68, 1, '38.35616438356165', '1478044800', 68, 0),
(69, 1, '38.35616438356165', '1478131200', 69, 0),
(70, 1, '38.35616438356165', '1478217600', 70, 0),
(71, 1, '38.35616438356165', '1478304000', 71, 0),
(72, 1, '38.35616438356165', '1478390400', 72, 0),
(73, 1, '38.35616438356165', '1478476800', 73, 0),
(74, 1, '38.35616438356165', '1478563200', 74, 0),
(75, 1, '38.35616438356165', '1478649600', 75, 0),
(76, 1, '38.35616438356165', '1478736000', 76, 0),
(77, 1, '38.35616438356165', '1478822400', 77, 0),
(78, 1, '38.35616438356165', '1478908800', 78, 0),
(79, 1, '38.35616438356165', '1478995200', 79, 0),
(80, 1, '38.35616438356165', '1479081600', 80, 0),
(81, 1, '38.35616438356165', '1479168000', 81, 0),
(82, 1, '38.35616438356165', '1479254400', 82, 0),
(83, 1, '38.35616438356165', '1479340800', 83, 0),
(84, 1, '38.35616438356165', '1479427200', 84, 0),
(85, 1, '38.35616438356165', '1479513600', 85, 0),
(86, 1, '38.35616438356165', '1479600000', 86, 0),
(87, 1, '38.35616438356165', '1479686400', 87, 0),
(88, 1, '38.35616438356165', '1479772800', 88, 0),
(89, 1, '38.35616438356165', '1479859200', 89, 0),
(90, 1, '38.35616438356165', '1479945600', 90, 0),
(91, 1, '38.35616438356165', '1480032000', 91, 0),
(92, 3, '8.914739726027397', '1464825600', 1, 0),
(93, 3, '8.914739726027397', '1464912000', 2, 0),
(94, 3, '8.914739726027397', '1464998400', 3, 0),
(95, 3, '8.914739726027397', '1465084800', 4, 0),
(96, 3, '8.914739726027397', '1465171200', 5, 0),
(97, 3, '8.914739726027397', '1465257600', 6, 0),
(98, 3, '8.914739726027397', '1465344000', 7, 0),
(99, 3, '8.914739726027397', '1465430400', 8, 0),
(100, 3, '8.914739726027397', '1465516800', 9, 0),
(101, 3, '8.914739726027397', '1465603200', 10, 0),
(102, 3, '8.914739726027397', '1465689600', 11, 0),
(103, 3, '8.914739726027397', '1465776000', 12, 0),
(104, 3, '8.914739726027397', '1465862400', 13, 0),
(105, 3, '8.914739726027397', '1465948800', 14, 0),
(106, 3, '8.914739726027397', '1466035200', 15, 0),
(107, 3, '8.914739726027397', '1466121600', 16, 0),
(108, 3, '8.914739726027397', '1466208000', 17, 0),
(109, 3, '8.914739726027397', '1466294400', 18, 0),
(110, 3, '8.914739726027397', '1466380800', 19, 0),
(111, 3, '8.914739726027397', '1466467200', 20, 0),
(112, 3, '8.914739726027397', '1466553600', 21, 0),
(113, 3, '8.914739726027397', '1466640000', 22, 0),
(114, 3, '8.914739726027397', '1466726400', 23, 0),
(115, 3, '8.914739726027397', '1466812800', 24, 0),
(116, 3, '8.914739726027397', '1466899200', 25, 0),
(117, 3, '8.914739726027397', '1466985600', 26, 0),
(118, 3, '8.914739726027397', '1467072000', 27, 0),
(119, 3, '8.914739726027397', '1467158400', 28, 0),
(120, 3, '8.914739726027397', '1467244800', 29, 0),
(121, 3, '8.914739726027397', '1467331200', 30, 0),
(122, 3, '8.914739726027397', '1467417600', 31, 0),
(123, 3, '8.914739726027397', '1467504000', 32, 0),
(124, 3, '8.914739726027397', '1467590400', 33, 0),
(125, 3, '8.914739726027397', '1467676800', 34, 0),
(126, 3, '8.914739726027397', '1467763200', 35, 0),
(127, 3, '8.914739726027397', '1467849600', 36, 0),
(128, 3, '8.914739726027397', '1467936000', 37, 0),
(129, 3, '8.914739726027397', '1468022400', 38, 0),
(130, 3, '8.914739726027397', '1468108800', 39, 0),
(131, 3, '8.914739726027397', '1468195200', 40, 0),
(132, 3, '8.914739726027397', '1468281600', 41, 0),
(133, 3, '8.914739726027397', '1468368000', 42, 0),
(134, 3, '8.914739726027397', '1468454400', 43, 0),
(135, 3, '8.914739726027397', '1468540800', 44, 0),
(136, 3, '8.914739726027397', '1468627200', 45, 0),
(137, 3, '8.914739726027397', '1468713600', 46, 0),
(138, 3, '8.914739726027397', '1468800000', 47, 0),
(139, 3, '8.914739726027397', '1468886400', 48, 0),
(140, 3, '8.914739726027397', '1468972800', 49, 0),
(141, 3, '8.914739726027397', '1469059200', 50, 0),
(142, 3, '8.914739726027397', '1469145600', 51, 0),
(143, 3, '8.914739726027397', '1469232000', 52, 0),
(144, 3, '8.914739726027397', '1469318400', 53, 0),
(145, 3, '8.914739726027397', '1469404800', 54, 0),
(146, 3, '8.914739726027397', '1469491200', 55, 0),
(147, 3, '8.914739726027397', '1469577600', 56, 0),
(148, 3, '8.914739726027397', '1469664000', 57, 0),
(149, 3, '8.914739726027397', '1469750400', 58, 0),
(150, 3, '8.914739726027397', '1469836800', 59, 0),
(151, 3, '8.914739726027397', '1469923200', 60, 0),
(152, 3, '8.914739726027397', '1470009600', 61, 0),
(153, 3, '8.914739726027397', '1470096000', 62, 0),
(154, 3, '8.914739726027397', '1470182400', 63, 0),
(155, 3, '8.914739726027397', '1470268800', 64, 0),
(156, 3, '8.914739726027397', '1470355200', 65, 0),
(157, 3, '8.914739726027397', '1470441600', 66, 0),
(158, 3, '8.914739726027397', '1470528000', 67, 0),
(159, 3, '8.914739726027397', '1470614400', 68, 0),
(160, 3, '8.914739726027397', '1470700800', 69, 0),
(161, 3, '8.914739726027397', '1470787200', 70, 0),
(162, 3, '8.914739726027397', '1470873600', 71, 0),
(163, 3, '8.914739726027397', '1470960000', 72, 0),
(164, 3, '8.914739726027397', '1471046400', 73, 0),
(165, 3, '8.914739726027397', '1471132800', 74, 0),
(166, 3, '8.914739726027397', '1471219200', 75, 0),
(167, 3, '8.914739726027397', '1471305600', 76, 0),
(168, 3, '8.914739726027397', '1471392000', 77, 0),
(169, 3, '8.914739726027397', '1471478400', 78, 0),
(170, 3, '8.914739726027397', '1471564800', 79, 0),
(171, 3, '8.914739726027397', '1471651200', 80, 0),
(172, 3, '8.914739726027397', '1471737600', 81, 0),
(173, 3, '8.914739726027397', '1471824000', 82, 0),
(174, 3, '8.914739726027397', '1471910400', 83, 0),
(175, 3, '8.914739726027397', '1471996800', 84, 0),
(176, 3, '8.914739726027397', '1472083200', 85, 0),
(177, 3, '8.914739726027397', '1472169600', 86, 0),
(178, 3, '8.914739726027397', '1472256000', 87, 0),
(179, 3, '8.914739726027397', '1472342400', 88, 0),
(180, 3, '8.914739726027397', '1472428800', 89, 0),
(181, 3, '8.914739726027397', '1472515200', 90, 0),
(182, 3, '8.914739726027397', '1472601600', 91, 0);

-- --------------------------------------------------------

--
-- Table structure for table `fund_manager_orders`
--

DROP TABLE IF EXISTS `fund_manager_orders`;
CREATE TABLE `fund_manager_orders` (
  `id` int(255) NOT NULL,
  `account_number` varchar(255) NOT NULL,
  `id_investment_management_type` int(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `value_date` varchar(255) NOT NULL,
  `spread` varchar(255) NOT NULL,
  `is_traded` int(1) NOT NULL DEFAULT '0',
  `is_authorised` int(1) NOT NULL DEFAULT '0',
  `ordered_by` int(255) NOT NULL,
  `traded_by` int(255) NOT NULL,
  `authorised_by` int(255) NOT NULL,
  `id_company` int(255) NOT NULL,
  `id_branch` int(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `date_created` varchar(255) NOT NULL,
  `date_traded` varchar(255) NOT NULL,
  `date_authorised` varchar(255) NOT NULL,
  `id_client` int(255) NOT NULL,
  `remarks` text NOT NULL,
  `instruction` text NOT NULL,
  `redemption` text NOT NULL,
  `number_days` varchar(255) NOT NULL,
  `maturity_date` varchar(255) NOT NULL,
  `daily_interest` varchar(255) NOT NULL,
  `stopped` int(1) NOT NULL DEFAULT '0',
  `days_dropped` int(1) NOT NULL DEFAULT '0',
  `previous` int(255) NOT NULL DEFAULT '0',
  `is_fund` int(5) NOT NULL DEFAULT '0',
  `id_asset_category` int(255) NOT NULL,
  `id_instrument_code` int(255) NOT NULL,
  `investment_code` varchar(255) DEFAULT NULL,
  `certificate_printed` int(1) NOT NULL DEFAULT '0',
  `id_bank` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `fund_manager_orders`
--

TRUNCATE TABLE `fund_manager_orders`;
--
-- Dumping data for table `fund_manager_orders`
--

INSERT INTO `fund_manager_orders` (`id`, `account_number`, `id_investment_management_type`, `rate`, `value_date`, `spread`, `is_traded`, `is_authorised`, `ordered_by`, `traded_by`, `authorised_by`, `id_company`, `id_branch`, `amount`, `date_created`, `date_traded`, `date_authorised`, `id_client`, `remarks`, `instruction`, `redemption`, `number_days`, `maturity_date`, `daily_interest`, `stopped`, `days_dropped`, `previous`, `is_fund`, `id_asset_category`, `id_instrument_code`, `investment_code`, `certificate_printed`, `id_bank`) VALUES
(1, '100000000003', 0, '28', '1472162400', '0', 1, 1, 11, 11, 11, 2, 2, '50000', '1480689824', '1480689844', '1480689871', 6, '', '2', '1', '91', '1480032000', '38.35616438356165', 1, 91, 0, 1, 3, 4, '100000000001', 1, 3),
(3, '100000000003', 0, '28', '1464732000', '0', 1, 1, 11, 11, 11, 2, 2, '11621', '1480714509', '1480714522', '1480714531', 6, '', '2', '1', '91', '1472601600', '8.914739726027397', 1, 91, 0, 1, 3, 4, '10000000002', 1, 3),
(4, '100000000003', 0, '28', '1472601600', '0', 1, 0, 0, 0, 0, 2, 2, '11621', '1480718132', '1480718132', '1480718132', 6, 'This Order Was Generated By The System Based On The Initial Instructions', '2', '1', '91', '1488580532', '8.914739726027397', 0, 0, 3, 1, 3, 4, '10000000002', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `fund_manager_transactions`
--

DROP TABLE IF EXISTS `fund_manager_transactions`;
CREATE TABLE `fund_manager_transactions` (
  `id` int(255) NOT NULL,
  `id_asset_category` int(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `id_placement` int(255) NOT NULL,
  `id_transaction_type` int(255) NOT NULL,
  `id_user` int(255) NOT NULL,
  `is_authorised` int(1) NOT NULL DEFAULT '0',
  `authorised_by` int(255) NOT NULL,
  `id_company` int(255) NOT NULL,
  `id_branch` int(255) NOT NULL,
  `id_investment_account` int(255) NOT NULL,
  `id_order` int(255) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `stamp` varchar(255) NOT NULL,
  `is_fund` int(5) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `fund_manager_transactions`
--

TRUNCATE TABLE `fund_manager_transactions`;
--
-- Dumping data for table `fund_manager_transactions`
--

INSERT INTO `fund_manager_transactions` (`id`, `id_asset_category`, `amount`, `id_placement`, `id_transaction_type`, `id_user`, `is_authorised`, `authorised_by`, `id_company`, `id_branch`, `id_investment_account`, `id_order`, `remarks`, `stamp`, `is_fund`) VALUES
(1, 4, '50000', 1, 2, 11, 1, 11, 2, 2, 0, 1, 'New Placement', '1480689871', 0),
(2, 4, '1150.68480', 1, 2, 0, 1, 0, 2, 2, 0, 1, 'Depositing Interest After Redemption Period', '1480689871', 0),
(3, 4, '1150.68480', 1, 2, 0, 1, 0, 2, 2, 0, 1, 'Depositing Interest After Redemption Period', '1480689871', 0),
(4, 4, '1150.68480', 1, 2, 0, 1, 0, 2, 2, 0, 1, 'Depositing Interest After Redemption Period', '1480689871', 0),
(5, 4, '11621', 3, 2, 11, 1, 11, 2, 2, 0, 3, 'New Placement', '1480714531', 0),
(6, 4, '267.44190', 3, 2, 0, 1, 0, 2, 2, 0, 3, 'Being Interest After Redemption Period', '1480714531', 0),
(7, 4, '267.44190', 3, 2, 0, 1, 0, 2, 2, 0, 3, 'Being Interest After Redemption Period', '1480714531', 0),
(8, 4, '267.44190', 3, 2, 0, 1, 0, 2, 2, 0, 3, 'Being Interest After Redemption Period', '1480714532', 0);

-- --------------------------------------------------------

--
-- Table structure for table `id_card_types`
--

DROP TABLE IF EXISTS `id_card_types`;
CREATE TABLE `id_card_types` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `issuer` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `id_card_types`
--

TRUNCATE TABLE `id_card_types`;
--
-- Dumping data for table `id_card_types`
--

INSERT INTO `id_card_types` (`id`, `name`, `issuer`) VALUES
(1, 'Voter''s Identification Card', ''),
(2, 'Passport', ''),
(3, 'National Identification Card', '');

-- --------------------------------------------------------

--
-- Table structure for table `instrument_codes`
--

DROP TABLE IF EXISTS `instrument_codes`;
CREATE TABLE `instrument_codes` (
  `id` int(255) NOT NULL,
  `issuer` varchar(255) NOT NULL,
  `tenor` varchar(255) NOT NULL,
  `days` varchar(255) NOT NULL,
  `id_asset_category` int(255) NOT NULL,
  `cost_price` varchar(255) NOT NULL,
  `id_company` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `currency` varchar(255) NOT NULL,
  `currency_symbol` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL DEFAULT '0',
  `value_date` varchar(255) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `instrument_codes`
--

TRUNCATE TABLE `instrument_codes`;
--
-- Dumping data for table `instrument_codes`
--

INSERT INTO `instrument_codes` (`id`, `issuer`, `tenor`, `days`, `id_asset_category`, `cost_price`, `id_company`, `name`, `currency`, `currency_symbol`, `rate`, `value_date`) VALUES
(1, 'Bank Of Ghana', 'Two Years', '365', 1, '100', 1, 'GH/F/45622329', 'Ghana Cedi', 'GhC', '0', '0'),
(2, 'The Royal Bank', 'One Year', '366', 2, '100', 1, 'etrewehhhhh', 'Ghana Cedi', 'GhC', '0', '0'),
(3, '1', '253', '563', 1, '', 1, 'test second', 'Ghana Ced', 'GhC', '25', '05/27/2016'),
(4, '2', '91', '91', 3, '20000', 2, 'Fixed Deposit', 'Ghana Ced', 'GhC', '28', '07/13/2016'),
(5, '3', '182', '182', 4, '', 3, '182 day Beige FD', 'Ghana Ced', 'GhC', '', ''),
(6, '3', '182', '150', 4, '', 3, '182 day Beige FD', 'Ghana Ced', 'GhC', '', ''),
(7, '4', '182', '150', 3, '', 2, '91 day Beige FD', 'Ghana Ced', 'GhC', '', ''),
(8, '5', '182', '182', 7, '', 2, '182 OAK FIXED DEPOSITS', 'Ghana Ced', 'GhC', '', ''),
(9, '2', '91', '365', 7, '', 2, '91 OAK FIXED DEPOSITS', 'Ghana Ced', 'GhC', '', ''),
(10, '6', '91', '91', 4, '', 3, '91 day Mcottley FD', 'Ghana Ced', 'GhC', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `investement_management_denominator`
--

DROP TABLE IF EXISTS `investement_management_denominator`;
CREATE TABLE `investement_management_denominator` (
  `id` int(11) NOT NULL,
  `days` varchar(255) NOT NULL,
  `id_branch` int(11) NOT NULL,
  `id_company` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `investement_management_denominator`
--

TRUNCATE TABLE `investement_management_denominator`;
-- --------------------------------------------------------

--
-- Table structure for table `investment_assets_recapitilisation_trail`
--

DROP TABLE IF EXISTS `investment_assets_recapitilisation_trail`;
CREATE TABLE `investment_assets_recapitilisation_trail` (
  `id` int(255) NOT NULL,
  `id_asset_order` int(255) NOT NULL,
  `prev_amount` varchar(255) NOT NULL,
  `interest_recapitalised` varchar(255) NOT NULL,
  `day_to_drop` int(255) NOT NULL,
  `day_recapitilises` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `investment_assets_recapitilisation_trail`
--

TRUNCATE TABLE `investment_assets_recapitilisation_trail`;
-- --------------------------------------------------------

--
-- Table structure for table `investment_client_portfolio`
--

DROP TABLE IF EXISTS `investment_client_portfolio`;
CREATE TABLE `investment_client_portfolio` (
  `id` int(255) NOT NULL,
  `id_client` int(255) NOT NULL,
  `id_asset_category` int(255) NOT NULL,
  `percentage` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `investment_client_portfolio`
--

TRUNCATE TABLE `investment_client_portfolio`;
-- --------------------------------------------------------

--
-- Table structure for table `investment_liability_daily_interest_transactions`
--

DROP TABLE IF EXISTS `investment_liability_daily_interest_transactions`;
CREATE TABLE `investment_liability_daily_interest_transactions` (
  `id` bigint(255) NOT NULL,
  `id_order` int(255) NOT NULL,
  `interest` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `day` int(255) NOT NULL,
  `is_fund` int(5) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `investment_liability_daily_interest_transactions`
--

TRUNCATE TABLE `investment_liability_daily_interest_transactions`;
--
-- Dumping data for table `investment_liability_daily_interest_transactions`
--

INSERT INTO `investment_liability_daily_interest_transactions` (`id`, `id_order`, `interest`, `date`, `day`, `is_fund`) VALUES
(1, 1, '38.35616438356165', '1472256000', 1, 0),
(2, 1, '38.35616438356165', '1472342400', 2, 0),
(3, 1, '38.35616438356165', '1472428800', 3, 0),
(4, 1, '38.35616438356165', '1472515200', 4, 0),
(5, 1, '38.35616438356165', '1472601600', 5, 0),
(6, 1, '38.35616438356165', '1472688000', 6, 0),
(7, 1, '38.35616438356165', '1472774400', 7, 0),
(8, 1, '38.35616438356165', '1472860800', 8, 0),
(9, 1, '38.35616438356165', '1472947200', 9, 0),
(10, 1, '38.35616438356165', '1473033600', 10, 0),
(11, 1, '38.35616438356165', '1473120000', 11, 0),
(12, 1, '38.35616438356165', '1473206400', 12, 0),
(13, 1, '38.35616438356165', '1473292800', 13, 0),
(14, 1, '38.35616438356165', '1473379200', 14, 0),
(15, 1, '38.35616438356165', '1473465600', 15, 0),
(16, 1, '38.35616438356165', '1473552000', 16, 0),
(17, 1, '38.35616438356165', '1473638400', 17, 0),
(18, 1, '38.35616438356165', '1473724800', 18, 0),
(19, 1, '38.35616438356165', '1473811200', 19, 0),
(20, 1, '38.35616438356165', '1473897600', 20, 0),
(21, 1, '38.35616438356165', '1473984000', 21, 0),
(22, 1, '38.35616438356165', '1474070400', 22, 0),
(23, 1, '38.35616438356165', '1474156800', 23, 0),
(24, 1, '38.35616438356165', '1474243200', 24, 0),
(25, 1, '38.35616438356165', '1474329600', 25, 0),
(26, 1, '38.35616438356165', '1474416000', 26, 0),
(27, 1, '38.35616438356165', '1474502400', 27, 0),
(28, 1, '38.35616438356165', '1474588800', 28, 0),
(29, 1, '38.35616438356165', '1474675200', 29, 0),
(30, 1, '38.35616438356165', '1474761600', 30, 0),
(31, 1, '38.35616438356165', '1474848000', 31, 0),
(32, 1, '38.35616438356165', '1474934400', 32, 0),
(33, 1, '38.35616438356165', '1475020800', 33, 0),
(34, 1, '38.35616438356165', '1475107200', 34, 0),
(35, 1, '38.35616438356165', '1475193600', 35, 0),
(36, 1, '38.35616438356165', '1475280000', 36, 0),
(37, 1, '38.35616438356165', '1475366400', 37, 0),
(38, 1, '38.35616438356165', '1475452800', 38, 0),
(39, 1, '38.35616438356165', '1475539200', 39, 0),
(40, 1, '38.35616438356165', '1475625600', 40, 0),
(41, 1, '38.35616438356165', '1475712000', 41, 0),
(42, 1, '38.35616438356165', '1475798400', 42, 0),
(43, 1, '38.35616438356165', '1475884800', 43, 0),
(44, 1, '38.35616438356165', '1475971200', 44, 0),
(45, 1, '38.35616438356165', '1476057600', 45, 0),
(46, 1, '38.35616438356165', '1476144000', 46, 0),
(47, 1, '38.35616438356165', '1476230400', 47, 0),
(48, 1, '38.35616438356165', '1476316800', 48, 0),
(49, 1, '38.35616438356165', '1476403200', 49, 0),
(50, 1, '38.35616438356165', '1476489600', 50, 0),
(51, 1, '38.35616438356165', '1476576000', 51, 0),
(52, 1, '38.35616438356165', '1476662400', 52, 0),
(53, 1, '38.35616438356165', '1476748800', 53, 0),
(54, 1, '38.35616438356165', '1476835200', 54, 0),
(55, 1, '38.35616438356165', '1476921600', 55, 0),
(56, 1, '38.35616438356165', '1477008000', 56, 0),
(57, 1, '38.35616438356165', '1477094400', 57, 0),
(58, 1, '38.35616438356165', '1477180800', 58, 0),
(59, 1, '38.35616438356165', '1477267200', 59, 0),
(60, 1, '38.35616438356165', '1477353600', 60, 0),
(61, 1, '38.35616438356165', '1477440000', 61, 0),
(62, 1, '38.35616438356165', '1477526400', 62, 0),
(63, 1, '38.35616438356165', '1477612800', 63, 0),
(64, 1, '38.35616438356165', '1477699200', 64, 0),
(65, 1, '38.35616438356165', '1477785600', 65, 0),
(66, 1, '38.35616438356165', '1477872000', 66, 0),
(67, 1, '38.35616438356165', '1477958400', 67, 0),
(68, 1, '38.35616438356165', '1478044800', 68, 0),
(69, 1, '38.35616438356165', '1478131200', 69, 0),
(70, 1, '38.35616438356165', '1478217600', 70, 0),
(71, 1, '38.35616438356165', '1478304000', 71, 0),
(72, 1, '38.35616438356165', '1478390400', 72, 0),
(73, 1, '38.35616438356165', '1478476800', 73, 0),
(74, 1, '38.35616438356165', '1478563200', 74, 0),
(75, 1, '38.35616438356165', '1478649600', 75, 0),
(76, 1, '38.35616438356165', '1478736000', 76, 0),
(77, 1, '38.35616438356165', '1478822400', 77, 0),
(78, 1, '38.35616438356165', '1478908800', 78, 0),
(79, 1, '38.35616438356165', '1478995200', 79, 0),
(80, 1, '38.35616438356165', '1479081600', 80, 0),
(81, 1, '38.35616438356165', '1479168000', 81, 0),
(82, 1, '38.35616438356165', '1479254400', 82, 0),
(83, 1, '38.35616438356165', '1479340800', 83, 0),
(84, 1, '38.35616438356165', '1479427200', 84, 0),
(85, 1, '38.35616438356165', '1479513600', 85, 0),
(86, 1, '38.35616438356165', '1479600000', 86, 0),
(87, 1, '38.35616438356165', '1479686400', 87, 0),
(88, 1, '38.35616438356165', '1479772800', 88, 0),
(89, 1, '38.35616438356165', '1479859200', 89, 0),
(90, 1, '38.35616438356165', '1479945600', 90, 0),
(91, 1, '38.35616438356165', '1480032000', 91, 0),
(92, 3, '38.35616438356165', '1469318400', 1, 0),
(93, 3, '38.35616438356165', '1469404800', 2, 0),
(94, 3, '38.35616438356165', '1469491200', 3, 0),
(95, 3, '38.35616438356165', '1469577600', 4, 0),
(96, 3, '38.35616438356165', '1469664000', 5, 0),
(97, 3, '38.35616438356165', '1469750400', 6, 0),
(98, 3, '38.35616438356165', '1469836800', 7, 0),
(99, 3, '38.35616438356165', '1469923200', 8, 0),
(100, 3, '38.35616438356165', '1470009600', 9, 0),
(101, 3, '38.35616438356165', '1470096000', 10, 0),
(102, 3, '38.35616438356165', '1470182400', 11, 0),
(103, 3, '38.35616438356165', '1470268800', 12, 0),
(104, 3, '38.35616438356165', '1470355200', 13, 0),
(105, 3, '38.35616438356165', '1470441600', 14, 0),
(106, 3, '38.35616438356165', '1470528000', 15, 0),
(107, 3, '38.35616438356165', '1470614400', 16, 0),
(108, 3, '38.35616438356165', '1470700800', 17, 0),
(109, 3, '38.35616438356165', '1470787200', 18, 0),
(110, 3, '38.35616438356165', '1470873600', 19, 0),
(111, 3, '38.35616438356165', '1470960000', 20, 0),
(112, 3, '38.35616438356165', '1471046400', 21, 0),
(113, 3, '38.35616438356165', '1471132800', 22, 0),
(114, 3, '38.35616438356165', '1471219200', 23, 0),
(115, 3, '38.35616438356165', '1471305600', 24, 0),
(116, 3, '38.35616438356165', '1471392000', 25, 0),
(117, 3, '38.35616438356165', '1471478400', 26, 0),
(118, 3, '38.35616438356165', '1471564800', 27, 0),
(119, 3, '38.35616438356165', '1471651200', 28, 0),
(120, 3, '38.35616438356165', '1471737600', 29, 0),
(121, 3, '38.35616438356165', '1471824000', 30, 0),
(122, 3, '38.35616438356165', '1471910400', 31, 0),
(123, 3, '38.35616438356165', '1471996800', 32, 0),
(124, 3, '38.35616438356165', '1472083200', 33, 0),
(125, 3, '38.35616438356165', '1472169600', 34, 0),
(126, 3, '38.35616438356165', '1472256000', 35, 0),
(127, 3, '38.35616438356165', '1472342400', 36, 0),
(128, 3, '38.35616438356165', '1472428800', 37, 0),
(129, 3, '38.35616438356165', '1472515200', 38, 0),
(130, 3, '38.35616438356165', '1472601600', 39, 0),
(131, 3, '38.35616438356165', '1472688000', 40, 0),
(132, 3, '38.35616438356165', '1472774400', 41, 0),
(133, 3, '38.35616438356165', '1472860800', 42, 0),
(134, 3, '38.35616438356165', '1472947200', 43, 0),
(135, 3, '38.35616438356165', '1473033600', 44, 0),
(136, 3, '38.35616438356165', '1473120000', 45, 0),
(137, 3, '38.35616438356165', '1473206400', 46, 0),
(138, 3, '38.35616438356165', '1473292800', 47, 0),
(139, 3, '38.35616438356165', '1473379200', 48, 0),
(140, 3, '38.35616438356165', '1473465600', 49, 0),
(141, 3, '38.35616438356165', '1473552000', 50, 0),
(142, 3, '38.35616438356165', '1473638400', 51, 0),
(143, 3, '38.35616438356165', '1473724800', 52, 0),
(144, 3, '38.35616438356165', '1473811200', 53, 0),
(145, 3, '38.35616438356165', '1473897600', 54, 0),
(146, 3, '38.35616438356165', '1473984000', 55, 0),
(147, 3, '38.35616438356165', '1474070400', 56, 0),
(148, 3, '38.35616438356165', '1474156800', 57, 0),
(149, 3, '38.35616438356165', '1474243200', 58, 0),
(150, 3, '38.35616438356165', '1474329600', 59, 0),
(151, 3, '38.35616438356165', '1474416000', 60, 0),
(152, 3, '38.35616438356165', '1474502400', 61, 0),
(153, 3, '38.35616438356165', '1474588800', 62, 0),
(154, 3, '38.35616438356165', '1474675200', 63, 0),
(155, 3, '38.35616438356165', '1474761600', 64, 0),
(156, 3, '38.35616438356165', '1474848000', 65, 0),
(157, 3, '38.35616438356165', '1474934400', 66, 0),
(158, 3, '38.35616438356165', '1475020800', 67, 0),
(159, 3, '38.35616438356165', '1475107200', 68, 0),
(160, 3, '38.35616438356165', '1475193600', 69, 0),
(161, 3, '38.35616438356165', '1475280000', 70, 0),
(162, 3, '38.35616438356165', '1475366400', 71, 0),
(163, 3, '38.35616438356165', '1475452800', 72, 0),
(164, 3, '38.35616438356165', '1475539200', 73, 0),
(165, 3, '38.35616438356165', '1475625600', 74, 0),
(166, 3, '38.35616438356165', '1475712000', 75, 0),
(167, 3, '38.35616438356165', '1475798400', 76, 0),
(168, 3, '38.35616438356165', '1475884800', 77, 0),
(169, 3, '38.35616438356165', '1475971200', 78, 0),
(170, 3, '38.35616438356165', '1476057600', 79, 0),
(171, 3, '38.35616438356165', '1476144000', 80, 0),
(172, 3, '38.35616438356165', '1476230400', 81, 0),
(173, 3, '38.35616438356165', '1476316800', 82, 0),
(174, 3, '38.35616438356165', '1476403200', 83, 0),
(175, 3, '38.35616438356165', '1476489600', 84, 0),
(176, 3, '38.35616438356165', '1476576000', 85, 0),
(177, 3, '38.35616438356165', '1476662400', 86, 0),
(178, 3, '38.35616438356165', '1476748800', 87, 0),
(179, 3, '38.35616438356165', '1476835200', 88, 0),
(180, 3, '38.35616438356165', '1476921600', 89, 0),
(181, 3, '38.35616438356165', '1477008000', 90, 0),
(182, 3, '38.35616438356165', '1477094400', 91, 0),
(183, 4, '38.35616438356165', '1477180800', 1, 0),
(184, 4, '38.35616438356165', '1477267200', 2, 0),
(185, 4, '38.35616438356165', '1477353600', 3, 0),
(186, 4, '38.35616438356165', '1477440000', 4, 0),
(187, 4, '38.35616438356165', '1477526400', 5, 0),
(188, 4, '38.35616438356165', '1477612800', 6, 0),
(189, 4, '38.35616438356165', '1477699200', 7, 0),
(190, 4, '38.35616438356165', '1477785600', 8, 0),
(191, 4, '38.35616438356165', '1477872000', 9, 0),
(192, 4, '38.35616438356165', '1477958400', 10, 0),
(193, 4, '38.35616438356165', '1478044800', 11, 0),
(194, 4, '38.35616438356165', '1478131200', 12, 0),
(195, 4, '38.35616438356165', '1478217600', 13, 0),
(196, 4, '38.35616438356165', '1478304000', 14, 0),
(197, 4, '38.35616438356165', '1478390400', 15, 0),
(198, 4, '38.35616438356165', '1478476800', 16, 0),
(199, 4, '38.35616438356165', '1478563200', 17, 0),
(200, 4, '38.35616438356165', '1478649600', 18, 0),
(201, 4, '38.35616438356165', '1478736000', 19, 0),
(202, 4, '38.35616438356165', '1478822400', 20, 0),
(203, 4, '38.35616438356165', '1478908800', 21, 0),
(204, 4, '38.35616438356165', '1478995200', 22, 0),
(205, 4, '38.35616438356165', '1479081600', 23, 0),
(206, 4, '38.35616438356165', '1479168000', 24, 0),
(207, 4, '38.35616438356165', '1479254400', 25, 0),
(208, 4, '38.35616438356165', '1479340800', 26, 0),
(209, 4, '38.35616438356165', '1479427200', 27, 0),
(210, 4, '38.35616438356165', '1479513600', 28, 0),
(211, 4, '38.35616438356165', '1479600000', 29, 0),
(212, 4, '38.35616438356165', '1479686400', 30, 0),
(213, 4, '38.35616438356165', '1479772800', 31, 0),
(214, 4, '38.35616438356165', '1479859200', 32, 0),
(215, 4, '38.35616438356165', '1479945600', 33, 0),
(216, 4, '38.35616438356165', '1480032000', 34, 0),
(217, 4, '38.35616438356165', '1480118400', 35, 0),
(218, 4, '38.35616438356165', '1480204800', 36, 0),
(219, 4, '38.35616438356165', '1480291200', 37, 0),
(220, 4, '38.35616438356165', '1480377600', 38, 0),
(221, 4, '38.35616438356165', '1480464000', 39, 0),
(222, 4, '38.35616438356165', '1480550400', 40, 0),
(223, 4, '38.35616438356165', '1480636800', 41, 0),
(224, 2, '38.35616438356165', '1480118400', 1, 0),
(225, 2, '38.35616438356165', '1480204800', 2, 0),
(226, 2, '38.35616438356165', '1480291200', 3, 0),
(227, 2, '38.35616438356165', '1480377600', 4, 0),
(228, 2, '38.35616438356165', '1480464000', 5, 0),
(229, 2, '38.35616438356165', '1480550400', 6, 0),
(230, 2, '38.35616438356165', '1480636800', 7, 0);

-- --------------------------------------------------------

--
-- Table structure for table `investment_management_accounts`
--

DROP TABLE IF EXISTS `investment_management_accounts`;
CREATE TABLE `investment_management_accounts` (
  `id` bigint(255) NOT NULL,
  `account_number` varchar(255) NOT NULL,
  `id_investment_management_type` int(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `value_date` varchar(255) NOT NULL,
  `spread` varchar(255) NOT NULL,
  `is_traded` int(1) NOT NULL DEFAULT '0',
  `is_authorised` int(1) NOT NULL DEFAULT '0',
  `ordered_by` int(255) NOT NULL,
  `traded_by` int(255) NOT NULL,
  `authorised_by` int(255) NOT NULL,
  `id_company` int(255) NOT NULL,
  `id_branch` int(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `date_created` varchar(255) NOT NULL,
  `date_traded` varchar(255) NOT NULL,
  `date_authorised` varchar(255) NOT NULL,
  `id_client` int(255) NOT NULL,
  `remarks` text NOT NULL,
  `instruction` text NOT NULL,
  `redemption` text NOT NULL,
  `number_days` varchar(255) NOT NULL,
  `maturity_date` varchar(255) NOT NULL,
  `daily_interest` varchar(255) NOT NULL,
  `id_liability_order` int(255) NOT NULL,
  `amount_left` varchar(255) NOT NULL,
  `stopped` int(1) NOT NULL DEFAULT '0',
  `days_dropped` int(1) NOT NULL DEFAULT '0',
  `previous` int(255) NOT NULL DEFAULT '0',
  `is_fund` int(5) NOT NULL DEFAULT '0',
  `investment_code` varchar(255) NOT NULL,
  `certificate_printed` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `investment_management_accounts`
--

TRUNCATE TABLE `investment_management_accounts`;
--
-- Dumping data for table `investment_management_accounts`
--

INSERT INTO `investment_management_accounts` (`id`, `account_number`, `id_investment_management_type`, `rate`, `value_date`, `spread`, `is_traded`, `is_authorised`, `ordered_by`, `traded_by`, `authorised_by`, `id_company`, `id_branch`, `amount`, `date_created`, `date_traded`, `date_authorised`, `id_client`, `remarks`, `instruction`, `redemption`, `number_days`, `maturity_date`, `daily_interest`, `id_liability_order`, `amount_left`, `stopped`, `days_dropped`, `previous`, `is_fund`, `investment_code`, `certificate_printed`) VALUES
(1, '100000000003', 2, '28', '1472162400', '', 1, 1, 11, 11, 11, 2, 2, '50000', '1480689299', '1480689332', '1480689344', 6, '', '2', '1', '91', '1480032000', '38.35616438356165', 1, '50000', 0, 0, 0, 0, '100000000001', 0),
(2, '100000000003', 2, '28', '1480032000', '', 1, 0, 0, 0, 0, 2, 2, '50000', '1480689344', '1480689344', '1480689344', 6, 'This Order Was Generated By The System Base On The Initial Instructions', '2', '1', '91', '1488555344', '38.35616438356165', 2, '50000', 0, 0, 1, 0, '', 0),
(3, '100000000003', 2, '28', '1469224800', '', 1, 1, 11, 11, 11, 2, 2, '50000', '1480713059', '1480713071', '1480713081', 6, '', '2', '1', '91', '1477094400', '38.35616438356165', 3, '50000', 0, 0, 0, 0, '100000000003', 0),
(4, '100000000003', 2, '28', '1477094400', '', 1, 0, 0, 0, 0, 2, 2, '50000', '1480713082', '1480713082', '1480713082', 6, 'This Order Was Generated By The System Base On The Initial Instructions', '2', '1', '91', '1488579082', '38.35616438356165', 4, '50000', 0, 0, 3, 0, '', 0),
(5, '100000000003', 2, '28', '1477087200', '', 1, 1, 0, 0, 11, 2, 2, '50000', '1480713082', '1480713082', '1480713090', 6, 'This Order Was Generated By The System Base On The Initial Instructions', '2', '1', '91', '1484956800', '38.35616438356165', 4, '50000', 0, 0, 3, 0, '', 0),
(6, '100000000003', 2, '28', '1480028400', '', 1, 1, 0, 0, 11, 2, 2, '50000', '1480689344', '1480689344', '1480713095', 6, 'This Order Was Generated By The System Base On The Initial Instructions', '2', '1', '91', '1487894400', '38.35616438356165', 2, '50000', 0, 0, 1, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `investment_management_orders`
--

DROP TABLE IF EXISTS `investment_management_orders`;
CREATE TABLE `investment_management_orders` (
  `id` int(255) NOT NULL,
  `account_number` varchar(255) NOT NULL,
  `id_investment_management_type` int(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `value_date` varchar(255) NOT NULL,
  `spread` varchar(255) NOT NULL,
  `is_traded` int(1) NOT NULL DEFAULT '0',
  `is_authorised` int(1) NOT NULL DEFAULT '0',
  `ordered_by` int(255) NOT NULL,
  `traded_by` int(255) NOT NULL,
  `authorised_by` int(255) NOT NULL,
  `id_company` int(255) NOT NULL,
  `id_branch` int(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `date_created` varchar(255) NOT NULL,
  `date_traded` varchar(255) NOT NULL,
  `date_authorised` varchar(255) NOT NULL,
  `id_client` int(255) NOT NULL,
  `remarks` text NOT NULL,
  `instruction` text NOT NULL,
  `redemption` text NOT NULL,
  `number_days` varchar(255) NOT NULL,
  `maturity_date` varchar(255) NOT NULL,
  `daily_interest` varchar(255) NOT NULL,
  `stopped` int(1) NOT NULL DEFAULT '0',
  `days_dropped` int(1) NOT NULL DEFAULT '0',
  `previous` int(255) NOT NULL DEFAULT '0',
  `is_fund` int(5) NOT NULL DEFAULT '0',
  `investment_code` varchar(255) NOT NULL,
  `certificate_printed` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `investment_management_orders`
--

TRUNCATE TABLE `investment_management_orders`;
--
-- Dumping data for table `investment_management_orders`
--

INSERT INTO `investment_management_orders` (`id`, `account_number`, `id_investment_management_type`, `rate`, `value_date`, `spread`, `is_traded`, `is_authorised`, `ordered_by`, `traded_by`, `authorised_by`, `id_company`, `id_branch`, `amount`, `date_created`, `date_traded`, `date_authorised`, `id_client`, `remarks`, `instruction`, `redemption`, `number_days`, `maturity_date`, `daily_interest`, `stopped`, `days_dropped`, `previous`, `is_fund`, `investment_code`, `certificate_printed`) VALUES
(1, '100000000003', 2, '28', '1472162400', '', 1, 1, 11, 11, 11, 2, 2, '50000', '1480689299', '1480689332', '1480689344', 6, '', '2', '1', '91', '1480032000', '38.35616438356165', 1, 91, 0, 0, '100000000001', 1),
(2, '100000000003', 2, '28', '1480028400', '', 1, 1, 0, 0, 11, 2, 2, '50000', '1480689344', '1480689344', '1480713095', 6, 'This Order Was Generated By The System Base On The Initial Instructions', '2', '1', '91', '1487894400', '38.35616438356165', 0, 0, 1, 0, '', 1),
(3, '100000000003', 2, '28', '1469224800', '', 1, 1, 11, 11, 11, 2, 2, '50000', '1480713059', '1480713071', '1480713081', 6, '', '2', '1', '91', '1477094400', '38.35616438356165', 1, 91, 0, 0, '100000000003', 0),
(4, '100000000003', 2, '28', '1477087200', '', 1, 1, 0, 0, 11, 2, 2, '50000', '1480713082', '1480713082', '1480713090', 6, 'This Order Was Generated By The System Base On The Initial Instructions', '2', '1', '91', '1484956800', '38.35616438356165', 0, 30, 3, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `investment_management_placement`
--

DROP TABLE IF EXISTS `investment_management_placement`;
CREATE TABLE `investment_management_placement` (
  `id` int(255) NOT NULL,
  `id_asset_category` int(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `date_created` varchar(255) NOT NULL,
  `id_user` int(255) NOT NULL,
  `id_company` int(255) NOT NULL,
  `id_branch` int(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `value_date` varchar(255) NOT NULL,
  `remarks` text NOT NULL,
  `is_fund` int(5) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `investment_management_placement`
--

TRUNCATE TABLE `investment_management_placement`;
-- --------------------------------------------------------

--
-- Table structure for table `investment_management_transactions`
--

DROP TABLE IF EXISTS `investment_management_transactions`;
CREATE TABLE `investment_management_transactions` (
  `id` bigint(255) NOT NULL,
  `id_order` int(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `id_placement` int(255) NOT NULL,
  `id_transaction_type` int(255) NOT NULL,
  `id_user` int(255) NOT NULL,
  `is_authorised` int(1) NOT NULL DEFAULT '0',
  `authorised_by` int(255) NOT NULL,
  `id_company` int(255) NOT NULL,
  `id_branch` int(255) NOT NULL,
  `id_investment_account` int(255) NOT NULL,
  `is_fund` int(5) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `investment_management_transactions`
--

TRUNCATE TABLE `investment_management_transactions`;
--
-- Dumping data for table `investment_management_transactions`
--

INSERT INTO `investment_management_transactions` (`id`, `id_order`, `amount`, `id_placement`, `id_transaction_type`, `id_user`, `is_authorised`, `authorised_by`, `id_company`, `id_branch`, `id_investment_account`, `is_fund`) VALUES
(1, 1, '50000', 0, 4, 11, 1, 11, 2, 2, 6, 0),
(2, 2, '50000', 0, 4, 0, 1, 0, 2, 2, 2, 0),
(3, 3, '50000', 0, 4, 11, 1, 11, 2, 2, 197, 0),
(4, 4, '50000', 0, 4, 0, 1, 0, 2, 2, 4, 0),
(5, 4, '50000', 0, 4, 11, 1, 11, 2, 2, 385, 0),
(6, 2, '50000', 0, 4, 11, 1, 11, 2, 2, 469, 0);

-- --------------------------------------------------------

--
-- Table structure for table `investment_management_types`
--

DROP TABLE IF EXISTS `investment_management_types`;
CREATE TABLE `investment_management_types` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `number_days` int(255) NOT NULL,
  `id_company` int(255) NOT NULL,
  `is_active` int(1) NOT NULL,
  `denominator` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `investment_management_types`
--

TRUNCATE TABLE `investment_management_types`;
--
-- Dumping data for table `investment_management_types`
--

INSERT INTO `investment_management_types` (`id`, `name`, `number_days`, `id_company`, `is_active`, `denominator`) VALUES
(1, '91 Day Fixed Deposit', 91, 1, 1, '365'),
(2, 'HPI-91', 91, 2, 1, '365'),
(3, 'HPI-182', 182, 2, 1, '365'),
(5, 'HPI-365', 365, 2, 1, '365'),
(6, 'HPI-730', 730, 2, 1, '365'),
(7, '91- HPI', 91, 3, 1, '365'),
(8, '182 - FI ', 182, 3, 1, '365'),
(9, '1 year FI', 365, 3, 1, '365');

-- --------------------------------------------------------

--
-- Table structure for table `investment_placement_daily_interest_transactions`
--

DROP TABLE IF EXISTS `investment_placement_daily_interest_transactions`;
CREATE TABLE `investment_placement_daily_interest_transactions` (
  `id` int(255) NOT NULL,
  `id_order` int(255) NOT NULL,
  `interest` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `day` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `investment_placement_daily_interest_transactions`
--

TRUNCATE TABLE `investment_placement_daily_interest_transactions`;
-- --------------------------------------------------------

--
-- Table structure for table `investment_placement_details`
--

DROP TABLE IF EXISTS `investment_placement_details`;
CREATE TABLE `investment_placement_details` (
  `id` int(255) NOT NULL,
  `id_investment_account` int(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `id_placement_order` int(255) NOT NULL,
  `id_asset_category` int(255) NOT NULL,
  `spread` varchar(255) NOT NULL,
  `daily_interest` varchar(255) NOT NULL,
  `daily_spread` varchar(255) NOT NULL,
  `is_fund` int(5) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `investment_placement_details`
--

TRUNCATE TABLE `investment_placement_details`;
-- --------------------------------------------------------

--
-- Table structure for table `investment_placement_orders`
--

DROP TABLE IF EXISTS `investment_placement_orders`;
CREATE TABLE `investment_placement_orders` (
  `id` int(255) NOT NULL,
  `id_bank` int(255) NOT NULL,
  `id_instrument_code` int(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `value_date` varchar(255) NOT NULL,
  `is_traded` int(1) NOT NULL DEFAULT '0',
  `is_authorised` int(1) NOT NULL DEFAULT '0',
  `ordered_by` int(255) NOT NULL,
  `traded_by` int(255) NOT NULL,
  `authorised_by` int(255) NOT NULL,
  `id_company` int(255) NOT NULL,
  `id_branch` int(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `date_created` varchar(255) NOT NULL,
  `date_traded` varchar(255) NOT NULL,
  `date_authorised` varchar(255) NOT NULL,
  `number_days` varchar(255) NOT NULL,
  `maturity_date` varchar(255) NOT NULL,
  `daily_interest` varchar(255) NOT NULL,
  `redemption` int(1) NOT NULL,
  `instruction` int(1) NOT NULL,
  `remarks` text NOT NULL,
  `stopped` int(1) NOT NULL DEFAULT '0',
  `days_dropped` int(255) NOT NULL DEFAULT '0',
  `spread` varchar(255) NOT NULL,
  `previous` int(255) NOT NULL DEFAULT '0',
  `is_fund` int(5) NOT NULL DEFAULT '0',
  `is_pending_drop` int(5) NOT NULL DEFAULT '0',
  `day_pending` int(255) NOT NULL,
  `investment_code` varchar(255) DEFAULT NULL,
  `certificate_printed` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `investment_placement_orders`
--

TRUNCATE TABLE `investment_placement_orders`;
-- --------------------------------------------------------

--
-- Table structure for table `investment_placement_transactions`
--

DROP TABLE IF EXISTS `investment_placement_transactions`;
CREATE TABLE `investment_placement_transactions` (
  `id` int(255) NOT NULL,
  `id_asset_category` int(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `id_placement` int(255) NOT NULL,
  `id_transaction_type` int(255) NOT NULL,
  `id_user` int(255) NOT NULL,
  `is_authorised` int(1) NOT NULL DEFAULT '0',
  `authorised_by` int(255) NOT NULL,
  `id_company` int(255) NOT NULL,
  `id_branch` int(255) NOT NULL,
  `id_investment_account` int(255) NOT NULL,
  `id_order` int(255) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `stamp` varchar(255) NOT NULL,
  `is_fund` int(5) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `investment_placement_transactions`
--

TRUNCATE TABLE `investment_placement_transactions`;
-- --------------------------------------------------------

--
-- Table structure for table `ledgers`
--

DROP TABLE IF EXISTS `ledgers`;
CREATE TABLE `ledgers` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `id_company` int(255) NOT NULL,
  `id_branch` int(255) NOT NULL,
  `id_ledger_category` int(255) NOT NULL,
  `id_ledger_subcategory` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `ledgers`
--

TRUNCATE TABLE `ledgers`;
--
-- Dumping data for table `ledgers`
--

INSERT INTO `ledgers` (`id`, `name`, `id_company`, `id_branch`, `id_ledger_category`, `id_ledger_subcategory`) VALUES
(1, 'Client Asset Cash Book', 0, 0, 1, 0),
(2, 'Client Deposit', 0, 0, 2, 0),
(3, 'Client Interest Receivable', 0, 0, 1, 0),
(4, 'Interest Receivable Company', 0, 0, 1, 0),
(5, 'Interest Income', 0, 0, 5, 0),
(6, 'Company Cash Book', 0, 0, 1, 0),
(7, 'Income Penalty', 0, 0, 2, 0),
(8, 'Fees Payable', 0, 0, 1, 0),
(9, 'Management Fees', 0, 0, 5, 0),
(10, 'Fixed Term Investment A/c', 0, 0, 1, 0),
(11, 'Interest Expense', 0, 0, 6, 0),
(12, 'Interest Payable', 0, 0, 2, 0),
(13, 'Non Current Asset', 0, 0, 1, 0),
(87, 'INCOME SURPLUS', 0, 0, 2, 1),
(88, 'STATED CAPITAL', 0, 0, 2, 1),
(89, 'Travel Wise Services', 0, 0, 2, 1),
(90, 'DIRECTORS LOAN', 0, 0, 2, 2),
(91, 'SHAREHOLDERS UNREGISTERED FUNDS', 0, 0, 2, 2),
(92, 'Trade Creditors', 0, 0, 2, 3),
(93, 'Accounts Payable', 0, 0, 1, 5),
(94, 'Accounts Payable', 0, 0, 2, 3),
(95, 'Branch Current Accounts', 0, 0, 2, 3),
(96, 'Brooks Welfare', 0, 0, 2, 3),
(97, 'HPN Contribution', 0, 0, 2, 3),
(98, 'JOHN NIPAH & ASSOCIATES', 0, 0, 2, 3),
(99, 'Net Salaries Payable-Permanent Staff', 0, 0, 2, 3),
(100, 'PAYE', 0, 0, 2, 3),
(101, 'SSNIT 5.5%', 0, 0, 2, 3),
(102, 'SSS Contribution', 0, 0, 2, 3),
(103, 'Welfare Deductions', 0, 0, 2, 3),
(104, 'Suspense Account', 0, 0, 2, 4),
(105, 'Uncleared Cheques', 0, 0, 2, 4),
(106, 'Fixed Asset-Cost', 0, 0, 1, 5),
(107, 'Fixed Assets-Accumulated Depreciation', 0, 0, 1, 5),
(108, 'BONDS', 0, 0, 1, 6),
(109, 'Brooks Investments(Listed Companies)', 0, 0, 1, 6),
(110, 'Clients Investments(others)', 0, 0, 1, 6),
(111, 'DEBENTURES/CP', 0, 0, 1, 6),
(112, 'FIXED DEPOSIT/PLACEMENT', 0, 0, 1, 6),
(113, 'HPN Investments', 0, 0, 1, 6),
(114, 'HPN Investments(Staff Car Loans)', 0, 0, 1, 6),
(115, 'Other Financial Services', 0, 0, 1, 6),
(116, 'Pension Funds Under Management', 0, 0, 1, 6),
(117, 'Treasury Bill Investments', 0, 0, 1, 6),
(118, 'Prep', 0, 0, 1, 7),
(119, 'Prepayment', 0, 0, 1, 7),
(120, 'Cash-in-hand', 0, 0, 1, 7),
(121, 'Bank Accounts', 0, 0, 1, 7),
(122, 'Accounts Receivable', 0, 0, 1, 7),
(123, 'BROOKS OWN INVESTMENTS', 0, 0, 1, 7),
(124, 'Loan Deduction', 0, 0, 1, 7),
(125, 'Salary Advance', 0, 0, 1, 7),
(126, 'STAFF LOANS(DEBTORS)', 0, 0, 1, 7),
(127, 'Opening Balance', 0, 0, 1, 8),
(128, 'Current Period', 0, 0, 1, 8),
(129, 'Less: Transferred', 0, 0, 1, 8),
(130, 'Trade Creditors', 0, 0, 7, 9),
(131, 'Accounts Payable', 0, 0, 7, 9),
(132, 'FIXED DEPOSIT/PLACEMENTS', 0, 0, 7, 10),
(133, 'Prepayment', 0, 0, 7, 11),
(134, 'Accounts Receivable', 0, 0, 7, 11),
(135, 'Interest on Call Accounts', 0, 0, 7, 12),
(136, 'Other Income', 0, 0, 7, 13),
(137, 'Geeneral Expenses', 0, 0, 7, 14),
(138, 'Trade Creditors', 0, 0, 8, 15),
(139, 'Accounts Payable', 0, 0, 8, 15),
(140, 'Brooks Welfare', 0, 0, 8, 15),
(141, 'Net Salaries Payable-Permanent Staff', 0, 0, 8, 17),
(142, 'PAYE', 0, 0, 8, 15),
(143, 'SSNIT 5.5%', 0, 0, 8, 15),
(144, 'SSS Contribution', 0, 0, 8, 15),
(145, 'Welfare Deductions', 0, 0, 8, 15),
(146, 'BONDS', 0, 0, 8, 16),
(147, 'FIXED DEPOSIT/PLACEMENTS', 0, 0, 8, 16),
(148, 'Prepayment', 0, 0, 8, 17),
(149, 'Other Income', 0, 0, 7, 13),
(150, 'ADMINISTRATIVE EXPENSES', 0, 0, 8, 19),
(151, 'GENERAL EXPENSES', 0, 0, 8, 19),
(152, 'MARKETING EXPENSES', 0, 0, 8, 19),
(153, 'OFFICE EXPENSES', 0, 0, 8, 19),
(154, 'STAFF COSTS', 0, 0, 8, 19),
(155, 'Investment Expenses', 0, 0, 6, 20),
(156, 'Interest Accured/paid on PF Investment', 0, 0, 6, 20),
(157, 'Interest Expenses Advance Amortised', 0, 0, 6, 20),
(158, 'Interest on Overdraft', 0, 0, 6, 20),
(159, 'Interest Paid/Accured on HPN Investments', 0, 0, 6, 20),
(160, 'Interest Paid/Accured on SIS  Investments', 0, 0, 6, 20),
(161, 'Interest Paid on Directors Loan', 0, 0, 6, 20),
(162, 'License Renewal Forms', 0, 0, 6, 20),
(163, 'PENALTIES PAID ON PREMATURE LIQUIDATIONS', 0, 0, 6, 20),
(164, 'Whiteoffs/Shortages', 0, 0, 6, 20),
(165, 'ADMINISTRATIVE EXPENSES', 0, 0, 6, 21),
(166, 'Corperate Taxation', 0, 0, 6, 21),
(167, 'GENERAL EXPENSES', 0, 0, 6, 21),
(168, 'MARKETING EXPENSES', 0, 0, 6, 21),
(169, 'OFFICE EXPENSES', 0, 0, 6, 21),
(170, 'Other Miscellaneous Expenses', 0, 0, 6, 21),
(171, 'PROFESSIONAL EXPENSES', 0, 0, 6, 21),
(172, 'Travelling  and  Entertainment', 0, 0, 6, 21),
(173, 'STAFF COSTS', 0, 0, 6, 21),
(174, 'Bank Interest Earned on Call', 0, 0, 5, 22),
(175, 'Commission on HPN Account', 0, 0, 5, 22),
(176, 'Interest Earned on Brooks Own Investment', 0, 0, 5, 22),
(177, 'Interest Earned on HPN Investments', 0, 0, 5, 22),
(178, 'Interest on Call Accounts', 0, 0, 5, 22),
(179, 'Management Fees-BAM', 0, 0, 6, 21),
(180, 'Management Fees-BAM', 0, 0, 6, 21),
(181, 'Management Fees-BAM', 0, 0, 5, 22),
(182, 'PENALTIES EARNED ON PREMATURE LIQUIDATIONS', 0, 0, 5, 22),
(183, 'Realised Exchange Gain', 0, 0, 5, 22),
(184, 'Other Income', 0, 0, 5, 23),
(185, 'Proceeds From Sale of Fixed Asset', 0, 0, 5, 23);

-- --------------------------------------------------------

--
-- Table structure for table `ledger_category`
--

DROP TABLE IF EXISTS `ledger_category`;
CREATE TABLE `ledger_category` (
  `id` int(5) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `ledger_category`
--

TRUNCATE TABLE `ledger_category`;
-- --------------------------------------------------------

--
-- Table structure for table `ledger_entries`
--

DROP TABLE IF EXISTS `ledger_entries`;
CREATE TABLE `ledger_entries` (
  `id` bigint(255) NOT NULL,
  `id_ledger` int(255) NOT NULL,
  `transaction_type` int(255) NOT NULL,
  `narration` text NOT NULL,
  `amount` varchar(255) NOT NULL,
  `stamp` varchar(255) NOT NULL,
  `id_client` int(255) NOT NULL,
  `id_placement_order` int(255) NOT NULL,
  `id_company` int(255) NOT NULL,
  `id_branch` int(255) NOT NULL,
  `id_investment_order` int(255) NOT NULL DEFAULT '0',
  `balance` varchar(255) NOT NULL,
  `is_fund` int(5) NOT NULL DEFAULT '0',
  `id_bank` int(255) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `ledger_entries`
--

TRUNCATE TABLE `ledger_entries`;
--
-- Dumping data for table `ledger_entries`
--

INSERT INTO `ledger_entries` (`id`, `id_ledger`, `transaction_type`, `narration`, `amount`, `stamp`, `id_client`, `id_placement_order`, `id_company`, `id_branch`, `id_investment_order`, `balance`, `is_fund`, `id_bank`) VALUES
(1, 2, 5, 'Client Deposit', '50000', '1480689110', 6, 0, 2, 2, 1, '50000.00', 0, 0),
(2, 1, 6, 'Client Deposit', '50000', '1480689110', 6, 0, 2, 2, 1, '-50000.00', 0, 0),
(3, 2, 5, 'Client Deposit', '110', '1480689114', 6, 0, 2, 2, 2, '50110.00', 0, 0),
(4, 1, 6, 'Client Deposit', '110', '1480689114', 6, 0, 2, 2, 2, '-50110.00', 0, 0),
(5, 1, 5, 'Booking Client Investment', '50000', '1480689344', 6, 0, 2, 2, 1, '-110.00', 0, 0),
(6, 10, 6, 'Booking Client Investment', '50000', '1480689344', 6, 0, 2, 2, 1, '-50000.00', 0, 0),
(7, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '38.35', 0, 0),
(8, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-38.35', 0, 0),
(9, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '76.70', 0, 0),
(10, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-76.70', 0, 0),
(11, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '115.05', 0, 0),
(12, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-115.05', 0, 0),
(13, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '153.40', 0, 0),
(14, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-153.40', 0, 0),
(15, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '191.75', 0, 0),
(16, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-191.75', 0, 0),
(17, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '230.10', 0, 0),
(18, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-230.10', 0, 0),
(19, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '268.45', 0, 0),
(20, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-268.45', 0, 0),
(21, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '306.80', 0, 0),
(22, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-306.80', 0, 0),
(23, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '345.15', 0, 0),
(24, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-345.15', 0, 0),
(25, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '383.50', 0, 0),
(26, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-383.50', 0, 0),
(27, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '421.85', 0, 0),
(28, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-421.85', 0, 0),
(29, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '460.20', 0, 0),
(30, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-460.20', 0, 0),
(31, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '498.55', 0, 0),
(32, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-498.55', 0, 0),
(33, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '536.90', 0, 0),
(34, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-536.90', 0, 0),
(35, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '575.25', 0, 0),
(36, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-575.25', 0, 0),
(37, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '613.60', 0, 0),
(38, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-613.60', 0, 0),
(39, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '651.95', 0, 0),
(40, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-651.95', 0, 0),
(41, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '690.30', 0, 0),
(42, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-690.30', 0, 0),
(43, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '728.65', 0, 0),
(44, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-728.65', 0, 0),
(45, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '767.00', 0, 0),
(46, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-767.00', 0, 0),
(47, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '805.35', 0, 0),
(48, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-805.35', 0, 0),
(49, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '843.70', 0, 0),
(50, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-843.70', 0, 0),
(51, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '882.05', 0, 0),
(52, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-882.05', 0, 0),
(53, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '920.40', 0, 0),
(54, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-920.40', 0, 0),
(55, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '958.75', 0, 0),
(56, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-958.75', 0, 0),
(57, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '997.10', 0, 0),
(58, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-997.10', 0, 0),
(59, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '1035.45', 0, 0),
(60, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-1035.45', 0, 0),
(61, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '1073.80', 0, 0),
(62, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-1073.80', 0, 0),
(63, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '1112.15', 0, 0),
(64, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-1112.15', 0, 0),
(65, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '1150.50', 0, 0),
(66, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-1150.50', 0, 0),
(67, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '1188.85', 0, 0),
(68, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-1188.85', 0, 0),
(69, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '1227.20', 0, 0),
(70, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-1227.20', 0, 0),
(71, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '1265.55', 0, 0),
(72, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-1265.55', 0, 0),
(73, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '1303.90', 0, 0),
(74, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-1303.90', 0, 0),
(75, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '1342.25', 0, 0),
(76, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-1342.25', 0, 0),
(77, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '1380.60', 0, 0),
(78, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-1380.60', 0, 0),
(79, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '1418.95', 0, 0),
(80, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-1418.95', 0, 0),
(81, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '1457.30', 0, 0),
(82, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-1457.30', 0, 0),
(83, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '1495.65', 0, 0),
(84, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-1495.65', 0, 0),
(85, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '1534.00', 0, 0),
(86, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-1534.00', 0, 0),
(87, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '1572.35', 0, 0),
(88, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-1572.35', 0, 0),
(89, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '1610.70', 0, 0),
(90, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-1610.70', 0, 0),
(91, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '1649.05', 0, 0),
(92, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-1649.05', 0, 0),
(93, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '1687.40', 0, 0),
(94, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-1687.40', 0, 0),
(95, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '1725.75', 0, 0),
(96, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-1725.75', 0, 0),
(97, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '1764.10', 0, 0),
(98, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-1764.10', 0, 0),
(99, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '1802.45', 0, 0),
(100, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-1802.45', 0, 0),
(101, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '1840.80', 0, 0),
(102, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-1840.80', 0, 0),
(103, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '1879.15', 0, 0),
(104, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-1879.15', 0, 0),
(105, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '1917.50', 0, 0),
(106, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-1917.50', 0, 0),
(107, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '1955.85', 0, 0),
(108, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-1955.85', 0, 0),
(109, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '1994.20', 0, 0),
(110, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-1994.20', 0, 0),
(111, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '2032.55', 0, 0),
(112, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-2032.55', 0, 0),
(113, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '2070.90', 0, 0),
(114, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-2070.90', 0, 0),
(115, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '2109.25', 0, 0),
(116, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-2109.25', 0, 0),
(117, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '2147.60', 0, 0),
(118, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-2147.60', 0, 0),
(119, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '2185.95', 0, 0),
(120, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-2185.95', 0, 0),
(121, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '2224.30', 0, 0),
(122, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-2224.30', 0, 0),
(123, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '2262.65', 0, 0),
(124, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-2262.65', 0, 0),
(125, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '2301.00', 0, 0),
(126, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-2301.00', 0, 0),
(127, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '2339.35', 0, 0),
(128, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-2339.35', 0, 0),
(129, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '2377.70', 0, 0),
(130, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-2377.70', 0, 0),
(131, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '2416.05', 0, 0),
(132, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-2416.05', 0, 0),
(133, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '2454.40', 0, 0),
(134, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-2454.40', 0, 0),
(135, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '2492.75', 0, 0),
(136, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-2492.75', 0, 0),
(137, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '2531.10', 0, 0),
(138, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-2531.10', 0, 0),
(139, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '2569.45', 0, 0),
(140, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-2569.45', 0, 0),
(141, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '2607.80', 0, 0),
(142, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-2607.80', 0, 0),
(143, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '2646.15', 0, 0),
(144, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-2646.15', 0, 0),
(145, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '2684.50', 0, 0),
(146, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-2684.50', 0, 0),
(147, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '2722.85', 0, 0),
(148, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-2722.85', 0, 0),
(149, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '2761.20', 0, 0),
(150, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-2761.20', 0, 0),
(151, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '2799.55', 0, 0),
(152, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-2799.55', 0, 0),
(153, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '2837.90', 0, 0),
(154, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-2837.90', 0, 0),
(155, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '2876.25', 0, 0),
(156, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-2876.25', 0, 0),
(157, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '2914.60', 0, 0),
(158, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-2914.60', 0, 0),
(159, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '2952.95', 0, 0),
(160, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-2952.95', 0, 0),
(161, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '2991.30', 0, 0),
(162, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-2991.30', 0, 0),
(163, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '3029.65', 0, 0),
(164, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-3029.65', 0, 0),
(165, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '3068.00', 0, 0),
(166, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-3068.00', 0, 0),
(167, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '3106.35', 0, 0),
(168, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-3106.35', 0, 0),
(169, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '3144.70', 0, 0),
(170, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-3144.70', 0, 0),
(171, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '3183.05', 0, 0),
(172, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-3183.05', 0, 0),
(173, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '3221.40', 0, 0),
(174, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-3221.40', 0, 0),
(175, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '3259.75', 0, 0),
(176, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-3259.75', 0, 0),
(177, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '3298.10', 0, 0),
(178, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-3298.10', 0, 0),
(179, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '3336.45', 0, 0),
(180, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-3336.45', 0, 0),
(181, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '3374.80', 0, 0),
(182, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-3374.80', 0, 0),
(183, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '3413.15', 0, 0),
(184, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-3413.15', 0, 0),
(185, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '3451.50', 0, 0),
(186, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-3451.50', 0, 0),
(187, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '3489.85', 0, 0),
(188, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480689344', 6, 0, 2, 2, 1, '-3489.85', 0, 0),
(189, 1, 5, 'At Maturity', '50038.35', '1480689344', 6, 0, 2, 2, 1, '49928.35', 0, 0),
(190, 2, 6, 'At Maturity', '50000', '1480689344', 6, 0, 2, 2, 1, '110.00', 0, 0),
(191, 12, 6, 'At Maturity', '38.35', '1480689344', 6, 0, 2, 2, 1, '3451.50', 0, 0),
(192, 2, 5, 'Client Deposit', '50000', '1480689685', 6, 0, 2, 2, 9, '50110.00', 0, 0),
(193, 1, 6, 'Client Deposit', '50000', '1480689685', 6, 0, 2, 2, 9, '-71.65', 0, 0),
(194, 1, 5, 'New Client Asset Purchase', '50000', '1480689871', 0, 1, 2, 2, 0, '49928.34', 1, 0),
(195, 2, 6, 'New Client Asset Purchase', '50000', '1480689871', 0, 1, 2, 2, 0, '110.00', 1, 0),
(196, 1, 5, 'Booking Client Investment', '50000', '1480713081', 6, 0, 2, 2, 3, '99928.34', 0, 0),
(197, 10, 6, 'Booking Client Investment', '50000', '1480713081', 6, 0, 2, 2, 3, '-100000.00', 0, 0),
(198, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '3489.85', 0, 0),
(199, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-3528.20', 0, 0),
(200, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '3528.20', 0, 0),
(201, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-3566.55', 0, 0),
(202, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '3566.55', 0, 0),
(203, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-3604.90', 0, 0),
(204, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '3604.90', 0, 0),
(205, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-3643.25', 0, 0),
(206, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '3643.25', 0, 0),
(207, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-3681.60', 0, 0),
(208, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '3681.60', 0, 0),
(209, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-3719.95', 0, 0),
(210, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '3719.95', 0, 0),
(211, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-3758.30', 0, 0),
(212, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '3758.30', 0, 0),
(213, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-3796.65', 0, 0),
(214, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '3796.65', 0, 0),
(215, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-3835.00', 0, 0),
(216, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '3835.00', 0, 0),
(217, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-3873.35', 0, 0),
(218, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '3873.35', 0, 0),
(219, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-3911.70', 0, 0),
(220, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '3911.70', 0, 0),
(221, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-3950.05', 0, 0),
(222, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '3950.05', 0, 0),
(223, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-3988.40', 0, 0),
(224, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '3988.40', 0, 0),
(225, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-4026.75', 0, 0),
(226, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '4026.75', 0, 0),
(227, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-4065.10', 0, 0),
(228, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '4065.10', 0, 0),
(229, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-4103.45', 0, 0),
(230, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '4103.45', 0, 0),
(231, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-4141.80', 0, 0),
(232, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '4141.80', 0, 0),
(233, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-4180.15', 0, 0),
(234, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '4180.15', 0, 0),
(235, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-4218.50', 0, 0),
(236, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '4218.50', 0, 0),
(237, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-4256.85', 0, 0),
(238, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '4256.85', 0, 0),
(239, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-4295.20', 0, 0),
(240, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '4295.20', 0, 0),
(241, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-4333.55', 0, 0),
(242, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '4333.55', 0, 0),
(243, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-4371.90', 0, 0),
(244, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '4371.90', 0, 0),
(245, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-4410.25', 0, 0),
(246, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '4410.25', 0, 0),
(247, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-4448.60', 0, 0),
(248, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '4448.60', 0, 0),
(249, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-4486.95', 0, 0),
(250, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '4486.95', 0, 0),
(251, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-4525.30', 0, 0),
(252, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '4525.30', 0, 0),
(253, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-4563.65', 0, 0),
(254, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '4563.65', 0, 0),
(255, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-4602.00', 0, 0),
(256, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '4602.00', 0, 0),
(257, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-4640.35', 0, 0),
(258, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '4640.35', 0, 0),
(259, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-4678.70', 0, 0),
(260, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '4678.70', 0, 0),
(261, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-4717.05', 0, 0),
(262, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '4717.05', 0, 0),
(263, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-4755.40', 0, 0),
(264, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '4755.40', 0, 0),
(265, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-4793.75', 0, 0),
(266, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '4793.75', 0, 0),
(267, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-4832.10', 0, 0),
(268, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '4832.10', 0, 0),
(269, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-4870.45', 0, 0),
(270, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '4870.45', 0, 0),
(271, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-4908.80', 0, 0),
(272, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '4908.80', 0, 0),
(273, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-4947.15', 0, 0),
(274, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '4947.15', 0, 0),
(275, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-4985.50', 0, 0),
(276, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '4985.50', 0, 0),
(277, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-5023.85', 0, 0),
(278, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '5023.85', 0, 0),
(279, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-5062.20', 0, 0),
(280, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '5062.20', 0, 0),
(281, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-5100.55', 0, 0),
(282, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '5100.55', 0, 0),
(283, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713081', 6, 0, 2, 2, 3, '-5138.90', 0, 0),
(284, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '5138.90', 0, 0),
(285, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-5177.25', 0, 0),
(286, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '5177.25', 0, 0),
(287, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-5215.60', 0, 0),
(288, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '5215.60', 0, 0),
(289, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-5253.95', 0, 0),
(290, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '5253.95', 0, 0),
(291, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-5292.30', 0, 0),
(292, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '5292.30', 0, 0),
(293, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-5330.65', 0, 0),
(294, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '5330.65', 0, 0),
(295, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-5369.00', 0, 0),
(296, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '5369.00', 0, 0),
(297, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-5407.35', 0, 0),
(298, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '5407.35', 0, 0),
(299, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-5445.70', 0, 0),
(300, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '5445.70', 0, 0),
(301, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-5484.05', 0, 0),
(302, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '5484.05', 0, 0),
(303, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-5522.40', 0, 0),
(304, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '5522.40', 0, 0),
(305, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-5560.75', 0, 0),
(306, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '5560.75', 0, 0),
(307, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-5599.10', 0, 0),
(308, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '5599.10', 0, 0),
(309, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-5637.45', 0, 0),
(310, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '5637.45', 0, 0),
(311, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-5675.80', 0, 0),
(312, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '5675.80', 0, 0),
(313, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-5714.15', 0, 0),
(314, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '5714.15', 0, 0),
(315, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-5752.50', 0, 0),
(316, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '5752.50', 0, 0),
(317, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-5790.85', 0, 0),
(318, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '5790.85', 0, 0),
(319, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-5829.20', 0, 0),
(320, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '5829.20', 0, 0),
(321, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-5867.55', 0, 0),
(322, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '5867.55', 0, 0),
(323, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-5905.90', 0, 0),
(324, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '5905.90', 0, 0),
(325, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-5944.25', 0, 0),
(326, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '5944.25', 0, 0),
(327, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-5982.60', 0, 0),
(328, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '5982.60', 0, 0),
(329, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-6020.95', 0, 0),
(330, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '6020.95', 0, 0),
(331, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-6059.30', 0, 0),
(332, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '6059.30', 0, 0),
(333, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-6097.65', 0, 0),
(334, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '6097.65', 0, 0),
(335, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-6136.00', 0, 0),
(336, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '6136.00', 0, 0),
(337, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-6174.35', 0, 0),
(338, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '6174.35', 0, 0),
(339, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-6212.70', 0, 0),
(340, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '6212.70', 0, 0),
(341, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-6251.05', 0, 0),
(342, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '6251.05', 0, 0),
(343, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-6289.40', 0, 0),
(344, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '6289.40', 0, 0),
(345, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-6327.75', 0, 0),
(346, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '6327.75', 0, 0),
(347, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-6366.10', 0, 0),
(348, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '6366.10', 0, 0),
(349, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-6404.45', 0, 0),
(350, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '6404.45', 0, 0),
(351, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-6442.80', 0, 0),
(352, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '6442.80', 0, 0),
(353, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-6481.15', 0, 0),
(354, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '6481.15', 0, 0),
(355, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-6519.50', 0, 0),
(356, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '6519.50', 0, 0),
(357, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-6557.85', 0, 0),
(358, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '6557.85', 0, 0),
(359, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-6596.20', 0, 0),
(360, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '6596.20', 0, 0),
(361, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-6634.55', 0, 0),
(362, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '6634.55', 0, 0),
(363, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-6672.90', 0, 0),
(364, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '6672.90', 0, 0),
(365, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-6711.25', 0, 0),
(366, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '6711.25', 0, 0),
(367, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-6749.60', 0, 0),
(368, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '6749.60', 0, 0),
(369, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-6787.95', 0, 0),
(370, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '6787.95', 0, 0),
(371, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-6826.30', 0, 0),
(372, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '6826.30', 0, 0),
(373, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-6864.65', 0, 0),
(374, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '6864.65', 0, 0),
(375, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-6903.00', 0, 0),
(376, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '6903.00', 0, 0),
(377, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-6941.35', 0, 0),
(378, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '6941.35', 0, 0),
(379, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713082', 6, 0, 2, 2, 3, '-6979.70', 0, 0),
(380, 1, 5, 'Interest At Maturity', '38.35', '1480713082', 6, 0, 2, 2, 3, '99966.69', 0, 0),
(381, 1, 5, 'Principal At Maturity', '50000', '1480713082', 6, 0, 2, 2, 3, '149966.69', 0, 0),
(382, 2, 6, 'At Maturity', '50000', '1480713082', 6, 0, 2, 2, 3, '-49890.00', 0, 0),
(383, 12, 6, 'At Maturity', '38.35', '1480713082', 6, 0, 2, 2, 3, '6903.00', 0, 0),
(384, 1, 5, 'Booking Client Investment', '50000', '1480713090', 6, 0, 2, 2, 4, '199966.69', 0, 0),
(385, 10, 6, 'Booking Client Investment', '50000', '1480713090', 6, 0, 2, 2, 4, '-150000.00', 0, 0),
(386, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '6941.35', 0, 0),
(387, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-7018.05', 0, 0),
(388, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '6979.70', 0, 0),
(389, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-7056.40', 0, 0),
(390, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '7018.05', 0, 0),
(391, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-7094.75', 0, 0),
(392, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '7056.40', 0, 0),
(393, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-7133.10', 0, 0),
(394, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '7094.75', 0, 0),
(395, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-7171.45', 0, 0),
(396, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '7133.10', 0, 0),
(397, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-7209.80', 0, 0),
(398, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '7171.45', 0, 0),
(399, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-7248.15', 0, 0),
(400, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '7209.80', 0, 0),
(401, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-7286.50', 0, 0),
(402, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '7248.15', 0, 0),
(403, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-7324.85', 0, 0),
(404, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '7286.50', 0, 0),
(405, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-7363.20', 0, 0),
(406, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '7324.85', 0, 0),
(407, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-7401.55', 0, 0),
(408, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '7363.20', 0, 0),
(409, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-7439.90', 0, 0),
(410, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '7401.55', 0, 0),
(411, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-7478.25', 0, 0),
(412, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '7439.90', 0, 0),
(413, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-7516.60', 0, 0),
(414, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '7478.25', 0, 0),
(415, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-7554.95', 0, 0),
(416, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '7516.60', 0, 0),
(417, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-7593.30', 0, 0),
(418, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '7554.95', 0, 0),
(419, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-7631.65', 0, 0),
(420, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '7593.30', 0, 0),
(421, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-7670.00', 0, 0),
(422, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '7631.65', 0, 0),
(423, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-7708.35', 0, 0),
(424, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '7670.00', 0, 0),
(425, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-7746.70', 0, 0),
(426, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '7708.35', 0, 0),
(427, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-7785.05', 0, 0),
(428, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '7746.70', 0, 0),
(429, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-7823.40', 0, 0),
(430, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '7785.05', 0, 0),
(431, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-7861.75', 0, 0),
(432, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '7823.40', 0, 0),
(433, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-7900.10', 0, 0),
(434, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '7861.75', 0, 0),
(435, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-7938.45', 0, 0),
(436, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '7900.10', 0, 0),
(437, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-7976.80', 0, 0),
(438, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '7938.45', 0, 0),
(439, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-8015.15', 0, 0),
(440, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '7976.80', 0, 0),
(441, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-8053.50', 0, 0),
(442, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '8015.15', 0, 0),
(443, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-8091.85', 0, 0),
(444, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '8053.50', 0, 0),
(445, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-8130.20', 0, 0),
(446, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '8091.85', 0, 0),
(447, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-8168.55', 0, 0),
(448, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '8130.20', 0, 0),
(449, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-8206.90', 0, 0),
(450, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '8168.55', 0, 0),
(451, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-8245.25', 0, 0),
(452, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '8206.90', 0, 0),
(453, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-8283.60', 0, 0),
(454, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '8245.25', 0, 0),
(455, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-8321.95', 0, 0),
(456, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '8283.60', 0, 0),
(457, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-8360.30', 0, 0),
(458, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '8321.95', 0, 0),
(459, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-8398.65', 0, 0),
(460, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '8360.30', 0, 0),
(461, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-8437.00', 0, 0),
(462, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '8398.65', 0, 0),
(463, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-8475.35', 0, 0),
(464, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '8437.00', 0, 0),
(465, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-8513.70', 0, 0),
(466, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '8475.35', 0, 0),
(467, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713090', 6, 0, 2, 2, 4, '-8552.05', 0, 0),
(468, 1, 5, 'Booking Client Investment', '50000', '1480713095', 6, 0, 2, 2, 2, '249966.69', 0, 0),
(469, 10, 6, 'Booking Client Investment', '50000', '1480713095', 6, 0, 2, 2, 2, '-200000.00', 0, 0),
(470, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713095', 6, 0, 2, 2, 2, '8513.70', 0, 0),
(471, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713095', 6, 0, 2, 2, 2, '-8590.40', 0, 0),
(472, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713095', 6, 0, 2, 2, 2, '8552.05', 0, 0),
(473, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713095', 6, 0, 2, 2, 2, '-8628.75', 0, 0),
(474, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713095', 6, 0, 2, 2, 2, '8590.40', 0, 0),
(475, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713095', 6, 0, 2, 2, 2, '-8667.10', 0, 0),
(476, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713095', 6, 0, 2, 2, 2, '8628.75', 0, 0);
INSERT INTO `ledger_entries` (`id`, `id_ledger`, `transaction_type`, `narration`, `amount`, `stamp`, `id_client`, `id_placement_order`, `id_company`, `id_branch`, `id_investment_order`, `balance`, `is_fund`, `id_bank`) VALUES
(477, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713095', 6, 0, 2, 2, 2, '-8705.45', 0, 0),
(478, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713095', 6, 0, 2, 2, 2, '8667.10', 0, 0),
(479, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713095', 6, 0, 2, 2, 2, '-8743.80', 0, 0),
(480, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713095', 6, 0, 2, 2, 2, '8705.45', 0, 0),
(481, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713095', 6, 0, 2, 2, 2, '-8782.15', 0, 0),
(482, 12, 5, 'Daily Interest Accrual', '38.35616438356165', '1480713095', 6, 0, 2, 2, 2, '8743.80', 0, 0),
(483, 11, 6, 'Daily Interest Accrual', '38.35616438356165', '1480713095', 6, 0, 2, 2, 2, '-8820.50', 0, 0),
(484, 1, 5, 'New Client Asset Purchase', '11621', '1480714531', 0, 3, 2, 2, 0, '261587.69', 1, 0),
(485, 2, 6, 'New Client Asset Purchase', '11621', '1480714531', 0, 3, 2, 2, 0, '-61511.00', 1, 0),
(486, 2, 5, 'Client Deposit', '110', '1480864628', 1, 0, 2, 2, 31, '-61401.00', 0, 0),
(487, 1, 6, 'Client Deposit', '110', '1480864628', 1, 0, 2, 2, 31, '261477.69', 0, 0),
(488, 2, 5, 'Client Deposit', '110', '1480878898', 1, 0, 2, 2, 32, '-61291.00', 0, 0),
(489, 1, 6, 'Client Deposit', '110', '1480878898', 1, 0, 2, 2, 32, '261367.69', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ledger_report`
--

DROP TABLE IF EXISTS `ledger_report`;
CREATE TABLE `ledger_report` (
  `id` int(255) NOT NULL,
  `id_ledger` int(255) NOT NULL,
  `id_report` int(255) NOT NULL,
  `position` int(1) NOT NULL,
  `id_subcategory` int(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `ledger_report`
--

TRUNCATE TABLE `ledger_report`;
-- --------------------------------------------------------

--
-- Table structure for table `ledger_subcategory`
--

DROP TABLE IF EXISTS `ledger_subcategory`;
CREATE TABLE `ledger_subcategory` (
  `id` int(255) NOT NULL,
  `id_ledger_category` int(255) NOT NULL,
  `id_company` int(255) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `ledger_subcategory`
--

TRUNCATE TABLE `ledger_subcategory`;
-- --------------------------------------------------------

--
-- Table structure for table `liquidate_fund`
--

DROP TABLE IF EXISTS `liquidate_fund`;
CREATE TABLE `liquidate_fund` (
  `id` int(255) NOT NULL,
  `id_order` int(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `current_rate` varchar(255) NOT NULL,
  `penalty` varchar(255) NOT NULL,
  `days` int(255) NOT NULL,
  `id_branch` int(255) NOT NULL,
  `id_company` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `liquidate_fund`
--

TRUNCATE TABLE `liquidate_fund`;
-- --------------------------------------------------------

--
-- Table structure for table `liquidate_investment`
--

DROP TABLE IF EXISTS `liquidate_investment`;
CREATE TABLE `liquidate_investment` (
  `id` int(255) NOT NULL,
  `id_order` int(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `current_rate` varchar(255) NOT NULL,
  `penalty` varchar(255) NOT NULL,
  `days` int(255) NOT NULL,
  `id_branch` int(255) NOT NULL,
  `id_company` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `liquidate_investment`
--

TRUNCATE TABLE `liquidate_investment`;
-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
CREATE TABLE `messages` (
  `id` int(255) NOT NULL,
  `recipient` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `sender` varchar(255) NOT NULL,
  `date_created` varchar(255) NOT NULL,
  `date_to_send` varchar(255) NOT NULL,
  `is_sent` int(1) NOT NULL,
  `date_sent` varchar(255) NOT NULL,
  `id_company` int(255) NOT NULL,
  `id_branch` int(255) NOT NULL,
  `message_type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `messages`
--

TRUNCATE TABLE `messages`;
--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `recipient`, `message`, `sender`, `date_created`, `date_to_send`, `is_sent`, `date_sent`, `id_company`, `id_branch`, `message_type`) VALUES
(1, '+233273458516', 'Credit Transaction Alert Acct Name: DELEKA PROSPER   Date : 12/02/2016 03:30:33  Details : Being New Investment Deposit : Cash  Amt: 50,000.00 Curr Bal : 50,000.00', '', '1480689110', '1480689110', 0, '1480689110', 2, 0, '1'),
(2, '+233273458516', 'Credit Transaction Alert Acct Name: DELEKA PROSPER   Date : 12/02/2016 03:31:40  Details : Deposit For SIS : Cash  Amt: 110.00 Curr Bal : 50,110.00', '', '1480689114', '1480689114', 0, '1480689114', 2, 0, '1'),
(3, '+233273458516', 'Your investment 100000000001 is due redemption in 7 days', '', '1480689344', '1480689344', 0, '1480689344', 2, 0, '1'),
(4, '+233273458516', 'Fixed Term Investment Booking Alert Acct Name: DELEKA PROSPER   Value Date : 08/26/2016 12:00:00Amount (GhC) : 50,000.00 Period (Days): 91  Maturity Date : 11/25/2016 01:00:00', '', '1480689344', '1480689344', 0, '1480689344', 2, 0, '1'),
(5, '+233273458516', 'Credit Transaction Alert Acct Name: DELEKA PROSPER   Date : 12/02/2016 03:41:01  Details : Deposit For Portfolio Management : Cash  Amt: 50,000.00 Curr Bal : 103,490.39', '', '1480689685', '1480689685', 0, '1480689685', 2, 0, '1'),
(6, '+233273458516', 'Your investment 100000000001 is due redemption in 7 days', '', '1480689871', '1480689871', 0, '1480689871', 2, 0, '1'),
(7, '+233273458516', 'Investment Booking Alert Acct Name: DELEKA PROSPER   Value Date : 08/26/2016 12:00:00Amount (GhC) :  Period (Days): 91  Maturity Date : 11/25/2016 01:00:00', '', '1480689871', '1480689871', 0, '1480689871', 2, 0, '1'),
(8, '+233273458516', 'Your investment 100000000003 is due redemption in 7 days', '', '1480713082', '1480713082', 0, '1480713082', 2, 0, '1'),
(9, '+233273458516', 'Fixed Term Investment Booking Alert Acct Name: DELEKA PROSPER   Value Date : 07/23/2016 12:00:00Amount (GhC) : 50,000.00 Period (Days): 91  Maturity Date : 10/22/2016 02:00:00', '', '1480713082', '1480713082', 0, '1480713082', 2, 0, '1'),
(10, '+233273458516', 'Fixed Term Investment Booking Alert Acct Name: DELEKA PROSPER   Value Date : 10/22/2016 02:00:00Amount (GhC) : 50,000.00 Period (Days): 91  Maturity Date : 03/03/2017 11:11:22', '', '1480713090', '1480713090', 0, '1480713090', 2, 0, '1'),
(11, '+233273458516', 'Fixed Term Investment Booking Alert Acct Name: DELEKA PROSPER   Value Date : 11/25/2016 01:00:00Amount (GhC) : 50,000.00 Period (Days): 91  Maturity Date : 03/03/2017 04:35:44', '', '1480713095', '1480713095', 0, '1480713095', 2, 0, '1'),
(12, '+233273458516', 'Your investment 10000000002 is due redemption in 7 days', '', '1480714531', '1480714531', 0, '1480714531', 2, 0, '1'),
(13, '+233273458516', 'Investment Booking Alert Acct Name: DELEKA PROSPER   Value Date : 06/01/2016 12:00:00Amount (GhC) :  Period (Days): 91  Maturity Date : 08/31/2016 02:00:00', '', '1480714532', '1480714532', 0, '1480714532', 2, 0, '1'),
(14, '+233267534489', 'Credit Transaction Alert Acct Name: Afari Nunya Jnr  Date : 12/04/2016 03:49:01  Details : New PF Upload : Cash  Amt: 110.00 Curr Bal : 110.00', '', '1480864628', '1480864628', 0, '1480864628', 2, 0, '1'),
(15, '+233267534489', 'Credit Transaction Alert Acct Name: Afari Nunya Jnr  Date : 12/04/2016 08:14:46  Details : PF : Cash  Amt: 110.00 Curr Bal : 220.00', '', '1480878898', '1480878898', 0, '1480878898', 2, 0, '1');

-- --------------------------------------------------------

--
-- Table structure for table `message_types`
--

DROP TABLE IF EXISTS `message_types`;
CREATE TABLE `message_types` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `message_types`
--

TRUNCATE TABLE `message_types`;
-- --------------------------------------------------------

--
-- Table structure for table `modules_sub_modules`
--

DROP TABLE IF EXISTS `modules_sub_modules`;
CREATE TABLE `modules_sub_modules` (
  `id` int(255) NOT NULL,
  `id_module` int(255) NOT NULL,
  `id_sub_module` int(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `modules_sub_modules`
--

TRUNCATE TABLE `modules_sub_modules`;
-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` int(255) NOT NULL,
  `id_user` int(255) NOT NULL,
  `id_sub_sub_module` int(255) NOT NULL,
  `url` text NOT NULL,
  `message` text NOT NULL,
  `is_read` int(1) NOT NULL DEFAULT '0',
  `date_created` varchar(255) NOT NULL,
  `date_read` varchar(255) NOT NULL,
  `user_read` int(255) NOT NULL,
  `id_company` int(255) NOT NULL,
  `id_branch` int(11) NOT NULL,
  `id_sub_module` int(255) NOT NULL,
  `id_module` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `notifications`
--

TRUNCATE TABLE `notifications`;
--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `id_user`, `id_sub_sub_module`, `url`, `message`, `is_read`, `date_created`, `date_read`, `user_read`, `id_company`, `id_branch`, `id_sub_module`, `id_module`) VALUES
(1, 11, 4, 'http://localhost/int/clients/approve_transactions', 'New Client Deposit', 1, '1480689034', '0', 0, 2, 2, 3, 5),
(2, 11, 4, 'http://localhost/int/clients/approve_transactions', 'New Client Deposit', 1, '1480689100', '1480689114', 11, 2, 2, 3, 5),
(3, 11, 11, 'http://localhost/int/investment/trading', 'New Liability Awaiting Trading', 1, '1480689299', '1480689321', 11, 2, 2, 6, 1),
(4, 11, 12, 'http://localhost/int/investment/authorisation', 'New Liability Awaiting Authorisation', 1, '1480689332', '1480689337', 11, 2, 2, 6, 1),
(5, 11, 12, 'http://localhost/int/investment/authorisation', 'New Liability Awaiting Authorisation', 1, '1480689344', '0', 0, 2, 2, 6, 1),
(6, 11, 0, 'http://localhost/int/savings/pending_accounts', 'New Savings Account Awaiting Authorisation', 1, '1480689485', '1480689591', 11, 2, 2, 32, 9),
(7, 11, 4, 'http://localhost/int/clients/approve_transactions', 'New Client Deposit', 1, '1480689661', '1480689685', 11, 2, 2, 3, 5),
(8, 11, 21, 'http://localhost/int/fund/asset_trading', 'New Client Investment Awaiting Trading', 1, '1480689824', '1480689831', 11, 2, 2, 11, 2),
(9, 11, 22, 'http://localhost/int/fund/asset_authorisation', 'New Client Investment Awaiting Authorisation', 1, '1480689844', '1480689850', 11, 2, 2, 11, 2),
(10, 11, 22, 'http://localhost/int/fund/asset_authorisation', 'New Client Investment Awaiting Authorisation', 1, '1480689871', '1480713921', 11, 2, 2, 11, 2),
(11, 11, 11, 'http://localhost/int/investment/trading', 'New Liability Awaiting Trading', 1, '1480713059', '1480713064', 11, 2, 2, 6, 1),
(12, 11, 12, 'http://localhost/int/investment/authorisation', 'New Liability Awaiting Authorisation', 1, '1480713071', '1480713074', 11, 2, 2, 6, 1),
(13, 11, 12, 'http://localhost/int/investment/authorisation', 'New Liability Awaiting Authorisation', 0, '1480713082', '0', 0, 2, 2, 6, 1),
(14, 11, 21, 'http://localhost/int/fund/asset_trading', 'New Client Investment Awaiting Trading', 1, '1480714509', '1480714515', 11, 2, 2, 11, 2),
(15, 11, 22, 'http://localhost/int/fund/asset_authorisation', 'New Client Investment Awaiting Authorisation', 1, '1480714522', '1480714525', 11, 2, 2, 11, 2),
(16, 11, 22, 'http://localhost/int/fund/asset_authorisation', 'New Client Investment Awaiting Authorisation', 0, '1480714532', '0', 0, 2, 2, 11, 2),
(17, 11, 4, 'http://localhost/int/clients/approve_transactions', 'New Client Deposit', 1, '1480862941', '1480864628', 11, 2, 2, 3, 5),
(18, 11, 4, 'http://localhost/int/clients/approve_transactions', 'New Client Deposit', 1, '1480878886', '1480878898', 11, 2, 2, 3, 5);

-- --------------------------------------------------------

--
-- Table structure for table `partial_redemption_fund`
--

DROP TABLE IF EXISTS `partial_redemption_fund`;
CREATE TABLE `partial_redemption_fund` (
  `id` int(255) NOT NULL,
  `id_order` int(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `current_rate` varchar(255) NOT NULL,
  `penalty` varchar(255) NOT NULL,
  `id_branch` int(255) NOT NULL,
  `id_company` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `partial_redemption_fund`
--

TRUNCATE TABLE `partial_redemption_fund`;
-- --------------------------------------------------------

--
-- Table structure for table `partial_redemption_investment`
--

DROP TABLE IF EXISTS `partial_redemption_investment`;
CREATE TABLE `partial_redemption_investment` (
  `id` int(255) NOT NULL,
  `id_order` int(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `current_rate` varchar(255) NOT NULL,
  `penalty` varchar(255) NOT NULL,
  `id_branch` int(255) NOT NULL,
  `id_company` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `partial_redemption_investment`
--

TRUNCATE TABLE `partial_redemption_investment`;
-- --------------------------------------------------------

--
-- Table structure for table `pf_accounts`
--

DROP TABLE IF EXISTS `pf_accounts`;
CREATE TABLE `pf_accounts` (
  `id` int(255) NOT NULL,
  `account_number` varchar(255) NOT NULL,
  `id_client` int(255) NOT NULL,
  `id_company` int(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `telephone` varchar(255) NOT NULL,
  `id_provident_fund` int(255) NOT NULL,
  `id_user` int(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `voluntary_value` varchar(255) NOT NULL,
  `member_value` varchar(255) NOT NULL,
  `employer_value` varchar(255) NOT NULL,
  `mandatory_value` varchar(255) NOT NULL,
  `residential` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `pf_accounts`
--

TRUNCATE TABLE `pf_accounts`;
--
-- Dumping data for table `pf_accounts`
--

INSERT INTO `pf_accounts` (`id`, `account_number`, `id_client`, `id_company`, `quantity`, `first_name`, `last_name`, `telephone`, `id_provident_fund`, `id_user`, `is_active`, `voluntary_value`, `member_value`, `employer_value`, `mandatory_value`, `residential`, `email`) VALUES
(1, 'ANA/OP/1', 1, 0, '43910.00000', 'Darko', 'Isaac', '262141279', 1, 11, 1, '5000.00000', '10000.00000', '20000.00000', '20000.00000', 'A48A/', 'isaacbremang@gmail.com'),
(2, 'ANA/OP/2', 1, 0, '43910.00000', 'Darko', 'Isaac', '262141279', 1, 11, 1, '5000.00000', '10000.00000', '20000.00000', '20000.00000', 'A48A/', 'isaacbremang@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `placement_companies`
--

DROP TABLE IF EXISTS `placement_companies`;
CREATE TABLE `placement_companies` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `telephone` int(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `id_company` int(255) NOT NULL,
  `id_branch` int(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `location` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `placement_companies`
--

TRUNCATE TABLE `placement_companies`;
--
-- Dumping data for table `placement_companies`
--

INSERT INTO `placement_companies` (`id`, `name`, `telephone`, `email`, `id_company`, `id_branch`, `is_active`, `location`) VALUES
(1, 'Royal Bank', 574389899, 'isaacbremang@gmail.com', 1, 0, 1, 'hjkmj'),
(2, 'CIG Company Limited', 208824342, 'kambodorsa71@gmail.com', 2, 0, 1, 'P.O.BOX AF 2973'),
(3, 'Beige Capital', 2038398328, 'info@gmail.com', 3, 0, 1, 'sdf'),
(4, 'SOVEREIGN BANK', 302550133, '', 2, 0, 1, '116 FREE TOWN AVENUE'),
(5, 'OAK PATNERS', 302550133, '', 2, 0, 1, 'ACCRA'),
(6, 'McOttley Money Lending', 5275, 'ewgs', 3, 0, 1, 'fdssa');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `products`
--

TRUNCATE TABLE `products`;
--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `alias`) VALUES
(1, 'Portfolio Management', 'P.M'),
(2, 'Fixed Term Investment', 'F.T.I'),
(3, 'Welfare Scheme / PF', 'P.F'),
(4, 'C.I.S', 'C.I.S'),
(5, 'Savings Products', 'S.P');

-- --------------------------------------------------------

--
-- Table structure for table `provident_funds`
--

DROP TABLE IF EXISTS `provident_funds`;
CREATE TABLE `provident_funds` (
  `id` int(255) NOT NULL,
  `id_company` int(255) NOT NULL,
  `id_client` int(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `id_user` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `penalty` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `provident_funds`
--

TRUNCATE TABLE `provident_funds`;
--
-- Dumping data for table `provident_funds`
--

INSERT INTO `provident_funds` (`id`, `id_company`, `id_client`, `value`, `quantity`, `date`, `id_user`, `name`, `status`, `penalty`) VALUES
(1, 2, 1, '2', '1000', '1480864672', 11, 'One Piece', 1, '10.9');

-- --------------------------------------------------------

--
-- Table structure for table `provident_funds_history`
--

DROP TABLE IF EXISTS `provident_funds_history`;
CREATE TABLE `provident_funds_history` (
  `id` int(255) NOT NULL,
  `id_company` int(255) NOT NULL,
  `id_client` int(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `id_user` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `former_id` int(255) NOT NULL,
  `penalty` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `provident_funds_history`
--

TRUNCATE TABLE `provident_funds_history`;
--
-- Dumping data for table `provident_funds_history`
--

INSERT INTO `provident_funds_history` (`id`, `id_company`, `id_client`, `value`, `quantity`, `date`, `id_user`, `name`, `status`, `former_id`, `penalty`) VALUES
(1, 2, 1, '2', '1000', '1480864672', 11, 'One Piece', 1, 1, '10');

-- --------------------------------------------------------

--
-- Table structure for table `provident_fund_transaction`
--

DROP TABLE IF EXISTS `provident_fund_transaction`;
CREATE TABLE `provident_fund_transaction` (
  `id` int(255) NOT NULL,
  `amount` varchar(255) NOT NULL DEFAULT '0.00',
  `value` varchar(255) NOT NULL DEFAULT '0',
  `quantity` varchar(255) NOT NULL DEFAULT '0',
  `id_pf_account` int(255) NOT NULL,
  `id_company` int(255) NOT NULL,
  `id_user` int(255) NOT NULL,
  `id_client` int(255) NOT NULL,
  `transaction_type` int(1) NOT NULL DEFAULT '0',
  `id_savings_accounts_transaction` int(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `is_approved` int(1) NOT NULL DEFAULT '1',
  `voluntary_value` varchar(255) NOT NULL DEFAULT '0',
  `member_value` varchar(255) NOT NULL DEFAULT '0',
  `employer_value` varchar(255) NOT NULL DEFAULT '0',
  `mandatory_value` varchar(255) NOT NULL DEFAULT '0',
  `voluntary_amount` varchar(255) NOT NULL DEFAULT '0',
  `member_amount` varchar(255) NOT NULL DEFAULT '0',
  `employer_amount` varchar(255) NOT NULL DEFAULT '0',
  `mandatory_amount` varchar(255) NOT NULL DEFAULT '0',
  `tier_type` int(255) NOT NULL DEFAULT '0',
  `penalty` varchar(255) NOT NULL DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `provident_fund_transaction`
--

TRUNCATE TABLE `provident_fund_transaction`;
--
-- Dumping data for table `provident_fund_transaction`
--

INSERT INTO `provident_fund_transaction` (`id`, `amount`, `value`, `quantity`, `id_pf_account`, `id_company`, `id_user`, `id_client`, `transaction_type`, `id_savings_accounts_transaction`, `date`, `is_approved`, `voluntary_value`, `member_value`, `employer_value`, `mandatory_value`, `voluntary_amount`, `member_amount`, `employer_amount`, `mandatory_amount`, `tier_type`, `penalty`) VALUES
(1, '110.00', '110.00', '55000.00000', 1, 2, 11, 1, 2, 31, '1480868520', 1, '5000.00000', '10000.00000', '20000.00000', '20000.00000', '10', '20', '40', '40', 0, '0.00'),
(2, '20', '20', '10000.00', 1, 2, 11, 1, 1, 0, '1480869646', 1, '0', '0', '0', '0', '0', '0', '0', '0', 1, '2.18000'),
(3, '110.00', '110.00', '55000.00000', 2, 2, 11, 1, 2, 32, '1480878948', 1, '5000.00000', '10000.00000', '20000.00000', '20000.00000', '10', '20', '40', '40', 0, '0.00'),
(4, '10', '10', '5545.00', 2, 2, 11, 1, 1, 0, '1480879017', 1, '0', '0', '0', '0', '0', '0', '0', '0', 1, '1.09000'),
(5, '10', '10', '5545.00', 2, 2, 11, 1, 1, 0, '1480879967', 1, '0', '0', '0', '0', '0', '0', '0', '0', 2, '1.09000');

-- --------------------------------------------------------

--
-- Table structure for table `relation_officers`
--

DROP TABLE IF EXISTS `relation_officers`;
CREATE TABLE `relation_officers` (
  `id` int(255) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `telephone` varchar(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `id_company` int(255) NOT NULL,
  `id_branch` int(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `id_user` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `relation_officers`
--

TRUNCATE TABLE `relation_officers`;
--
-- Dumping data for table `relation_officers`
--

INSERT INTO `relation_officers` (`id`, `fullname`, `email`, `telephone`, `is_active`, `id_company`, `id_branch`, `date`, `id_user`) VALUES
(1, 'Richmond Mensah', 'editors@collegemag.net', '0574389899', 1, 1, 1, '1463602253', 2),
(2, 'Ibrahim', 'root@devappstudio.com', '---', 1, 2, 0, '1468502087', 3),
(3, 'Intalekt Support User', 'isaacbremang@gmail.com', '------', 1, 2, 0, '1468502087', 11),
(4, 'Elizabeth Akua Ampadu', 'elizabeth.akua-ampadu@brooksmoney.com', '2208', 1, 2, 2, '1468505720', 7),
(5, 'Elvis Kambo-Dorsa', 'kambo.dorsa@brooksmoney.com', '2214', 1, 2, 2, '1468505720', 9),
(6, 'Finxl User', 'root@devappstudio.com1', '---', 1, 3, 3, '1469312298', 16),
(7, 'Prosper Deleka', 'prosper.deleka@brooksmoney.com', '2212', 1, 2, 2, '1470399572', 8);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `roles`
--

TRUNCATE TABLE `roles`;
--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `is_active`) VALUES
(1, 'Allow', 1),
(2, 'Insert', 1),
(3, 'Edit', 1),
(4, 'Delete', 1);

-- --------------------------------------------------------

--
-- Table structure for table `savings_accounts`
--

DROP TABLE IF EXISTS `savings_accounts`;
CREATE TABLE `savings_accounts` (
  `id` int(255) NOT NULL,
  `client_id` int(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `timestamp` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `savings_accounts`
--

TRUNCATE TABLE `savings_accounts`;
--
-- Dumping data for table `savings_accounts`
--

INSERT INTO `savings_accounts` (`id`, `client_id`, `amount`, `timestamp`) VALUES
(1, 6, '24053.23', '1480689033'),
(2, 1, '220.0000000000', '1480862941');

-- --------------------------------------------------------

--
-- Table structure for table `savings_accounts_transactions`
--

DROP TABLE IF EXISTS `savings_accounts_transactions`;
CREATE TABLE `savings_accounts_transactions` (
  `id` int(255) NOT NULL,
  `product_id` int(255) NOT NULL DEFAULT '0',
  `product_scheme_id` int(255) NOT NULL DEFAULT '0',
  `savings_account_id` int(255) NOT NULL,
  `transaction_type` int(2) NOT NULL,
  `time_stamp` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `is_approved` int(1) NOT NULL DEFAULT '0',
  `transaction_by` int(255) NOT NULL,
  `approved_by` int(255) NOT NULL,
  `account_number` varchar(255) NOT NULL,
  `remarks` text NOT NULL,
  `id_bank` int(255) NOT NULL DEFAULT '0',
  `means_payment` varchar(255) NOT NULL,
  `cheque_number` varchar(255) NOT NULL,
  `value_date` varchar(255) NOT NULL,
  `id_branch` int(255) NOT NULL,
  `id_company` int(255) NOT NULL,
  `reversal_of` int(255) NOT NULL DEFAULT '0',
  `id_company_bank` int(255) NOT NULL,
  `company_bank_cheque_number` varchar(255) NOT NULL DEFAULT '',
  `invoice_printed` int(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `savings_accounts_transactions`
--

TRUNCATE TABLE `savings_accounts_transactions`;
--
-- Dumping data for table `savings_accounts_transactions`
--

INSERT INTO `savings_accounts_transactions` (`id`, `product_id`, `product_scheme_id`, `savings_account_id`, `transaction_type`, `time_stamp`, `amount`, `is_approved`, `transaction_by`, `approved_by`, `account_number`, `remarks`, `id_bank`, `means_payment`, `cheque_number`, `value_date`, `id_branch`, `id_company`, `reversal_of`, `id_company_bank`, `company_bank_cheque_number`, `invoice_printed`) VALUES
(1, 0, 0, 1, 2, '1480689033', '50000', 1, 11, 11, '100000000003', 'Being New Investment Deposit : Cash', 0, 'Cash', '', '1480633200', 2, 2, 0, 0, '', 0),
(2, 0, 0, 1, 2, '1480689100', '110', 1, 11, 11, '100000000003', 'Deposit For SIS : Cash', 0, 'Cash', '', '1480633200', 2, 2, 0, 0, '', 0),
(3, 0, 0, 1, 1, '1480689344', '50000', 1, 11, 0, '100000000003', 'Booking Of New Investment', 0, '0', '0', '', 2, 2, 0, 0, '', 1),
(4, 1, 0, 1, 2, '1480689344', '1150.6848', 1, 0, 0, '100000000003', 'Depositing Interest After Redemption Period', 0, '', '', '', 0, 0, 0, 0, '', 0),
(5, 1, 0, 1, 2, '1480689344', '1150.6848', 1, 0, 0, '100000000003', 'Depositing Interest After Redemption Period', 0, '', '', '', 0, 0, 0, 0, '', 0),
(6, 1, 0, 1, 2, '1480689344', '1150.6848', 1, 0, 0, '100000000003', 'Depositing Interest After Redemption Period', 0, '', '', '', 0, 0, 0, 0, '', 0),
(7, 1, 0, 1, 2, '1480689344', '50038.35', 1, 0, 0, '100000000003', 'Depositing Interest And Principal After Investment Period', 0, '', '', '', 0, 0, 0, 0, '', 0),
(8, 1, 0, 1, 1, '1480689485', '110', 1, 0, 0, '100000000003', 'New Savings Product Account', 0, '', '', '', 0, 0, 0, 0, '', 0),
(9, 0, 0, 1, 2, '1480689661', '50000', 1, 11, 11, '100000000003', 'Deposit For Portfolio Management : Cash', 0, 'Cash', '', '1480633200', 2, 2, 0, 0, '', 0),
(10, 1, 0, 1, 1, '1480689871', '50000', 1, 0, 0, '100000000003', 'New Purchase Of Fund Asset', 0, '', '', '', 0, 0, 0, 0, '', 0),
(11, 0, 0, 1, 1, '1480689871', '50000', 1, 11, 0, '100000000003', 'Booking Of New Investment', 0, '0', '0', '', 2, 2, 0, 0, '', 1),
(12, 1, 0, 1, 2, '1480689871', '1150.6848', 1, 0, 0, '100000000003', 'Depositing Interest After Redemption Period', 0, '', '', '', 0, 0, 0, 0, '', 0),
(13, 1, 0, 1, 2, '1480689871', '1150.6848', 1, 0, 0, '100000000003', 'Depositing Interest After Redemption Period', 0, '', '', '', 0, 0, 0, 0, '', 0),
(14, 1, 0, 1, 2, '1480689871', '1150.6848', 1, 0, 0, '100000000003', 'Depositing Interest After Redemption Period', 0, '', '', '', 0, 0, 0, 0, '', 0),
(15, 1, 0, 1, 2, '1480689871', '50038.35', 1, 0, 0, '100000000003', 'Depositing Interest And Principal After Investment Period', 0, '', '', '', 0, 0, 0, 0, '', 0),
(16, 0, 0, 1, 1, '1480713081', '50000', 1, 11, 0, '100000000003', 'Booking Of New Investment', 0, '0', '0', '', 2, 2, 0, 0, '', 1),
(17, 1, 0, 1, 2, '1480713081', '1150.6848', 1, 0, 0, '100000000003', 'Depositing Interest After Redemption Period', 0, '', '', '', 0, 0, 0, 0, '', 0),
(18, 1, 0, 1, 2, '1480713082', '1150.6848', 1, 0, 0, '100000000003', 'Depositing Interest After Redemption Period', 0, '', '', '', 0, 0, 0, 0, '', 0),
(19, 1, 0, 1, 2, '1480713082', '1150.6848', 1, 0, 0, '100000000003', 'Depositing Interest After Redemption Period', 0, '', '', '', 0, 0, 0, 0, '', 0),
(20, 1, 0, 1, 2, '1480713082', '50000', 1, 0, 0, '100000000003', 'Being Principal After Investment Period', 0, '', '', '', 0, 0, 0, 0, '', 0),
(21, 1, 0, 1, 2, '1480713082', '38.35', 1, 0, 0, '100000000003', 'Being Final Part Of Interest After Investment Period', 0, '', '', '', 0, 0, 0, 0, '', 0),
(22, 0, 0, 1, 1, '1480713090', '50000', 1, 11, 0, '100000000003', 'Booking Of New Investment', 0, '0', '0', '', 2, 2, 0, 0, '', 1),
(23, 1, 0, 1, 2, '1480713090', '1150.6848', 1, 0, 0, '100000000003', 'Depositing Interest After Redemption Period', 0, '', '', '', 0, 0, 0, 0, '', 0),
(24, 0, 0, 1, 1, '1480713095', '50000', 1, 11, 0, '100000000003', 'Booking Of New Investment', 0, '0', '0', '', 2, 2, 0, 0, '', 1),
(25, 0, 0, 1, 1, '1480714531', '11621', 1, 11, 0, '100000000003', 'Booking Of New Investment', 0, '0', '0', '', 2, 2, 0, 0, '', 1),
(26, 1, 0, 1, 2, '1480714531', '267.4419', 1, 0, 0, '100000000003', 'Being Interest After Redemption Period', 0, '', '', '', 0, 0, 0, 0, '', 0),
(27, 1, 0, 1, 2, '1480714531', '267.4419', 1, 0, 0, '100000000003', 'Being Interest After Redemption Period', 0, '', '', '', 0, 0, 0, 0, '', 0),
(28, 1, 0, 1, 2, '1480714532', '267.4419', 1, 0, 0, '100000000003', 'Being Interest After Redemption Period', 0, '', '', '', 0, 0, 0, 0, '', 0),
(29, 1, 0, 1, 2, '1480714532', '11621', 1, 0, 0, '100000000003', 'Being Principal After Investment Period', 0, '', '', '', 0, 0, 0, 0, '', 0),
(30, 1, 0, 1, 2, '1480714532', '8.91473', 1, 0, 0, '100000000003', 'Being Final Part Interest After Investment Period', 0, '', '', '', 0, 0, 0, 0, '', 0),
(31, 0, 0, 2, 2, '1480862941', '110', 1, 11, 11, '100000000001', 'New PF Upload : Cash', 0, 'Cash', '', '1480806000', 2, 2, 0, 0, '', 0),
(32, 0, 0, 2, 2, '1480878886', '110', 1, 11, 11, '100000000001', 'PF : Cash', 0, 'Cash', '', '1480806000', 2, 2, 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `savings_accounts_transactions_denied`
--

DROP TABLE IF EXISTS `savings_accounts_transactions_denied`;
CREATE TABLE `savings_accounts_transactions_denied` (
  `id` int(255) NOT NULL,
  `product_id` int(255) NOT NULL DEFAULT '0',
  `product_scheme_id` int(255) NOT NULL DEFAULT '0',
  `savings_account_id` int(255) NOT NULL,
  `transaction_type` int(2) NOT NULL,
  `time_stamp` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `is_approved` int(1) NOT NULL DEFAULT '0',
  `transaction_by` int(255) NOT NULL,
  `approved_by` int(255) NOT NULL,
  `account_number` varchar(255) NOT NULL,
  `remarks` text NOT NULL,
  `id_bank` int(255) NOT NULL DEFAULT '0',
  `means_payment` varchar(255) NOT NULL,
  `cheque_number` varchar(255) NOT NULL,
  `value_date` varchar(255) NOT NULL,
  `id_branch` int(255) NOT NULL,
  `id_company` int(255) NOT NULL,
  `reversal_of` int(255) NOT NULL DEFAULT '0',
  `id_company_bank` int(255) NOT NULL,
  `company_bank_cheque_number` varchar(255) NOT NULL DEFAULT '',
  `invoice_printed` int(255) NOT NULL,
  `prev_id` int(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `savings_accounts_transactions_denied`
--

TRUNCATE TABLE `savings_accounts_transactions_denied`;
-- --------------------------------------------------------

--
-- Table structure for table `savings_products`
--

DROP TABLE IF EXISTS `savings_products`;
CREATE TABLE `savings_products` (
  `id` int(255) NOT NULL,
  `id_company` int(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `min_amount` varchar(255) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `time_stamp` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `savings_products`
--

TRUNCATE TABLE `savings_products`;
--
-- Dumping data for table `savings_products`
--

INSERT INTO `savings_products` (`id`, `id_company`, `rate`, `name`, `min_amount`, `remarks`, `time_stamp`) VALUES
(1, 3, '20', 'SIS acount', '50', '', ''),
(2, 3, '22', 'CISA', '20', '', ''),
(3, 2, '6', 'One Piece', '56', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `savings_product_accounts`
--

DROP TABLE IF EXISTS `savings_product_accounts`;
CREATE TABLE `savings_product_accounts` (
  `id` int(255) NOT NULL,
  `id_client` int(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `date_created` varchar(255) NOT NULL,
  `id_user` int(255) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `id_branch` int(255) NOT NULL,
  `id_company` int(255) NOT NULL,
  `id_savings_product` int(255) NOT NULL,
  `is_opened` int(1) NOT NULL DEFAULT '1',
  `is_auth` int(255) NOT NULL DEFAULT '0',
  `id_auth` int(255) NOT NULL,
  `date_closed` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `savings_product_accounts`
--

TRUNCATE TABLE `savings_product_accounts`;
--
-- Dumping data for table `savings_product_accounts`
--

INSERT INTO `savings_product_accounts` (`id`, `id_client`, `code`, `amount`, `date_created`, `id_user`, `remarks`, `id_branch`, `id_company`, `id_savings_product`, `is_opened`, `is_auth`, `id_auth`, `date_closed`) VALUES
(1, 6, '100000000001', '110.000', '1480689485', 11, '', 2, 2, 3, 1, 1, 11, '');

-- --------------------------------------------------------

--
-- Table structure for table `savings_product_transactions`
--

DROP TABLE IF EXISTS `savings_product_transactions`;
CREATE TABLE `savings_product_transactions` (
  `id` int(255) NOT NULL,
  `id_account` int(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `id_user` int(255) NOT NULL,
  `date_created` varchar(255) NOT NULL,
  `id_branch` int(255) NOT NULL,
  `transaction_type` int(255) NOT NULL,
  `remarks` text NOT NULL,
  `is_auth` int(255) NOT NULL DEFAULT '0',
  `id_auth` int(255) NOT NULL,
  `id_company` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `savings_product_transactions`
--

TRUNCATE TABLE `savings_product_transactions`;
--
-- Dumping data for table `savings_product_transactions`
--

INSERT INTO `savings_product_transactions` (`id`, `id_account`, `amount`, `id_user`, `date_created`, `id_branch`, `transaction_type`, `remarks`, `is_auth`, `id_auth`, `id_company`) VALUES
(1, 1, '110', 11, '1480689485', 2, 2, 'Initial Deposit For Account Opening', 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `savings_transaction_type`
--

DROP TABLE IF EXISTS `savings_transaction_type`;
CREATE TABLE `savings_transaction_type` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `savings_transaction_type`
--

TRUNCATE TABLE `savings_transaction_type`;
--
-- Dumping data for table `savings_transaction_type`
--

INSERT INTO `savings_transaction_type` (`id`, `name`) VALUES
(1, 'Withdrawal'),
(2, 'Deposit');

-- --------------------------------------------------------

--
-- Table structure for table `system_logs`
--

DROP TABLE IF EXISTS `system_logs`;
CREATE TABLE `system_logs` (
  `id` int(255) NOT NULL,
  `action` text NOT NULL,
  `narration` text NOT NULL,
  `id_user` int(255) NOT NULL,
  `id_company` int(255) NOT NULL,
  `id_branch` int(255) NOT NULL,
  `stamp` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `system_logs`
--

TRUNCATE TABLE `system_logs`;
--
-- Dumping data for table `system_logs`
--

INSERT INTO `system_logs` (`id`, `action`, `narration`, `id_user`, `id_company`, `id_branch`, `stamp`) VALUES
(1, 'Access', 'Successful Login From User', 11, 2, 2, '1480687453'),
(2, 'Read', 'User Visited The Transactions Page', 11, 2, 2, '1480687467'),
(3, 'Read', 'User Visited The Transactions Page', 11, 2, 2, '1480687986'),
(4, 'Read', 'User Visited The Approve Transactions Page', 11, 2, 2, '1480688002'),
(5, 'Read', 'User Read Notification With Id 1', 11, 2, 2, '1480688002'),
(6, 'Read', 'User Visited The Approve Transactions Page', 11, 2, 2, '1480688008'),
(7, 'Read', 'User Read Notification With Id 1', 11, 2, 2, '1480688008'),
(8, 'Read', 'User Visited The Transactions Page', 11, 2, 2, '1480688029'),
(9, 'Read', 'User Visited The Transactions Page', 11, 2, 2, '1480688090'),
(10, 'Read', 'User Visited The Approve Transactions Page', 11, 2, 2, '1480688103'),
(11, 'Read', 'User Read Notification With Id 2', 11, 2, 2, '1480688103'),
(12, 'Read', 'User Visited The Approve Transactions Page', 11, 2, 2, '1480688122'),
(13, 'Read', 'User Read Notification With Id 2', 11, 2, 2, '1480688122'),
(14, 'Read', 'User Visited The Transactions Page', 11, 2, 2, '1480688991'),
(15, 'Read', 'User Visited The Transactions Page', 11, 2, 2, '1480689034'),
(16, 'Read', 'User Visited The Transactions Page', 11, 2, 2, '1480689101'),
(17, 'Read', 'User Visited The Approve Transactions Page', 11, 2, 2, '1480689104'),
(18, 'Read', 'User Read Notification With Id 2', 11, 2, 2, '1480689104'),
(19, 'Read', 'User Visited The Approve Transactions Page', 11, 2, 2, '1480689110'),
(20, 'Read', 'User Read Notification With Id 2', 11, 2, 2, '1480689110'),
(21, 'Read', 'User Visited The Approve Transactions Page', 11, 2, 2, '1480689114'),
(22, 'Read', 'User Read Notification With Id 2', 11, 2, 2, '1480689114'),
(23, 'Read', 'User Read Notification With Id 3', 11, 2, 2, '1480689321'),
(24, 'Read', 'User Read Notification With Id 4', 11, 2, 2, '1480689337'),
(25, 'Read', 'User Read Notification With Id 6', 11, 2, 2, '1480689490'),
(26, 'Read', 'User Read Notification With Id 6', 11, 2, 2, '1480689586'),
(27, 'Read', 'User Read Notification With Id 6', 11, 2, 2, '1480689591'),
(28, 'Read', 'User Visited The Transactions Page', 11, 2, 2, '1480689626'),
(29, 'Read', 'User Visited The Transactions Page', 11, 2, 2, '1480689661'),
(30, 'Read', 'User Visited The Approve Transactions Page', 11, 2, 2, '1480689680'),
(31, 'Read', 'User Read Notification With Id 7', 11, 2, 2, '1480689680'),
(32, 'Read', 'User Visited The Approve Transactions Page', 11, 2, 2, '1480689685'),
(33, 'Read', 'User Read Notification With Id 7', 11, 2, 2, '1480689685'),
(34, 'Read', 'User Read Notification With Id 8', 11, 2, 2, '1480689831'),
(35, 'Read', 'User Read Notification With Id 9', 11, 2, 2, '1480689850'),
(36, 'Access', 'Successful Login From User', 11, 2, 2, '1480712664'),
(37, 'Read', 'User Read Notification With Id 11', 11, 2, 2, '1480713064'),
(38, 'Read', 'User Read Notification With Id 12', 11, 2, 2, '1480713074'),
(39, 'Read', 'User Read Notification With Id 10', 11, 2, 2, '1480713921'),
(40, 'Read', 'User Read Notification With Id 14', 11, 2, 2, '1480714515'),
(41, 'Read', 'User Read Notification With Id 15', 11, 2, 2, '1480714525'),
(42, 'Access', 'Successful Login From User', 11, 2, 2, '1480862842'),
(43, 'Read', 'User Visited The Transactions Page', 11, 2, 2, '1480862910'),
(44, 'Read', 'User Visited The Transactions Page', 11, 2, 2, '1480862941'),
(45, 'Read', 'User Visited The Approve Transactions Page', 11, 2, 2, '1480864622'),
(46, 'Read', 'User Read Notification With Id 17', 11, 2, 2, '1480864622'),
(47, 'Read', 'User Visited The Approve Transactions Page', 11, 2, 2, '1480864628'),
(48, 'Read', 'User Read Notification With Id 17', 11, 2, 2, '1480864628'),
(49, 'Read', 'User Visited The Transactions Page', 11, 2, 2, '1480878858'),
(50, 'Read', 'User Visited The Transactions Page', 11, 2, 2, '1480878886'),
(51, 'Read', 'User Visited The Approve Transactions Page', 11, 2, 2, '1480878892'),
(52, 'Read', 'User Read Notification With Id 18', 11, 2, 2, '1480878892'),
(53, 'Read', 'User Visited The Approve Transactions Page', 11, 2, 2, '1480878898'),
(54, 'Read', 'User Read Notification With Id 18', 11, 2, 2, '1480878898'),
(55, 'Read', 'User Visited The Client Setup Page', 11, 2, 2, '1480881032'),
(56, 'Read', 'User Visited The Client Setup Page', 11, 2, 2, '1480881045');

-- --------------------------------------------------------

--
-- Table structure for table `system_modules`
--

DROP TABLE IF EXISTS `system_modules`;
CREATE TABLE `system_modules` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `system_modules`
--

TRUNCATE TABLE `system_modules`;
--
-- Dumping data for table `system_modules`
--

INSERT INTO `system_modules` (`id`, `name`, `is_active`, `url`) VALUES
(1, 'Fixed Term Investment', 1, ''),
(2, 'Portfolio Management', 1, ''),
(3, 'Welfare Scheme / PF', 1, ''),
(4, 'C.I.S', 1, ''),
(5, 'Client Management', 1, ''),
(6, 'Bulk Messaging', 1, ''),
(7, 'System Settings', 1, ''),
(8, 'Reports / General Ledgers\r\n', 1, ''),
(9, 'Savings Product', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `system_sub_modules`
--

DROP TABLE IF EXISTS `system_sub_modules`;
CREATE TABLE `system_sub_modules` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `is_active` int(1) NOT NULL,
  `id_system_module` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `system_sub_modules`
--

TRUNCATE TABLE `system_sub_modules`;
--
-- Dumping data for table `system_sub_modules`
--

INSERT INTO `system_sub_modules` (`id`, `name`, `is_active`, `id_system_module`) VALUES
(1, 'Dashboard', 1, 5),
(2, 'Clients', 1, 5),
(3, 'Transactions', 1, 5),
(4, 'Set Up', 1, 5),
(5, 'Dashboard', 1, 1),
(6, 'Liabilities', 1, 1),
(7, 'Assets', 1, 1),
(8, 'Settings', 1, 1),
(10, 'Dashboard', 1, 2),
(11, 'Assets', 1, 2),
(12, 'Savings', 1, 9),
(13, 'Settings', 1, 9),
(14, 'All Bulk Messages', 1, 6),
(15, 'Send Bulk Text Messages', 1, 6),
(16, 'Send Bulk Emails', 1, 6),
(17, 'Settings', 1, 6),
(18, 'Ledgers', 1, 8),
(19, 'G.L Statement', 1, 8),
(20, 'Fund Management Report', 1, 8),
(21, 'Investment Reports', 1, 8),
(22, 'Placement Reports', 1, 8),
(23, 'Client Statements', 1, 8),
(24, 'Trial Balance', 1, 8),
(25, 'Manual G.L Entry', 1, 8),
(27, 'Dashboard', 1, 7),
(28, 'Assets Settings', 1, 7),
(29, 'Bank Settings', 1, 7),
(30, 'Branch Settings', 1, 7),
(31, 'Company Settings', 1, 7),
(32, 'Manage Pending Accounts', 1, 9),
(33, 'Manage Pending Transactions', 1, 9),
(34, 'Clients', 1, 3),
(35, 'Manage Transactions', 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `system_sub_sub_module`
--

DROP TABLE IF EXISTS `system_sub_sub_module`;
CREATE TABLE `system_sub_sub_module` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `id_system_sub_module` int(255) NOT NULL,
  `is_active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `system_sub_sub_module`
--

TRUNCATE TABLE `system_sub_sub_module`;
--
-- Dumping data for table `system_sub_sub_module`
--

INSERT INTO `system_sub_sub_module` (`id`, `name`, `id_system_sub_module`, `is_active`) VALUES
(1, 'Client Setup', 2, 1),
(2, 'Client Management', 2, 1),
(3, 'Transactions', 3, 1),
(4, 'Manage Transactions', 3, 1),
(5, 'Relation Officer', 4, 1),
(6, 'Countries', 4, 1),
(7, 'Id Cards', 4, 1),
(8, 'Business Types', 4, 1),
(9, 'All Liabilities', 6, 1),
(10, 'Orders', 6, 1),
(11, 'Trading', 6, 1),
(12, 'Authorization', 6, 1),
(13, 'All Assets', 7, 1),
(14, 'Investments Due', 7, 1),
(15, 'Orders', 7, 1),
(16, 'Trading', 7, 1),
(17, 'Authorization', 7, 1),
(18, 'Investment Types', 8, 1),
(19, 'All Assets', 11, 1),
(20, 'Orders', 11, 1),
(21, 'Trading', 11, 1),
(22, 'Authorization', 11, 1),
(23, 'Savings Products', 13, 1),
(24, 'Bulk Messages Settings', 17, 1),
(25, 'Asset Classes', 28, 1),
(26, 'Asset Categories', 28, 1),
(27, 'Instruments', 28, 1),
(28, 'Placement Companies', 28, 1),
(29, 'Available Banks', 29, 1),
(30, 'Company Bank Account', 29, 1),
(31, 'User Management', 30, 1),
(32, 'Settings', 30, 1),
(33, 'User Management', 31, 1),
(34, 'Branches', 31, 1),
(35, 'Settings', 31, 1),
(36, 'Transaction Reversal', 3, 1),
(37, 'Approve Client Details Editing', 2, 1),
(38, 'Client Investment Management', 2, 1),
(39, 'Savings Accounts', 12, 1),
(40, 'Upload Members', 34, 1),
(41, 'Transaction', 34, 1),
(42, 'Close Account', 34, 1),
(43, 'Manage Transactions', 35, 1),
(44, 'Manage Members', 34, 1),
(45, 'Welfare Settings', 34, 1);

-- --------------------------------------------------------

--
-- Table structure for table `temp_value`
--

DROP TABLE IF EXISTS `temp_value`;
CREATE TABLE `temp_value` (
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `dob` varchar(255) NOT NULL,
  `value` double NOT NULL,
  `val` int(1) NOT NULL DEFAULT '1',
  `id_user` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `temp_value`
--

TRUNCATE TABLE `temp_value`;
-- --------------------------------------------------------

--
-- Table structure for table `titles`
--

DROP TABLE IF EXISTS `titles`;
CREATE TABLE `titles` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `titles`
--

TRUNCATE TABLE `titles`;
--
-- Dumping data for table `titles`
--

INSERT INTO `titles` (`id`, `name`) VALUES
(1, 'Mr.'),
(2, 'Mrs.'),
(3, 'Miss'),
(4, 'Dr.');

-- --------------------------------------------------------

--
-- Table structure for table `top_up_fund`
--

DROP TABLE IF EXISTS `top_up_fund`;
CREATE TABLE `top_up_fund` (
  `id` int(255) NOT NULL,
  `id_order` int(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `current_rate` varchar(255) NOT NULL,
  `penalty` varchar(255) NOT NULL,
  `id_branch` int(255) NOT NULL,
  `id_company` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `top_up_fund`
--

TRUNCATE TABLE `top_up_fund`;
-- --------------------------------------------------------

--
-- Table structure for table `top_up_investment`
--

DROP TABLE IF EXISTS `top_up_investment`;
CREATE TABLE `top_up_investment` (
  `id` int(255) NOT NULL,
  `id_order` int(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `current_rate` varchar(255) NOT NULL,
  `penalty` varchar(255) NOT NULL,
  `id_branch` int(255) NOT NULL,
  `id_company` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `top_up_investment`
--

TRUNCATE TABLE `top_up_investment`;
-- --------------------------------------------------------

--
-- Table structure for table `transaction_types`
--

DROP TABLE IF EXISTS `transaction_types`;
CREATE TABLE `transaction_types` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `transaction_types`
--

TRUNCATE TABLE `transaction_types`;
--
-- Dumping data for table `transaction_types`
--

INSERT INTO `transaction_types` (`id`, `name`) VALUES
(1, 'Placement'),
(2, 'Returns'),
(3, 'Settlement\r\n'),
(4, 'New Investment\r\n'),
(5, 'Credit'),
(6, 'Debit'),
(7, 'Top Up');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `id_branch` int(255) NOT NULL DEFAULT '1',
  `id_company` int(255) NOT NULL DEFAULT '1',
  `id_user_group` int(255) NOT NULL DEFAULT '0',
  `fullname` varchar(255) NOT NULL,
  `last_login` varchar(255) NOT NULL,
  `login_id` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `is_suspended` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `users`
--

TRUNCATE TABLE `users`;
--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `id_branch`, `id_company`, `id_user_group`, `fullname`, `last_login`, `login_id`, `email`, `phone`, `address`, `is_suspended`) VALUES
(1, 'root', 'sha256:1000:ujiui4HPc8nNL1f+hrNWHCCNPNsY0uq+:5WrF9qqdJKpp5aojtx+zcLHTEoyVjJ2e', 1, 1, -1, 'Isaac Bremang Darko', '1479417963', '', '', '', '', 0),
(2, 'hfc.admin', 'sha256:1000:lWA7MWTpr3qE2VeTsMYjfS+jU5O6IdG8:SUX6/bsnen1+zRMtgLcSMVHXIOJ0t5Z5', 1, 1, 0, 'Richmond Mensah', '1469024322', '', 'editors@collegemag.net', '0574389899', 'fhgfdsds', 0),
(3, 'ibrahim_root', 'sha256:1000:yQfC4vjZ9XHugbFLi5nuzilJiIz0owj0:648MtFb1VHfXGxD6eMlXWGwoRVtP4wwN', 0, 2, 9, 'Ibrahim', '1479746405', '', 'root@devappstudio.com', '---', '---', 0),
(4, 'SuMub', 'sha256:1000:IEnkkP6rc60wbrzH9LFsmQwvmAq9c1/4:zE0NX9hu1aUMBnKNyH3JAUguH3wSVrbg', 2, 2, 14, 'Sumaya Mubashiru', '1474533409', '', 'sumayamubashiru@brooksmoney.com', '0246852220', 'Brooks', 0),
(5, 'ChYin', 'sha256:1000:KVdhv0gfPCwB0r3BXWNwT3mCl+pfN7sX:Jpdamr5JghVhKbbU1MmhiqBDuG+6bzYr', 2, 2, 17, 'Christopher Yin', '1476796682', '', 'christopher.yin@brooksmoney.com', '2213', 'Brooks', 0),
(6, 'PaFed', 'sha256:1000:sNQsxl7zoOy+eNcBslvY9CYpFf7jxUOO:0gOk35+GqwbtErvmqcDjKgI05TkLV0bV', 2, 2, 15, 'Patience Feda', '1480346129', '', 'patience.feda@brooksmoney.com', '2210', 'BROOKS', 0),
(7, 'ElAmp', 'sha256:1000:S+H+PnhSzkzlJRlid8oMBwCXb0MKCdvg:BSEmyAeujotKsX/Nu6HgwKsN9QtmOp39', 2, 2, 12, 'Elizabeth Akua Ampadu', '1478529735', '', 'elizabeth.akua-ampadu@brooksmoney.com', '2208', 'BROOKS', 0),
(8, 'PrDel', 'sha256:1000:OXc0OuTrLXXk8OhqwmjHf9D4rRz9IzM9:PDNGluKb1qyFz+rr1c+4jFYjchkfeC4z', 2, 2, 19, 'Prosper Deleka', '1478540687', '', 'prosper.deleka@brooksmoney.com', '2212', 'BROOKS', 0),
(9, 'ElDor', 'sha256:1000:7JH9ZXxJJXpegnF8Qt5cKv4e3YgX4qZR:Y3kQ7H5e2JoWNMf6+EmFBZkDKL5enEYH', 2, 2, 19, 'Elvis Kambo-Dorsa', '1468496240', '', 'kambo.dorsa@brooksmoney.com', '2214', 'BROKKS', 0),
(10, 'DanquaGo', 'sha256:1000:kFZbYE2ws9NOzG7skgLiGq4qs53Ucqw/:j7y7TAJL22LDbp3TPWwtSAmP1qyjZnUN', 2, 2, 9, 'Gordon Danquah', '1470843291', '', 'gordon.danquah@brooksmoney.com', '2224', 'Lymin Creek', 0),
(11, 'support_user', 'sha256:1000:qMlZ0RqOzvkQFUiLszQMX4vUvd4PHDIy:8toDZ0ATMc5dL3S8kHSriaqw1uo5yATF', 2, 2, -1, 'Intalekt Support User', '1480862842', '', 'isaacbremang@gmail.com', '------', '-----', 0),
(12, 'isaac', 'sha256:1000:DzT+hj0AZy9B1LxwrvxQRzA46ZOtlEP4:uHUeGEB55bv112/I6WISYkP8v+9uJ36a', 2, 2, 0, 'Isaac', '1468496995', '', 'isaacbremang@gmai.com', '------', '-----', 0),
(13, 'brainiac', 'sha256:1000:YmLGn/TPFxuB3J6EYPekm6rQ7cM2Fbyd:P02d2DBKihnyER4VUWo9FS2WA2rxjUwy', 1, 1, 9, 'Isaac', '1469105734', '', 'isaacbremang@igmail.com', '00233262141279', '---', 0),
(14, 'TaylorLo', 'sha256:1000:wQ3vrzAq5/quIWV0ivfLa5tIOMSjgZfP:hNgHCx2BgJTfBmi36nz4sCQvKFyI3/1b', 2, 2, 8, 'Loretta Taylor', '1469019006', '', 'loretta.taylor@lymincreek.com', '2240', 'Lymin Creek', 0),
(15, 'LeNya', 'sha256:1000:tv9Mt6niq+GPagfMu2aYUVjM0kJS3Xzd:+yGcA1tqpUaiplmbROsUYPotpU5c1k6d', 2, 2, 21, 'Leonard Nyakpo', '1471958888', '', 'leonard.nakpo@brooksmoney.com', '2226', 'BROOKS', 0),
(16, 'support_user_finxl', 'sha256:1000:ghYE8HJ2auE6qyROFuUBPMKJi0klPhF/:Nd7rAnAmsFwW2+92AXnIj21JairPtOEb', 3, 3, -1, 'Finxl User', '1480260846', '', 'root@devappstudio.com1', '---', '-----', 0),
(17, 'benkuj', 'sha256:1000:jThAScgeOZeiMndkYpeG+/+lcTWKG/Rp:VRfGKxq+B/HMkAnS+92q6MXW2ut/66Iu', 2, 2, 9, 'Loretta Taylor', '1470669848', '', 'lorreta.taylor@brooksmoney.com', '0273458526', '-- --', 0),
(18, 'EwDan', 'sha256:1000:AvKEySybBKw4Z1rs5rN4h1Sayc3mcive:IQ4Sjg7ulxUKHZ/LJKWovF3gBdeVge+M', 5, 2, 11, 'Ewurama Danso', '1479289229', '', 'ewurama.danso@brooksmoney.com', '2202', 'BROOKS', 0),
(19, 'BeKur', 'sha256:1000:GCdG9340LVsz+sQpAG2/EMkj3/QgiLEg:dyPzVV2cVsYium6OGRzq/qLgGnEwTuef', 2, 2, 8, 'Benn Kujar', '', '', 'benn.kujar@lymincreek.com', '2222', 'Lymin Creek', 0),
(20, 'LuAhi', 'sha256:1000:4DJ/DeuTD/9U7buw5HolejkWAmOivkjR:L9XzI5Q0ts4spHPkond9JspjJV7dk0t3', 4, 2, 11, 'Lucas Worlanyo Ahiable ', '1480340757', '', 'lucas.ahiable@brooksmoney.com', '2202', 'BROOKS', 0),
(21, 'Test_Prosper', 'sha256:1000:xTPSLNe/8unZMRDM9VwYBShkXkX7R5dL:M8oKoRZ2PE97ShXfuJUS0JM3bhSnkNgK', 2, 2, 18, 'test account', '1478537143', '', 'ibrahim.mohammed@brooksmoney.com', '2240', 'ips', 0),
(22, 'EuDan', 'sha256:1000:XY6/ka/R1U5/mNLwdJL7zXrIGt9OZIxE:zUeFErntKvRCJG7TTdVUAivLdxhDSsFq', 2, 2, 15, 'Eunice Ofosu-Dankyi', '1471436332', '', 'eunice.ofosu-dankyi@brooksmoney.com', '2211', 'BROOKS', 0),
(23, 'Test1_Prosper', 'sha256:1000:ZcIgDTAMZferGz3iWGoEd99qZpgOyejK:98oqzNPXvyPruFhE3feCrGwcbQJYgohY', 2, 2, 20, 'Test1', '1480325272', '', 'ibrahim.mohammed@lymincreek.com', '2214', 'BROOKS', 0),
(24, 'EmDan', 'sha256:1000:cF99U0OEHHgbi9JkPDnB4dsuJh+/OPJM:rg0arKsT7z0UjqqTSZMNb407DBgOQ0IQ', 2, 2, 8, 'Emmanuel Danso-Boafo', '1471621376', '', 'emmanuel.danfo-boafo@brooksmony.com', '2203', 'BROOKS', 0),
(25, 'elvis', 'sha256:1000:jSiMf2YAU7E3uIKMibxE7TIiKTCTpdTQ:1ow9V2HK+PNUGYYJUQV97b2fe6eH00hu', 3, 3, -1, 'Elvis', '1478773584', '', 'testaccount@in.com', '00233262141279', '-----', 0),
(26, 'usr', 'sha256:1000:0adjFut1/PLfdkI9tlKLqDaqYCEeJT0N:MWvosD5rpp+nyK6XfbzKMotdwVfLU6W0', 2, 2, 9, 'Isaac', '1475591558', '', 'abraham.nikoilai@koteycommunication.com', '00233262141279', 'A48A/2B Candle Link Laterbiokorshie Accra', 0),
(27, 'DziBe', 'sha256:1000:frjzcXSRgl6FNscPCTFlSbKeMrf1Oe0M:WIB83WhelhJJCPsKOyg2Jbm2XW5lK3a+', 2, 2, 13, 'Benjamin Dzisam', '1475422431', '', 'benjamin.dzisam@brooksmoney.com', '2217', 'BROOKS', 0),
(28, 'support_user1', 'sha256:1000:ETaRUmiQvXMP9OFILJK5GhXavPDSw6rf:n5YCQJYv21QI91X41NpvL9wpTB7oxL3O', 0, 4, -1, 'Intalekt Support Team', '1477922580', '', 'ii@ii.net', '+233262141279', '----', 0),
(29, 'EdAsa', 'sha256:1000:5K+hVh/ahQ4V8tPqhIYebzFoDJW1EMWF:zTaTz7IkjJLxpFCL1iX/AOnX6uvteE3k', 2, 2, 8, 'EDWARD AYENSU ASANTE', '1480068727', '', 'edward.ayensu-asante@brooksmoney.com', '2226', 'Accra', 0),
(30, 'GeAka', 'sha256:1000:EjAbfa7Cj4ZCE0JJI7Fr9lBZq0txXCoa:V/TVAse9fyy2lXQDJ8Fo2C2W9lzmRDSi', 2, 2, 8, 'GEORGE AKAMA', '', '', 'george.akama@brooksmoney.com', '2213', 'Accra', 0),
(31, 'ErAch', 'sha256:1000:cZXXfwSvwVypmF6sfUIQK8p5VDTLX1yZ:D0fNdMpCb4hjiGz3yHSZmaZ6IDD8hU2e', 2, 2, 8, 'ERIC ACHEAMPONG', '1480347921', '', 'eric.acheampong@brooksmoney.com', '2213', 'Accra', 0),
(32, 'FrApp', 'sha256:1000:lfT1pj58F/XgPQeMth2/4lzeakYfLWzH:rBP2frk52tq9ldXTTxyU3LKflbcR0gKK', 2, 2, 8, 'FREDRICK APPIAH', '1480068753', '', 'fredrick.appiah@brooksmoney.com', '2209', 'Accra', 0),
(33, 'BOENO', 'sha256:1000:8NAg6NwzHtiqTMZKPKXpLWbqZZVrF8mG:eyIqLpI3d9/6Q/6ajZnIvuw9S7B6WR5h', 2, 2, 9, 'Enock Boadi-Ansah', '1479997773', '', 'enock.baodi-ansah@lymincreek.com', '0208553357', 'Lymin Creek', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_groups`
--

DROP TABLE IF EXISTS `user_groups`;
CREATE TABLE `user_groups` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `id_branch` int(255) NOT NULL DEFAULT '1',
  `id_company` int(255) NOT NULL DEFAULT '1',
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `user_groups`
--

TRUNCATE TABLE `user_groups`;
--
-- Dumping data for table `user_groups`
--

INSERT INTO `user_groups` (`id`, `name`, `id_branch`, `id_company`, `description`) VALUES
(1, 'Company Administrator', 1, 1, 'Company super user'),
(2, 'Accounts Group', 0, 2, 'officers in accounts'),
(3, 'SALES MANAGER', 0, 2, 'SALES MANAGER'),
(4, 'ACCOUNTS MANAGER', 0, 2, 'ACC MANAGER'),
(5, 'SALES EXECUTIVE', 0, 2, 'SALES EXEC.'),
(6, 'CUSTOMER SERVICE MANAGER', 0, 2, 'CS MANAGER'),
(7, 'CUSTOMER SERVICE OFFICER', 0, 2, 'CS OFFICER'),
(8, 'Temp User Group', 0, 2, 'Temporary Administrators'),
(9, 'System Administrators', 0, 2, 'Complete Conrtol Over System'),
(10, 'Temp', 2, 2, 'Trial'),
(11, 'CS_ClientSetup', 0, 2, 'Customer Service Officers'),
(12, 'CS_Mgr', 0, 2, 'Customer Service Manager'),
(13, 'CS_RelationshipMgt', 0, 2, 'Relationship Managers'),
(14, 'Sales_Mgr', 0, 2, 'Sales Manager'),
(15, 'Ac_DepWdr', 0, 2, 'Accounts - Deposits and Redrawals'),
(16, 'Ac_Treasury', 0, 2, 'Acconts Treasury'),
(17, 'Ac_Mgr', 0, 2, 'Accounts Manager'),
(18, 'AP_OrderSetup', 0, 2, 'Asset and Pension Setup'),
(19, 'AP_Trading', 0, 2, 'Asset and Pension Trading'),
(20, 'AP_Mgr', 0, 2, 'Asset and Pensions Manager'),
(21, 'M_Dir', 0, 2, 'Chief Executive Officer'),
(22, 'Sales_Exec', 0, 2, 'Sales Exectives'),
(23, 'finance', 3, 3, 'fvef');

-- --------------------------------------------------------

--
-- Table structure for table `user_groups_roles_modules_sub_module`
--

DROP TABLE IF EXISTS `user_groups_roles_modules_sub_module`;
CREATE TABLE `user_groups_roles_modules_sub_module` (
  `id` int(255) NOT NULL,
  `id_user_group` int(255) NOT NULL,
  `id_role` int(255) NOT NULL,
  `is_modules_sub_module` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `user_groups_roles_modules_sub_module`
--

TRUNCATE TABLE `user_groups_roles_modules_sub_module`;
-- --------------------------------------------------------

--
-- Table structure for table `user_group_roles_modules_sub_module`
--

DROP TABLE IF EXISTS `user_group_roles_modules_sub_module`;
CREATE TABLE `user_group_roles_modules_sub_module` (
  `id` int(255) NOT NULL,
  `id_user` int(255) NOT NULL,
  `id_role` int(255) NOT NULL,
  `id_system_module` int(255) NOT NULL,
  `id_system_sub_module` int(255) NOT NULL,
  `id_system_sub_sub_module` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `user_group_roles_modules_sub_module`
--

TRUNCATE TABLE `user_group_roles_modules_sub_module`;
--
-- Dumping data for table `user_group_roles_modules_sub_module`
--

INSERT INTO `user_group_roles_modules_sub_module` (`id`, `id_user`, `id_role`, `id_system_module`, `id_system_sub_module`, `id_system_sub_sub_module`) VALUES
(1, 8, 1, 1, 5, 0),
(2, 8, 3, 1, 5, 0),
(3, 8, 4, 1, 5, 0),
(4, 8, 1, 1, 6, 9),
(5, 8, 2, 1, 6, 9),
(6, 8, 3, 1, 6, 9),
(7, 8, 4, 1, 6, 9),
(8, 8, 1, 1, 6, 10),
(9, 8, 1, 1, 6, 11),
(10, 8, 2, 1, 6, 10),
(11, 8, 2, 1, 6, 11),
(12, 8, 3, 1, 6, 10),
(13, 8, 3, 1, 6, 11),
(14, 8, 4, 1, 6, 10),
(15, 8, 4, 1, 6, 11),
(16, 8, 1, 1, 6, 12),
(17, 8, 1, 1, 7, 13),
(18, 8, 2, 1, 6, 12),
(19, 8, 2, 1, 7, 13),
(20, 8, 3, 1, 6, 12),
(21, 8, 3, 1, 7, 13),
(22, 8, 4, 1, 6, 12),
(23, 8, 4, 1, 7, 13),
(24, 8, 1, 1, 7, 14),
(25, 8, 1, 1, 7, 15),
(26, 8, 2, 1, 7, 14),
(27, 8, 2, 1, 7, 15),
(28, 8, 3, 1, 7, 14),
(29, 8, 3, 1, 7, 15),
(30, 8, 4, 1, 7, 15),
(31, 8, 4, 1, 7, 14),
(32, 8, 1, 1, 7, 16),
(33, 8, 1, 1, 7, 17),
(34, 8, 2, 1, 7, 16),
(35, 8, 4, 1, 7, 16),
(36, 8, 2, 1, 7, 17),
(37, 8, 3, 1, 7, 16),
(38, 8, 4, 1, 7, 17),
(39, 8, 3, 1, 7, 17),
(40, 8, 1, 1, 8, 18),
(41, 8, 2, 1, 8, 18),
(42, 8, 3, 1, 8, 18),
(43, 8, 4, 1, 8, 18),
(44, 8, 4, 1, 8, 18),
(45, 8, 1, 2, 10, 0),
(46, 8, 3, 2, 10, 0),
(47, 8, 4, 2, 10, 0),
(48, 8, 1, 2, 11, 19),
(49, 8, 2, 2, 11, 19),
(50, 8, 3, 2, 11, 19),
(51, 8, 4, 2, 11, 19),
(52, 8, 1, 2, 11, 20),
(53, 8, 2, 2, 11, 20),
(54, 8, 3, 2, 11, 20),
(55, 8, 1, 2, 11, 21),
(56, 8, 2, 2, 11, 21),
(57, 8, 3, 2, 11, 21),
(58, 8, 4, 2, 11, 21),
(59, 8, 4, 2, 11, 20),
(60, 8, 1, 2, 11, 22),
(61, 8, 2, 2, 11, 22),
(62, 8, 3, 2, 11, 22),
(63, 8, 4, 2, 11, 22),
(64, 8, 1, 5, 1, 0),
(65, 8, 3, 5, 1, 0),
(66, 8, 1, 5, 2, 1),
(67, 8, 4, 5, 1, 0),
(68, 8, 2, 5, 2, 1),
(69, 8, 3, 5, 2, 1),
(70, 8, 4, 5, 2, 1),
(71, 8, 1, 5, 2, 2),
(72, 8, 2, 5, 2, 2),
(73, 8, 3, 5, 2, 2),
(74, 8, 4, 5, 2, 2),
(75, 8, 1, 5, 3, 3),
(76, 8, 2, 5, 3, 3),
(77, 8, 3, 5, 3, 3),
(78, 8, 4, 5, 3, 3),
(79, 8, 1, 5, 3, 4),
(80, 8, 2, 5, 3, 4),
(81, 8, 3, 5, 3, 4),
(82, 8, 4, 5, 3, 4),
(83, 8, 1, 5, 3, 36),
(84, 8, 2, 5, 3, 36),
(85, 8, 3, 5, 3, 36),
(86, 8, 4, 5, 3, 36),
(87, 8, 1, 5, 4, 5),
(88, 8, 2, 5, 4, 5),
(89, 8, 3, 5, 4, 5),
(90, 8, 4, 5, 4, 5),
(91, 8, 1, 5, 4, 6),
(92, 8, 2, 5, 4, 6),
(93, 8, 3, 5, 4, 6),
(94, 8, 4, 5, 4, 6),
(95, 8, 1, 5, 4, 7),
(96, 8, 2, 5, 4, 7),
(97, 8, 3, 5, 4, 7),
(98, 8, 4, 5, 4, 7),
(99, 8, 1, 5, 4, 8),
(100, 8, 2, 5, 4, 8),
(101, 8, 3, 5, 4, 8),
(102, 8, 4, 5, 4, 8),
(103, 8, 1, 6, 14, 0),
(104, 8, 3, 6, 14, 0),
(105, 8, 4, 6, 14, 0),
(106, 8, 1, 6, 15, 0),
(107, 8, 3, 6, 15, 0),
(108, 8, 4, 6, 15, 0),
(109, 8, 1, 6, 16, 0),
(110, 8, 3, 6, 16, 0),
(111, 8, 1, 6, 17, 24),
(112, 8, 2, 6, 17, 24),
(113, 8, 3, 6, 17, 24),
(114, 8, 4, 6, 17, 24),
(116, 8, 1, 8, 18, 0),
(117, 8, 3, 8, 18, 0),
(118, 8, 4, 8, 18, 0),
(119, 8, 1, 8, 19, 0),
(120, 8, 3, 8, 19, 0),
(121, 8, 4, 8, 19, 0),
(122, 8, 1, 8, 20, 0),
(123, 8, 3, 8, 20, 0),
(124, 8, 4, 8, 20, 0),
(125, 8, 1, 8, 21, 0),
(126, 8, 3, 8, 21, 0),
(127, 8, 4, 8, 21, 0),
(128, 8, 1, 8, 22, 0),
(129, 8, 3, 8, 22, 0),
(130, 8, 4, 8, 22, 0),
(131, 8, 1, 8, 23, 0),
(132, 8, 3, 8, 23, 0),
(133, 8, 4, 8, 23, 0),
(134, 8, 1, 8, 24, 0),
(135, 8, 3, 8, 24, 0),
(136, 8, 4, 8, 24, 0),
(137, 8, 1, 8, 25, 0),
(138, 8, 3, 8, 25, 0),
(139, 8, 4, 8, 25, 0),
(140, 8, 1, 9, 12, 0),
(141, 8, 3, 9, 12, 0),
(142, 8, 4, 9, 12, 0),
(143, 8, 1, 9, 13, 23),
(144, 8, 2, 9, 13, 23),
(145, 8, 3, 9, 13, 23),
(146, 8, 4, 9, 13, 23),
(147, 9, 1, 9, 13, 23),
(148, 9, 2, 9, 13, 23),
(149, 9, 3, 9, 13, 23),
(150, 9, 4, 9, 13, 23),
(151, 9, 1, 9, 12, 0),
(152, 9, 3, 9, 12, 0),
(153, 9, 4, 9, 12, 0),
(154, 9, 1, 8, 25, 0),
(155, 9, 1, 1, 5, 0),
(156, 9, 3, 8, 25, 0),
(157, 9, 3, 1, 5, 0),
(158, 9, 4, 8, 25, 0),
(159, 9, 4, 1, 5, 0),
(160, 9, 1, 8, 24, 0),
(161, 9, 1, 1, 6, 9),
(162, 9, 1, 8, 23, 0),
(163, 9, 2, 1, 6, 9),
(164, 9, 3, 1, 6, 9),
(165, 9, 1, 8, 22, 0),
(166, 9, 4, 1, 6, 9),
(167, 9, 1, 8, 21, 0),
(168, 9, 1, 1, 6, 10),
(169, 9, 1, 8, 20, 0),
(170, 9, 2, 1, 6, 10),
(171, 9, 3, 1, 6, 10),
(172, 9, 1, 8, 19, 0),
(173, 9, 4, 1, 6, 10),
(174, 9, 1, 8, 18, 0),
(175, 9, 1, 1, 6, 11),
(176, 9, 1, 7, 31, 35),
(177, 9, 2, 1, 6, 11),
(178, 9, 1, 7, 31, 34),
(179, 9, 3, 1, 6, 11),
(180, 9, 1, 7, 31, 33),
(181, 9, 4, 1, 6, 11),
(182, 9, 1, 7, 30, 32),
(183, 9, 1, 1, 6, 12),
(184, 9, 1, 7, 30, 31),
(185, 9, 2, 1, 6, 12),
(186, 9, 3, 1, 6, 12),
(187, 9, 1, 7, 29, 30),
(188, 9, 4, 1, 6, 12),
(189, 9, 1, 1, 7, 13),
(190, 9, 1, 1, 7, 13),
(191, 9, 2, 1, 7, 13),
(192, 9, 1, 7, 29, 29),
(193, 9, 1, 7, 28, 28),
(194, 9, 3, 1, 7, 13),
(195, 9, 1, 7, 28, 27),
(196, 9, 4, 1, 7, 13),
(197, 9, 1, 7, 28, 26),
(198, 9, 1, 1, 7, 14),
(199, 9, 1, 7, 28, 25),
(200, 9, 2, 1, 7, 14),
(201, 9, 1, 7, 27, 0),
(202, 9, 3, 1, 7, 14),
(203, 9, 1, 6, 17, 24),
(204, 9, 4, 1, 7, 14),
(205, 9, 2, 6, 17, 24),
(206, 9, 1, 1, 7, 15),
(207, 9, 3, 6, 17, 24),
(208, 9, 2, 1, 7, 15),
(209, 9, 4, 6, 17, 24),
(210, 9, 1, 6, 16, 0),
(211, 9, 3, 1, 7, 15),
(212, 9, 1, 6, 15, 0),
(213, 9, 4, 1, 7, 15),
(214, 9, 1, 6, 14, 0),
(215, 9, 1, 1, 7, 16),
(216, 9, 1, 5, 4, 8),
(217, 9, 2, 1, 7, 16),
(218, 9, 3, 1, 7, 16),
(219, 9, 2, 5, 4, 8),
(220, 9, 4, 1, 7, 16),
(221, 9, 3, 5, 4, 8),
(222, 9, 4, 5, 4, 8),
(223, 9, 1, 1, 7, 17),
(224, 9, 1, 5, 4, 7),
(225, 9, 2, 1, 7, 17),
(226, 9, 1, 5, 4, 6),
(227, 9, 3, 1, 7, 17),
(228, 9, 1, 5, 4, 5),
(229, 9, 4, 1, 7, 17),
(230, 9, 1, 5, 3, 36),
(231, 9, 1, 1, 8, 18),
(232, 9, 2, 5, 3, 36),
(233, 9, 2, 1, 8, 18),
(234, 9, 2, 5, 4, 5),
(235, 9, 3, 1, 8, 18),
(236, 9, 3, 5, 4, 5),
(237, 9, 4, 1, 8, 18),
(238, 9, 3, 5, 3, 36),
(239, 9, 1, 2, 10, 0),
(240, 9, 4, 5, 4, 5),
(241, 9, 3, 2, 10, 0),
(242, 9, 4, 5, 3, 36),
(243, 9, 4, 2, 10, 0),
(244, 9, 1, 5, 3, 4),
(245, 9, 1, 2, 11, 19),
(246, 9, 2, 5, 3, 4),
(247, 9, 1, 2, 11, 20),
(248, 9, 2, 2, 11, 19),
(249, 9, 1, 2, 11, 21),
(250, 9, 2, 2, 11, 20),
(251, 9, 1, 2, 11, 22),
(252, 9, 2, 2, 11, 21),
(253, 9, 1, 5, 1, 0),
(254, 9, 2, 2, 11, 22),
(255, 9, 1, 5, 2, 1),
(256, 9, 1, 5, 3, 3),
(257, 9, 1, 5, 2, 2),
(258, 9, 2, 5, 2, 1),
(259, 9, 3, 2, 11, 19),
(260, 9, 2, 5, 2, 2),
(261, 9, 2, 5, 3, 3),
(262, 9, 3, 2, 11, 20),
(263, 9, 4, 2, 11, 19),
(264, 9, 3, 2, 11, 20),
(265, 9, 3, 2, 11, 21),
(266, 9, 4, 2, 11, 20),
(267, 9, 4, 2, 11, 21),
(268, 9, 4, 5, 3, 4),
(269, 9, 3, 2, 11, 22),
(270, 9, 3, 5, 3, 4),
(271, 9, 3, 5, 3, 4),
(272, 8, 1, 5, 2, 37),
(273, 8, 2, 5, 2, 37),
(274, 8, 3, 5, 2, 37),
(275, 8, 4, 5, 2, 37),
(276, 8, 1, 7, 28, 25),
(277, 8, 2, 7, 28, 25),
(278, 8, 3, 7, 28, 25),
(279, 8, 4, 7, 28, 25),
(280, 8, 1, 7, 28, 26),
(281, 8, 2, 7, 28, 26),
(282, 8, 3, 7, 28, 26),
(283, 8, 4, 7, 28, 26),
(284, 8, 1, 7, 28, 27),
(285, 8, 2, 7, 28, 27),
(286, 8, 3, 7, 28, 27),
(287, 8, 4, 7, 28, 27),
(288, 8, 1, 7, 28, 28),
(289, 8, 2, 7, 28, 28),
(290, 8, 3, 7, 28, 28),
(291, 8, 4, 7, 28, 28),
(292, 8, 1, 7, 29, 29),
(293, 8, 2, 7, 29, 29),
(294, 8, 3, 7, 29, 29),
(295, 8, 4, 7, 29, 29),
(296, 8, 1, 7, 29, 30),
(297, 8, 2, 7, 29, 30),
(298, 8, 3, 7, 29, 30),
(299, 8, 4, 7, 29, 30),
(304, 11, 1, 5, 1, 0),
(305, 11, 1, 5, 2, 1),
(306, 11, 2, 5, 2, 1),
(309, 11, 1, 5, 4, 5),
(310, 11, 1, 5, 4, 6),
(311, 11, 1, 5, 4, 7),
(312, 11, 1, 5, 4, 8),
(313, 12, 1, 5, 1, 0),
(314, 12, 1, 5, 2, 1),
(315, 12, 2, 5, 2, 1),
(316, 12, 1, 5, 2, 2),
(317, 12, 2, 5, 2, 2),
(318, 12, 3, 5, 2, 2),
(319, 12, 4, 5, 2, 2),
(320, 12, 1, 5, 2, 37),
(321, 12, 3, 5, 2, 37),
(322, 12, 4, 5, 2, 37),
(323, 12, 1, 5, 4, 5),
(324, 12, 2, 5, 4, 5),
(325, 12, 1, 5, 4, 8),
(326, 12, 2, 5, 4, 8),
(327, 12, 1, 5, 4, 7),
(328, 12, 1, 5, 4, 6),
(329, 13, 1, 5, 1, 0),
(330, 13, 1, 5, 2, 1),
(331, 13, 1, 5, 2, 2),
(332, 13, 1, 5, 2, 37),
(333, 13, 1, 5, 4, 5),
(334, 13, 1, 5, 4, 6),
(335, 13, 1, 5, 4, 7),
(336, 13, 1, 5, 4, 8),
(337, 11, 1, 6, 14, 0),
(340, 11, 1, 8, 23, 0),
(341, 11, 1, 9, 12, 0),
(342, 11, 1, 9, 13, 23),
(343, 12, 1, 6, 14, 0),
(346, 12, 1, 8, 23, 0),
(347, 12, 1, 9, 12, 0),
(348, 12, 1, 9, 13, 23),
(349, 13, 1, 6, 14, 0),
(350, 13, 1, 8, 23, 0),
(351, 13, 1, 9, 12, 0),
(352, 13, 1, 9, 13, 23),
(353, 14, 1, 5, 1, 0),
(354, 14, 1, 5, 2, 1),
(355, 14, 1, 5, 2, 2),
(356, 14, 1, 5, 2, 37),
(357, 14, 1, 5, 4, 5),
(358, 14, 1, 5, 4, 6),
(359, 14, 1, 5, 4, 7),
(360, 14, 1, 5, 4, 8),
(361, 14, 1, 6, 14, 0),
(366, 14, 1, 8, 23, 0),
(367, 14, 1, 9, 12, 0),
(368, 14, 1, 9, 13, 23),
(369, 15, 1, 5, 1, 0),
(370, 15, 1, 5, 3, 3),
(371, 15, 2, 5, 3, 3),
(372, 15, 1, 5, 3, 36),
(373, 15, 2, 5, 3, 36),
(374, 15, 1, 8, 23, 0),
(375, 15, 1, 9, 12, 0),
(376, 15, 1, 9, 13, 23),
(377, 16, 1, 7, 27, 0),
(378, 16, 1, 7, 29, 29),
(379, 16, 2, 7, 29, 29),
(380, 16, 1, 7, 29, 30),
(381, 16, 2, 7, 29, 30),
(382, 16, 1, 8, 18, 0),
(383, 16, 1, 8, 19, 0),
(384, 16, 1, 8, 20, 0),
(385, 16, 1, 8, 21, 0),
(386, 16, 1, 8, 22, 0),
(387, 16, 1, 8, 24, 0),
(388, 16, 1, 8, 25, 0),
(389, 16, 1, 9, 12, 0),
(390, 16, 1, 9, 13, 23),
(391, 17, 1, 5, 1, 0),
(392, 17, 1, 5, 3, 4),
(393, 17, 2, 5, 3, 4),
(394, 17, 3, 5, 3, 4),
(395, 17, 4, 5, 3, 4),
(396, 17, 1, 8, 21, 0),
(397, 17, 1, 8, 18, 0),
(398, 17, 1, 8, 19, 0),
(399, 17, 1, 8, 20, 0),
(400, 17, 1, 8, 22, 0),
(401, 17, 1, 8, 24, 0),
(402, 17, 1, 8, 25, 0),
(403, 17, 1, 9, 12, 0),
(404, 17, 1, 9, 13, 23),
(407, 18, 1, 1, 5, 0),
(409, 18, 1, 1, 6, 10),
(410, 18, 2, 1, 6, 10),
(411, 18, 1, 1, 7, 15),
(412, 18, 2, 1, 7, 15),
(413, 18, 1, 2, 11, 20),
(414, 18, 1, 8, 23, 0),
(416, 18, 2, 2, 11, 20),
(417, 19, 1, 1, 5, 0),
(418, 19, 1, 1, 6, 9),
(419, 19, 1, 1, 6, 11),
(421, 19, 1, 1, 7, 13),
(422, 19, 1, 1, 7, 16),
(423, 19, 2, 1, 7, 16),
(424, 19, 1, 2, 10, 0),
(425, 19, 1, 2, 11, 19),
(426, 19, 1, 2, 11, 21),
(427, 19, 2, 2, 11, 21),
(428, 19, 1, 7, 27, 0),
(429, 19, 1, 7, 28, 25),
(430, 19, 1, 7, 28, 26),
(431, 19, 2, 7, 28, 26),
(432, 19, 1, 7, 28, 27),
(433, 19, 2, 7, 28, 27),
(434, 19, 2, 7, 28, 25),
(435, 19, 1, 8, 20, 0),
(436, 19, 1, 8, 21, 0),
(437, 19, 1, 8, 22, 0),
(438, 19, 1, 9, 13, 23),
(439, 19, 1, 9, 12, 0),
(441, 20, 1, 1, 5, 0),
(442, 20, 1, 1, 6, 9),
(443, 20, 1, 1, 6, 12),
(444, 20, 3, 1, 6, 12),
(445, 20, 4, 1, 6, 12),
(446, 20, 1, 1, 7, 13),
(447, 20, 1, 1, 7, 17),
(448, 20, 3, 1, 7, 17),
(449, 20, 4, 1, 7, 17),
(450, 20, 1, 1, 8, 18),
(451, 20, 2, 1, 8, 18),
(452, 20, 1, 2, 10, 0),
(453, 20, 1, 2, 11, 19),
(454, 20, 1, 2, 11, 22),
(455, 20, 3, 2, 11, 22),
(456, 20, 4, 2, 11, 22),
(457, 20, 1, 7, 27, 0),
(458, 20, 1, 7, 28, 25),
(459, 20, 2, 7, 28, 25),
(460, 20, 1, 7, 28, 26),
(461, 20, 2, 7, 28, 26),
(462, 20, 1, 7, 28, 27),
(463, 20, 2, 7, 28, 27),
(464, 20, 1, 8, 20, 0),
(465, 20, 1, 8, 21, 0),
(466, 20, 1, 8, 22, 0),
(467, 20, 1, 9, 13, 23),
(468, 20, 1, 9, 12, 0),
(469, 21, 1, 1, 5, 0),
(470, 21, 1, 1, 6, 9),
(471, 21, 1, 1, 6, 10),
(472, 21, 1, 1, 6, 11),
(473, 21, 1, 1, 6, 12),
(474, 21, 1, 1, 7, 13),
(475, 21, 1, 1, 7, 14),
(476, 21, 1, 1, 7, 15),
(477, 21, 1, 1, 7, 16),
(478, 21, 1, 1, 7, 17),
(479, 21, 1, 1, 8, 18),
(480, 21, 1, 2, 10, 0),
(481, 21, 1, 2, 11, 19),
(482, 21, 1, 2, 11, 20),
(483, 21, 1, 2, 11, 21),
(484, 21, 1, 2, 11, 22),
(485, 21, 1, 5, 1, 0),
(486, 21, 1, 5, 2, 1),
(487, 21, 1, 5, 2, 2),
(488, 21, 1, 5, 2, 37),
(489, 21, 1, 5, 3, 3),
(490, 21, 1, 5, 3, 4),
(491, 21, 1, 5, 3, 36),
(492, 21, 1, 5, 4, 5),
(493, 21, 1, 5, 4, 6),
(494, 21, 1, 5, 4, 7),
(495, 21, 1, 5, 4, 8),
(496, 21, 1, 6, 14, 0),
(497, 21, 1, 6, 15, 0),
(498, 21, 1, 6, 16, 0),
(499, 21, 1, 6, 17, 24),
(500, 21, 1, 7, 27, 0),
(501, 21, 1, 7, 28, 25),
(502, 21, 1, 7, 28, 26),
(503, 21, 1, 7, 28, 27),
(504, 21, 1, 7, 28, 28),
(505, 21, 1, 7, 29, 29),
(506, 21, 1, 7, 29, 30),
(507, 21, 1, 7, 30, 31),
(508, 21, 1, 7, 30, 32),
(509, 21, 1, 7, 31, 33),
(510, 21, 1, 7, 31, 34),
(511, 21, 1, 7, 31, 35),
(512, 21, 1, 8, 18, 0),
(513, 21, 1, 8, 19, 0),
(514, 21, 1, 8, 20, 0),
(515, 21, 1, 8, 21, 0),
(516, 21, 1, 8, 22, 0),
(517, 21, 1, 8, 23, 0),
(518, 21, 1, 8, 24, 0),
(519, 21, 1, 8, 25, 0),
(520, 21, 1, 9, 12, 0),
(521, 21, 1, 9, 13, 23),
(523, 22, 1, 5, 1, 0),
(524, 22, 1, 5, 2, 1),
(525, 22, 1, 8, 23, 0),
(526, 22, 1, 9, 13, 23),
(527, 22, 1, 9, 12, 0),
(528, 22, 1, 6, 14, 0),
(529, 11, 3, 5, 2, 1),
(530, 20, 1, 1, 6, 11),
(531, 20, 3, 1, 6, 11),
(532, 20, 4, 1, 6, 11),
(533, 20, 3, 9, 12, 0),
(534, 20, 4, 9, 12, 0),
(535, 20, 3, 9, 13, 23),
(536, 20, 4, 9, 13, 23),
(537, 20, 1, 5, 2, 1),
(538, 19, 3, 1, 6, 11),
(539, 19, 4, 1, 6, 11),
(540, 19, 2, 1, 6, 11),
(541, 8, 1, 9, 32, 0),
(542, 8, 1, 9, 33, 0),
(543, 8, 3, 9, 32, 0),
(544, 8, 3, 9, 33, 0),
(545, 8, 4, 9, 33, 0),
(546, 8, 4, 9, 32, 0),
(547, 20, 1, 9, 32, 0),
(548, 20, 3, 9, 32, 0),
(549, 20, 4, 9, 32, 0),
(550, 20, 1, 9, 33, 0),
(551, 20, 3, 9, 33, 0),
(552, 20, 4, 9, 33, 0),
(554, 20, 1, 5, 2, 38),
(555, 16, 1, 5, 2, 1),
(556, 16, 1, 5, 2, 38),
(562, 16, 1, 5, 1, 0),
(563, 16, 1, 5, 2, 2),
(564, 9, 1, 9, 32, 0),
(565, 9, 1, 9, 33, 0),
(566, 9, 3, 9, 32, 0),
(567, 9, 3, 9, 33, 0),
(568, 9, 4, 9, 32, 0),
(569, 9, 4, 9, 33, 0),
(570, 9, 1, 9, 12, 39),
(571, 9, 2, 9, 12, 39),
(572, 9, 3, 9, 12, 39),
(573, 9, 1, 5, 2, 38),
(574, 9, 1, 5, 2, 37),
(575, 9, 2, 5, 2, 37),
(576, 9, 2, 5, 2, 38),
(577, 9, 3, 5, 2, 37),
(578, 9, 3, 5, 2, 38),
(579, 9, 4, 5, 2, 38),
(580, 20, 1, 9, 12, 39),
(584, 20, 2, 5, 2, 38),
(585, 20, 3, 5, 2, 38),
(586, 20, 4, 5, 2, 38),
(587, 20, 2, 9, 13, 23),
(588, 11, 1, 9, 12, 39),
(589, 11, 2, 9, 12, 39),
(590, 11, 4, 9, 12, 39),
(591, 12, 1, 9, 32, 0),
(592, 12, 3, 9, 32, 0),
(593, 12, 4, 9, 32, 0),
(596, 20, 2, 9, 12, 39),
(597, 19, 1, 9, 12, 39),
(598, 20, 1, 8, 23, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_roles_modules_sub_module`
--

DROP TABLE IF EXISTS `user_roles_modules_sub_module`;
CREATE TABLE `user_roles_modules_sub_module` (
  `id` int(255) NOT NULL,
  `id_user` int(255) NOT NULL,
  `id_role` int(255) NOT NULL,
  `id_system_module` int(255) NOT NULL,
  `id_system_sub_module` int(255) NOT NULL,
  `id_system_sub_sub_module` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `user_roles_modules_sub_module`
--

TRUNCATE TABLE `user_roles_modules_sub_module`;
--
-- Dumping data for table `user_roles_modules_sub_module`
--

INSERT INTO `user_roles_modules_sub_module` (`id`, `id_user`, `id_role`, `id_system_module`, `id_system_sub_module`, `id_system_sub_sub_module`) VALUES
(4, 2, 1, 1, 6, 10),
(5, 2, 1, 1, 7, 15),
(6, 2, 1, 9, 13, 23),
(7, 2, 1, 1, 6, 9),
(8, 2, 1, 7, 31, 35),
(9, 2, 1, 8, 18, 0),
(10, 2, 1, 5, 1, 0),
(11, 2, 1, 6, 14, 0),
(12, 3, 1, 1, 5, 0),
(13, 3, 1, 1, 6, 9),
(14, 3, 1, 1, 6, 10),
(15, 3, 1, 1, 6, 11),
(16, 3, 1, 1, 6, 12),
(17, 3, 1, 1, 7, 13),
(18, 3, 1, 1, 7, 14),
(19, 3, 1, 9, 12, 0),
(20, 3, 1, 7, 27, 0),
(21, 3, 1, 1, 7, 15),
(22, 3, 1, 1, 7, 16),
(23, 3, 1, 1, 7, 17),
(24, 3, 1, 1, 8, 18),
(25, 3, 1, 2, 10, 0),
(26, 3, 1, 2, 11, 19),
(27, 3, 1, 2, 11, 20),
(28, 3, 1, 2, 11, 21),
(29, 3, 1, 2, 11, 22),
(30, 3, 1, 5, 1, 0),
(31, 3, 1, 5, 2, 1),
(32, 3, 1, 5, 2, 2),
(33, 3, 1, 6, 14, 0),
(34, 3, 1, 8, 18, 0),
(35, 3, 1, 5, 3, 3),
(36, 3, 1, 5, 3, 4),
(37, 3, 1, 5, 4, 5),
(38, 3, 1, 5, 4, 6),
(39, 3, 1, 5, 4, 7),
(40, 3, 1, 5, 4, 8),
(41, 3, 1, 6, 15, 0),
(42, 3, 1, 6, 16, 0),
(43, 3, 1, 6, 17, 24),
(44, 3, 1, 7, 28, 25),
(45, 3, 1, 7, 28, 26),
(46, 3, 1, 7, 28, 27),
(47, 3, 1, 7, 28, 28),
(48, 3, 1, 7, 29, 29),
(49, 3, 1, 7, 29, 30),
(50, 3, 1, 7, 30, 31),
(51, 3, 1, 7, 30, 32),
(52, 3, 1, 7, 31, 33),
(53, 3, 1, 7, 31, 34),
(54, 3, 1, 7, 31, 35),
(55, 3, 1, 8, 19, 0),
(56, 3, 1, 8, 20, 0),
(57, 3, 1, 8, 21, 0),
(58, 3, 1, 8, 22, 0),
(59, 3, 1, 8, 23, 0),
(60, 3, 1, 8, 24, 0),
(61, 3, 1, 8, 25, 0),
(62, 3, 1, 9, 13, 23),
(63, 2, 1, 7, 31, 33),
(64, 3, 2, 1, 8, 18),
(65, 3, 3, 1, 8, 18),
(66, 3, 4, 1, 8, 18),
(67, 3, 2, 9, 13, 23),
(68, 3, 3, 9, 13, 23),
(69, 3, 4, 9, 13, 23),
(70, 3, 2, 1, 6, 9),
(71, 3, 3, 1, 6, 9),
(72, 3, 2, 1, 6, 10),
(73, 3, 3, 1, 6, 10),
(74, 3, 4, 1, 6, 10),
(75, 3, 4, 1, 6, 9),
(76, 3, 2, 1, 6, 11),
(77, 3, 3, 1, 6, 11),
(78, 3, 4, 1, 6, 11),
(79, 3, 2, 1, 6, 12),
(80, 3, 3, 1, 6, 12),
(81, 3, 4, 1, 6, 12),
(82, 3, 2, 1, 7, 13),
(83, 3, 3, 1, 7, 13),
(84, 3, 4, 1, 7, 13),
(85, 3, 2, 1, 7, 14),
(86, 3, 3, 1, 7, 14),
(87, 3, 4, 1, 7, 14),
(88, 3, 2, 1, 7, 15),
(89, 3, 3, 1, 7, 15),
(90, 3, 4, 1, 7, 15),
(91, 3, 2, 1, 7, 16),
(92, 3, 2, 1, 7, 17),
(93, 3, 3, 1, 7, 16),
(94, 3, 4, 1, 7, 16),
(95, 3, 3, 1, 7, 17),
(96, 3, 4, 1, 7, 17),
(97, 3, 2, 2, 11, 19),
(98, 3, 3, 2, 11, 19),
(99, 3, 4, 2, 11, 19),
(100, 3, 2, 2, 11, 20),
(101, 3, 3, 2, 11, 20),
(102, 3, 4, 2, 11, 20),
(103, 3, 2, 2, 11, 21),
(104, 3, 3, 2, 11, 21),
(105, 3, 4, 2, 11, 21),
(106, 3, 2, 2, 11, 22),
(107, 3, 3, 2, 11, 22),
(108, 3, 4, 2, 11, 22),
(109, 3, 2, 5, 2, 1),
(110, 3, 3, 5, 2, 1),
(111, 3, 4, 5, 2, 1),
(112, 3, 2, 5, 2, 2),
(113, 3, 3, 5, 2, 2),
(114, 3, 4, 5, 2, 2),
(115, 3, 2, 5, 3, 3),
(116, 3, 1, 5, 3, 36),
(117, 3, 3, 5, 1, 0),
(118, 3, 3, 2, 10, 0),
(119, 3, 3, 1, 5, 0),
(120, 3, 4, 1, 5, 0),
(121, 3, 4, 2, 10, 0),
(122, 3, 4, 5, 1, 0),
(123, 3, 3, 5, 3, 3),
(124, 3, 4, 5, 3, 3),
(125, 3, 2, 5, 3, 4),
(126, 3, 3, 5, 3, 4),
(127, 3, 4, 5, 3, 4),
(128, 3, 2, 5, 3, 36),
(129, 3, 3, 5, 3, 36),
(130, 3, 4, 5, 3, 36),
(131, 3, 2, 5, 4, 5),
(132, 3, 3, 5, 4, 5),
(133, 3, 4, 5, 4, 5),
(134, 3, 3, 6, 17, 24),
(135, 2, 1, 5, 3, 3),
(136, 2, 1, 5, 3, 4),
(137, 2, 2, 5, 3, 3),
(138, 2, 2, 5, 3, 4),
(139, 2, 3, 5, 3, 3),
(140, 2, 3, 5, 3, 4),
(141, 2, 4, 5, 3, 3),
(142, 2, 4, 5, 3, 4),
(143, 2, 1, 5, 2, 1),
(144, 2, 2, 5, 2, 1),
(145, 2, 1, 5, 2, 2),
(146, 2, 2, 5, 2, 2),
(147, 2, 3, 5, 2, 2),
(148, 2, 4, 5, 2, 2),
(149, 2, 3, 5, 2, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `application_info`
--
ALTER TABLE `application_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_migration`
--
ALTER TABLE `app_migration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `assets`
--
ALTER TABLE `assets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `asset_category`
--
ALTER TABLE `asset_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banks`
--
ALTER TABLE `banks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banks_available`
--
ALTER TABLE `banks_available`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `business_types`
--
ALTER TABLE `business_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients_update`
--
ALTER TABLE `clients_update`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `client_products`
--
ALTER TABLE `client_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `client_relation_officer`
--
ALTER TABLE `client_relation_officer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `company_bank_savings_transaction`
--
ALTER TABLE `company_bank_savings_transaction`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `country_codes`
--
ALTER TABLE `country_codes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fund_manager_account`
--
ALTER TABLE `fund_manager_account`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fund_manager_daily_interest_transactions`
--
ALTER TABLE `fund_manager_daily_interest_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fund_manager_orders`
--
ALTER TABLE `fund_manager_orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fund_manager_transactions`
--
ALTER TABLE `fund_manager_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `id_card_types`
--
ALTER TABLE `id_card_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `instrument_codes`
--
ALTER TABLE `instrument_codes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `investement_management_denominator`
--
ALTER TABLE `investement_management_denominator`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `investment_assets_recapitilisation_trail`
--
ALTER TABLE `investment_assets_recapitilisation_trail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `investment_client_portfolio`
--
ALTER TABLE `investment_client_portfolio`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `investment_liability_daily_interest_transactions`
--
ALTER TABLE `investment_liability_daily_interest_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `investment_management_accounts`
--
ALTER TABLE `investment_management_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `investment_management_orders`
--
ALTER TABLE `investment_management_orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `investment_management_placement`
--
ALTER TABLE `investment_management_placement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `investment_management_transactions`
--
ALTER TABLE `investment_management_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `investment_management_types`
--
ALTER TABLE `investment_management_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `investment_placement_daily_interest_transactions`
--
ALTER TABLE `investment_placement_daily_interest_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `investment_placement_details`
--
ALTER TABLE `investment_placement_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `investment_placement_orders`
--
ALTER TABLE `investment_placement_orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `investment_placement_transactions`
--
ALTER TABLE `investment_placement_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ledgers`
--
ALTER TABLE `ledgers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ledger_category`
--
ALTER TABLE `ledger_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ledger_entries`
--
ALTER TABLE `ledger_entries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ledger_report`
--
ALTER TABLE `ledger_report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ledger_subcategory`
--
ALTER TABLE `ledger_subcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `liquidate_fund`
--
ALTER TABLE `liquidate_fund`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `liquidate_investment`
--
ALTER TABLE `liquidate_investment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `message_types`
--
ALTER TABLE `message_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `modules_sub_modules`
--
ALTER TABLE `modules_sub_modules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `partial_redemption_fund`
--
ALTER TABLE `partial_redemption_fund`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `partial_redemption_investment`
--
ALTER TABLE `partial_redemption_investment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pf_accounts`
--
ALTER TABLE `pf_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `placement_companies`
--
ALTER TABLE `placement_companies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `provident_funds`
--
ALTER TABLE `provident_funds`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `provident_funds_history`
--
ALTER TABLE `provident_funds_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `provident_fund_transaction`
--
ALTER TABLE `provident_fund_transaction`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `relation_officers`
--
ALTER TABLE `relation_officers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `savings_accounts`
--
ALTER TABLE `savings_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `savings_accounts_transactions`
--
ALTER TABLE `savings_accounts_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `savings_accounts_transactions_denied`
--
ALTER TABLE `savings_accounts_transactions_denied`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `savings_products`
--
ALTER TABLE `savings_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `savings_product_accounts`
--
ALTER TABLE `savings_product_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `savings_product_transactions`
--
ALTER TABLE `savings_product_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `savings_transaction_type`
--
ALTER TABLE `savings_transaction_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_logs`
--
ALTER TABLE `system_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_modules`
--
ALTER TABLE `system_modules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_sub_modules`
--
ALTER TABLE `system_sub_modules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_sub_sub_module`
--
ALTER TABLE `system_sub_sub_module`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `titles`
--
ALTER TABLE `titles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `top_up_fund`
--
ALTER TABLE `top_up_fund`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `top_up_investment`
--
ALTER TABLE `top_up_investment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaction_types`
--
ALTER TABLE `transaction_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_groups`
--
ALTER TABLE `user_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_groups_roles_modules_sub_module`
--
ALTER TABLE `user_groups_roles_modules_sub_module`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_group_roles_modules_sub_module`
--
ALTER TABLE `user_group_roles_modules_sub_module`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_roles_modules_sub_module`
--
ALTER TABLE `user_roles_modules_sub_module`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `application_info`
--
ALTER TABLE `application_info`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `app_migration`
--
ALTER TABLE `app_migration`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `assets`
--
ALTER TABLE `assets`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `asset_category`
--
ALTER TABLE `asset_category`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `banks`
--
ALTER TABLE `banks`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `banks_available`
--
ALTER TABLE `banks_available`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `branches`
--
ALTER TABLE `branches`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `business_types`
--
ALTER TABLE `business_types`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;
--
-- AUTO_INCREMENT for table `clients_update`
--
ALTER TABLE `clients_update`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `client_products`
--
ALTER TABLE `client_products`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;
--
-- AUTO_INCREMENT for table `client_relation_officer`
--
ALTER TABLE `client_relation_officer`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;
--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `company_bank_savings_transaction`
--
ALTER TABLE `company_bank_savings_transaction`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=251;
--
-- AUTO_INCREMENT for table `country_codes`
--
ALTER TABLE `country_codes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=240;
--
-- AUTO_INCREMENT for table `fund_manager_account`
--
ALTER TABLE `fund_manager_account`
  MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `fund_manager_daily_interest_transactions`
--
ALTER TABLE `fund_manager_daily_interest_transactions`
  MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=183;
--
-- AUTO_INCREMENT for table `fund_manager_orders`
--
ALTER TABLE `fund_manager_orders`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `fund_manager_transactions`
--
ALTER TABLE `fund_manager_transactions`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `id_card_types`
--
ALTER TABLE `id_card_types`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `instrument_codes`
--
ALTER TABLE `instrument_codes`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `investement_management_denominator`
--
ALTER TABLE `investement_management_denominator`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `investment_assets_recapitilisation_trail`
--
ALTER TABLE `investment_assets_recapitilisation_trail`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `investment_client_portfolio`
--
ALTER TABLE `investment_client_portfolio`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `investment_liability_daily_interest_transactions`
--
ALTER TABLE `investment_liability_daily_interest_transactions`
  MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=231;
--
-- AUTO_INCREMENT for table `investment_management_accounts`
--
ALTER TABLE `investment_management_accounts`
  MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `investment_management_orders`
--
ALTER TABLE `investment_management_orders`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `investment_management_placement`
--
ALTER TABLE `investment_management_placement`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `investment_management_transactions`
--
ALTER TABLE `investment_management_transactions`
  MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `investment_management_types`
--
ALTER TABLE `investment_management_types`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `investment_placement_daily_interest_transactions`
--
ALTER TABLE `investment_placement_daily_interest_transactions`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `investment_placement_details`
--
ALTER TABLE `investment_placement_details`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `investment_placement_orders`
--
ALTER TABLE `investment_placement_orders`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `investment_placement_transactions`
--
ALTER TABLE `investment_placement_transactions`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ledgers`
--
ALTER TABLE `ledgers`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=186;
--
-- AUTO_INCREMENT for table `ledger_category`
--
ALTER TABLE `ledger_category`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ledger_entries`
--
ALTER TABLE `ledger_entries`
  MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=490;
--
-- AUTO_INCREMENT for table `ledger_report`
--
ALTER TABLE `ledger_report`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ledger_subcategory`
--
ALTER TABLE `ledger_subcategory`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `liquidate_fund`
--
ALTER TABLE `liquidate_fund`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `liquidate_investment`
--
ALTER TABLE `liquidate_investment`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `message_types`
--
ALTER TABLE `message_types`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `modules_sub_modules`
--
ALTER TABLE `modules_sub_modules`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `partial_redemption_fund`
--
ALTER TABLE `partial_redemption_fund`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `partial_redemption_investment`
--
ALTER TABLE `partial_redemption_investment`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pf_accounts`
--
ALTER TABLE `pf_accounts`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `placement_companies`
--
ALTER TABLE `placement_companies`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `provident_funds`
--
ALTER TABLE `provident_funds`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `provident_funds_history`
--
ALTER TABLE `provident_funds_history`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `provident_fund_transaction`
--
ALTER TABLE `provident_fund_transaction`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `relation_officers`
--
ALTER TABLE `relation_officers`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `savings_accounts`
--
ALTER TABLE `savings_accounts`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `savings_accounts_transactions`
--
ALTER TABLE `savings_accounts_transactions`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `savings_accounts_transactions_denied`
--
ALTER TABLE `savings_accounts_transactions_denied`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `savings_products`
--
ALTER TABLE `savings_products`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `savings_product_accounts`
--
ALTER TABLE `savings_product_accounts`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `savings_product_transactions`
--
ALTER TABLE `savings_product_transactions`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `savings_transaction_type`
--
ALTER TABLE `savings_transaction_type`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `system_logs`
--
ALTER TABLE `system_logs`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;
--
-- AUTO_INCREMENT for table `system_modules`
--
ALTER TABLE `system_modules`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `system_sub_modules`
--
ALTER TABLE `system_sub_modules`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `system_sub_sub_module`
--
ALTER TABLE `system_sub_sub_module`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
--
-- AUTO_INCREMENT for table `titles`
--
ALTER TABLE `titles`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `top_up_fund`
--
ALTER TABLE `top_up_fund`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `top_up_investment`
--
ALTER TABLE `top_up_investment`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `transaction_types`
--
ALTER TABLE `transaction_types`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `user_groups`
--
ALTER TABLE `user_groups`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `user_groups_roles_modules_sub_module`
--
ALTER TABLE `user_groups_roles_modules_sub_module`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user_group_roles_modules_sub_module`
--
ALTER TABLE `user_group_roles_modules_sub_module`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=599;
--
-- AUTO_INCREMENT for table `user_roles_modules_sub_module`
--
ALTER TABLE `user_roles_modules_sub_module`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=150;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
