<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>GiGSHiP</title>
	<link rel="stylesheet" href="<?php echo $assets ?>styles/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo $assets ?>styles/dgicon.css">
	<link rel="stylesheet" href="<?php echo $assets ?>styles/style.css">
</head>
<body>
	<!--Mian header-->
	<?php include "header.php" ?>
	<!--End Main Header-->
	<!--Main navigation -->
	<nav class="main-nav clearfix">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<ul class="nav-ul">
						<li class="nav-li"><a href="" class="nav-link main-nav-link">Home</a></li>
						<li class="nav-li"><a href="" class="nav-link main-nav-link">All Gigs</a></li>
						<li class="nav-li"><a href="" class="nav-link main-nav-link">All Request</a></li>
						<li class="nav-li"><a href="" class="nav-link main-nav-link">All Categories</a></li>
						<li class="nav-li"><a href="" class="nav-link main-nav-link">All Locations</a></li>
					</ul>
				</div>
			</div>
		</div>
	</nav>
	<!--End Main navigation-->
	
	
	<!-- Main Section -->
	<div class="login-wraper">
		<div id="flip" class="form-wraper">
			<div class="flip-over front">
				<form action="" class="login-form registerForm" id="registerForm">
					<div class="info-box">
						<span class="icon">
							<span class="dgicon dgicon-question-circle"></span>
						</span>
						<div class="text">
							<h3>Fill to sign up for Gigship.</h3>
						</div>						
					</div>
					<div class="ajax-message">
					
					</div>
					<p class="input-wraper">
						<label for="fname">First Name</label><br>
						<input type="text" name="fname" class="text-input fname" id="fname">
					</p>
					<p class="input-wraper">
						<label for="lname">Last Name</label><br>
						<input type="text" name="lname" class="text-input lname" id="lname">
					</p>
					<p class="input-wraper">
						<label for="email">Email</label><br>
						<input type="text" name="email" class="text-input email" id="email">
					</p>
					<p class="input-wraper">
						<label for="username">Username</label><br>
						<input type="text" name="username" class="text-input username" id="username">
					</p>
					<p class="input-wraper">
						<label for="password">Password</label><br>
						<input type="password" name="password" class="text-input password" id="password">
					</p>
					<p class="input-wraper">
						<label for="password1">Password Confirm</label><br>
						<input type="password" name="password_confirm" class="text-input password" id="password1">
					</p>
					<p class="input-wraper">
						<button type="submit" value="LOGIN" class="btn btn-primary" id="login-btn">SIGNUP</button>
					</p>
					<p class="form-action">
						<a href="<?php echo base_url().'login' ?>" class="tex-right action-rec">I have an account.</a>
					</p>

				</form>
			</div>
		</div>
	</div>
	<!-- End Main Section -->

	<!--footer content -->
	<footer class="footer-wraper">
		<div class="container">
			<div class="row">
				<!--footer here -->
			</div>
		</div>
	</footer>
	<?php include  "footer.php" ?>
</body>
</html>