<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>GiGSHiP</title>
	<link rel="stylesheet" href="<?php echo $assets ?>styles/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo $assets ?>styles/dgicon.css">
	<link rel="stylesheet" href="<?php echo $assets ?>styles/style.css">
</head>
<body>
	<!--Mian header-->
	<?php include "header.php" ?>
	<!--End Main Header-->
	<!--Main navigation -->
	<nav class="main-nav clearfix">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<ul class="nav-ul">
						<li class="nav-li"><a href="" class="nav-link main-nav-link">Home</a></li>
						<li class="nav-li"><a href="" class="nav-link main-nav-link">All Gigs</a></li>
						<li class="nav-li"><a href="" class="nav-link main-nav-link">All Request</a></li>
						<li class="nav-li"><a href="" class="nav-link main-nav-link">All Categories</a></li>
						<li class="nav-li"><a href="" class="nav-link main-nav-link">All Locations</a></li>
					</ul>
				</div>
			</div>
		</div>
	</nav>
	<!--End Main navigation-->
	
	
	<!-- Main Section -->
	<div class="login-wraper">
		<div id="flip" class="form-wraper">
			<div class="flip-over front">
			<?php 
			file_get_contents(base_url()."logout");
			if($this->input->get('c')):

			$res = $this->db->get_where('users',array("password_recovery_code"=>$this->input->get('c')))->row();
			 if($res){
			 ?>
				<form action="" class="login-form resetForm" id="resetForm">
					<div class="info-box">
						<span class="icon">
							<span class="dgicon dgicon-question-circle"></span>
						</span>
						<div class="text">
							<h3> Resest Lost password.</h3>
						</div>						
					</div>
					<div class="ajax-message"></div>
					<p class="input-wraper">
						<label for="password">New Password Password</label><br>
						<input type="password" name="password" class="text-input password" id="password">
					</p>
					<p class="input-wraper">
						<label for="password1">Password Confirm</label><br>
						<input type="password" name="password1" class="text-input password" id="password1">
					</p>
					<p class="input-wraper">
						<button type="submit" class="btn btn-primary" id="login-btn">RESET</button>
					</p>
					<p class="form-action">
						<a href="login.html" class="tex-right action-rec">I have an account.</a>
					</p>

				</form>
				<?php } else{
				
				} else: endif; ?>
			</div>
		</div>
	</div>
	<!-- End Main Section -->

	<!--footer content -->
	<footer class="footer-wraper">
		<div class="container">
			<div class="row">
				<!--footer here -->
			</div>
		</div>
	</footer>
	<?php include  "footer.php" ?>
</body>
</html>