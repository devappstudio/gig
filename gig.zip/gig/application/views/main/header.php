	<link rel="stylesheet" href="<?php echo $assets ?>css/font-awesome.css">

	<header class="main-header clearfix">
		<div class="container">
			<div class="row">
				<div class="col-md-2">
					<a href="<?php echo base_url() ?>" class="link logo-link">
						<img src="<?php echo $assets ?>images/logo.png" alt="GiGSHiP">
					</a>
				</div>
				<div class="col-md-4 text-center">
					<!--Seacrh Form (using q for query  field name)-->
					<div class="top-search-wraper">
						<form action="" class="top-search-form text-left">
							<input type="hidden" name="source" value="top-bar">
							<input type="text" name="q" class="input search-input inline" placeholder="Search for Gigs here">
							<input type="submit" value="" hidden="" id="top-submit">
							<label for="top-submit" class="search-label">&raquo;</label>
						</form>
					</div>
					<!--End Search form-->
				</div>
				<div class="col-md-6 text-right">
					<nav class="header-nav">
						<ul class="nav-ul">
							<li class="nav-li"><a href="<?php echo base_url() ?>" class="nav-link">Home</a></li>
							<li class="nav-li"><a href="<?php echo base_url().'blog' ?>" class="nav-link">Blog</a></li>
							<!-- Changes to user name and profile/acount link if logged in or redirect to login or create account-->
							<?php if(is_array($user)): ?>
							<li class="nav-li"><a href="<?php echo base_url().'register' ?>" class="nav-link">Signup</a></li>
							<!--Changes to logout if user is logged in *will submit logo later-->
							<li class="nav-li"><a href="<?php echo base_url().'login' ?>" class="nav-link">Sign in</a></li>
							<?php endif; ?>
							<li class="nav-li"><a href="<?php echo base_url().'new_gig' ?>" class="nav-link btn btn-small btn-primary">Sell A Gig</a></li>
						</ul>
					</nav>
				</div>
			</div>
		</div>
	</header>
