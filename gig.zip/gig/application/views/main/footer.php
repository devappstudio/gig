
<script src="<?php echo $assets; ?>js/jQuery-2.1.3.min.js" type="text/javascript"></script>
<script src="<?php echo $assets; ?>js/bootstrapValidator.js" type="text/javascript"></script>
<script src="<?php echo $assets; ?>js/jquery.validate.min.js" type="text/javascript"></script>
<script src="<?php echo $assets; ?>js/form_process.js" type="text/javascript"></script>
<script src="<?php echo $assets; ?>js/jquery-form.js" type="text/javascript"></script>
<script>
//recoverForm
        $(".recoverForm").submit(function(e)
            {
                e.preventDefault();
                            window.scroll(0,0);
                            var options = {
                                target: '.ajax-message',
                                type: "post",
                                url: "<?php echo base_url();?>index.php/site/recover_user",
                                dataType: "json",
                                cache: false,
                                data: $('#recoverForm').serialize(),
                                beforeSend: function () {
                                    $('.ajax-message').html('<div class="alert alert-success"> <i class="fa fa-spinner fa-spin"></i> <span>Please wait while we process request!</span></div>');
                                },
                                success: function (data) {
                                    $('.ajax-message').empty();
                                    if (data.status == 'success') {
                                        $(".ajax-message").html('');
                                        $(".ajax-message").html('<div class="alert alert-success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Thank you, please follow the instructions in the recovery email in the email in your account</p></div>').show().addClass('ajax_success');
                                        console.log(data);
                                        //location.reload();
                                        window.location = "<?php echo base_url() ?>"
                                       // $(".ajax-message").html('');
                                       $(".loginForm").hide();
                                    } else if (data.status == 'error') {
                                        console.log(data);
                                        $(".ajax-message").html('<br/><div class=" alert alert-error "><p>' + data.error + "</p></div><br/>");
                                    }
                                },
                                error: function () {
                                    $(".ajax-message").html('<div class="alert alert-danger"><p><i class="fa fa-exclamation-circle"></i> Session expired,please make sure you have a network connection and try again</p></div>');
                                }

                            };

                            e.preventDefault();
                            $('.recoverForm').ajaxSubmit(options);
            }
        );


        $(".loginForm").submit(function(e)
            {
                e.preventDefault();
                            window.scroll(0,0);
                            var options = {
                                target: '.ajax-message',
                                type: "post",
                                url: "<?php echo base_url();?>index.php/site/login_user",
                                dataType: "json",
                                cache: false,
                                data: $('#loginForm').serialize(),
                                beforeSend: function () {
                                    $('.ajax-message').html('<div class="alert alert-success"> <i class="fa fa-spinner fa-spin"></i> <span>Please wait while we process request!</span></div>');
                                },
                                success: function (data) {
                                    $('.ajax-message').empty();
                                    if (data.status == 'success') {
                                        $(".ajax-message").html('');
                                        $(".ajax-message").html('<div class="alert alert-success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Thank you, redirecting ... please be patient </p></div>').show().addClass('ajax_success');
                                        console.log(data);
                                        //location.reload();
                                        window.location = "<?php echo base_url() ?>"
                                       // $(".ajax-message").html('');
                                       $(".loginForm").hide();
                                    } else if (data.status == 'error') {
                                        console.log(data);
                                        $(".ajax-message").html('<br/><div class=" alert alert-error "><p>' + data.error + "</p></div><br/>");
                                    }
                                },
                                error: function () {
                                    $(".ajax-message").html('<div class="alert alert-danger"><p><i class="fa fa-exclamation-circle"></i> Session expired,please make sure you have a network connection and try again</p></div>');
                                }

                            };

                            e.preventDefault();
                            $('.loginForm').ajaxSubmit(options);
            }
        );

        $(".registerForm").submit(function(e)
            {
                e.preventDefault();
                            window.scroll(0,0);
                            var options = {
                                target: '.ajax-message',
                                type: "post",
                                url: "<?php echo base_url();?>index.php/site/register_user",
                                dataType: "json",
                                cache: false,
                                data: $('#registerForm').serialize(),
                                beforeSend: function () {
                                    $('.ajax-message').html('<div class="alert alert-success"> <i class="fa fa-spinner fa-spin"></i> <span>Please wait while we process request!</span></div>');
                                },
                                success: function (data) {
                                    $('.ajax-message').empty();
                                    if (data.status == 'success') {
                                        $(".ajax-message").html('');
                                        $(".ajax-message").html('<div class="alert alert-success"><p><i class="fa fa-check-circle"></i>&nbsp;&nbsp;Thank you, please follow the link sent to your email to activate your account.</p></div>').show().addClass('ajax_success');
                                        console.log(data);
                                        //location.reload();
                                       // $(".ajax-message").html('');
                                       $(".input-wraper").hide();
                                       $(".form-action").hide();
                                       $(".info-box").hide();
                                    } else if (data.status == 'error') {
                                        console.log(data);
                                        $(".ajax-message").html('<br/><div class=" alert alert-error "><p>' + data.error + "</p></div><br/>");
                                    }
                                },
                                error: function () {
                                    $(".ajax-message").html('<div class="alert alert-danger"><p><i class="fa fa-exclamation-circle"></i> Session expired,please make sure you have a network connection and try again</p></div>');
                                }

                            };

                            e.preventDefault();
                            $('.registerForm').ajaxSubmit(options);
            }
        );


</script>
