<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>GiGSHiP</title>
	<link rel="stylesheet" href="<?php echo $assets ?>styles/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo $assets ?>styles/dgicon.css">
	<link rel="stylesheet" href="<?php echo $assets ?>styles/style.css">
	<script>
		function _(id){
			return document.getElementById(id);
		}
		window.addEventListener('load', function(){
			var toRec = _('action-rec');
			toRec.onclick = function (e) {
				//e.preventDefault();
				_('flip').classList.toggle('flip');
			}

			var toLog = _('to-login');
			toLog.onclick = function (e) {
				e.preventDefault();
				_('flip').classList.toggle('flip');
			}
			if (location.hash == '#recovery') {
				_('flip').classList.add('flip');
			}
		});
	</script>
</head>
<body>
	<!--Mian header-->
	<?php include "header.php" ?>
	<!--End Main Header-->
	<!--Main navigation -->
	<nav class="main-nav clearfix">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<ul class="nav-ul">
						<li class="nav-li"><a href="" class="nav-link main-nav-link">Home</a></li>
						<li class="nav-li"><a href="" class="nav-link main-nav-link">All Gigs</a></li>
						<li class="nav-li"><a href="" class="nav-link main-nav-link">All Request</a></li>
						<li class="nav-li"><a href="" class="nav-link main-nav-link">All Categories</a></li>
						<li class="nav-li"><a href="" class="nav-link main-nav-link">All Locations</a></li>
					</ul>
				</div>
			</div>
		</div>
	</nav>
	<!--End Main navigation-->
	
	
	<!-- Main Section -->
	<div class="login-wraper">
		<div id="flip" class="login-flip form-wraper">
			<div class="flip-over front">
			<div class="ajax-message">
			<?php 
			if($this->input->get('c',true)):
			$res = $this->db->get_where('users',array('activation_code'=>$this->input->get('c',true)))->row();
			if($res){
				$this->db->where('id',$res->id);
				$this->db->update('users',array('activation_code'=>""));
				?>
				<div class="alert alert-success"><p><i class="fa fa-check-circle"></i> Thank you once again <?php echo $res->first_name ?>, your account is now active </p></div>				
				<?php
			}
			else
			{
				?>
				<div class="alert alert-danger"><p><i class="fa fa-exclamation-circle"></i> Sorry activation link does not exist or has been used</p></div>
				
				<?php
			}
			 ?>

			<?php endif; ?>
			</div>
			
				<form action="" class="login-form loginForm" id="loginForm">
					<p class="input-wraper">
						<label for="username">Username</label><br>
						<input type="text" name="username" class="text-input username" id="username">
					</p>
					<p class="input-wraper">
						<label for="password">Password</label><br>
						<input type="password" name="password" class="text-input password" id="password">
					</p>
					<p class="input-wraper">
						<button type="submit" value="LOGIN" class="btn btn-primary" id="login-btn">LOGIN</button>
					</p>
					<p class="form-action">
						<label for="stay_logged_in">
							<input type="checkbox" name="stay_logged_in" id="stay_logged_in">
							Stay logged in.
						</label>
						<a href="#recovery" class="tex-right action-rec" id="action-rec">I forgot my password.</a>
					</p>

				</form>
			</div>
			<div class="flip-over back">
				<form action="" class="recover-form recoverForm" id="recoverForm">
					<div class="info-box">
						<span class="icon">
							<span class="dgicon dgicon-question-circle"></span>
						</span>
						<div class="text">
							<h3>Recover lost password.</h3>
							<p class="inline">Please provide the email address used in you account to receive passeord recovery procedure.</p>
						</div>
						
					</div>
					<p class="input-wraper">
						<label for="email">Email</label><br>
						<input type="email" name="email" class="text-input email" id="email" placeholder="">
					</p>
					<hr>
					<p class="btn-wraper">
						<button type="button" class="btn btn-trans text-right" id="to-login">Back to Login</button>

						<button type="submit" class="btn btn-sec text-right" id="recover-btn">Recover</button>
					</p>

				</form>
			</div>
		</div>
	</div>
	<!-- End Main Section -->

	<!--footer content -->
	<footer class="footer-wraper">
		<div class="container">
			<div class="row">
				<!--footer here -->
			</div>
		</div>
	</footer>
	<?php include  "footer.php" ?>

</body>
</html>